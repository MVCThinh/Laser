﻿namespace Bending
{
    partial class ucAutoMain
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                this.ThreadDispose();

                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ucAutoMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea9 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend9 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea10 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend10 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle28 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle29 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle30 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle31 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle32 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle33 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle34 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle35 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle36 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle37 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle38 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle39 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle40 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle45 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle41 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle42 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle43 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle44 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle46 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle51 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle47 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle48 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle49 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle50 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle52 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle53 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle54 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle55 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle56 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle61 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle62 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle63 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle64 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle65 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle66 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle67 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tmrIF = new System.Windows.Forms.Timer(this.components);
            this.spLight1 = new System.IO.Ports.SerialPort(this.components);
            this.spLight2 = new System.IO.Ports.SerialPort(this.components);
            this.spLight3 = new System.IO.Ports.SerialPort(this.components);
            this.pn4 = new System.Windows.Forms.Panel();
            this.btn4 = new System.Windows.Forms.Button();
            this.cbSideImageSize4 = new System.Windows.Forms.ComboBox();
            this.cbLive4 = new System.Windows.Forms.CheckBox();
            this.button_PLC14 = new System.Windows.Forms.Button();
            this.checkBox_Overlay4 = new System.Windows.Forms.CheckBox();
            this.button_PLC4 = new System.Windows.Forms.Button();
            this.button_PC4 = new System.Windows.Forms.Button();
            this.lblScore4 = new System.Windows.Forms.Label();
            this.lblSearchResult4 = new System.Windows.Forms.Label();
            this.cogDS4 = new Cognex.VisionPro.Display.CogDisplay();
            this.lb4 = new System.Windows.Forms.Label();
            this.lbAlign4 = new System.Windows.Forms.Label();
            this.pn3 = new System.Windows.Forms.Panel();
            this.btn3 = new System.Windows.Forms.Button();
            this.cbSideImageSize3 = new System.Windows.Forms.ComboBox();
            this.cbLive3 = new System.Windows.Forms.CheckBox();
            this.button_PLC13 = new System.Windows.Forms.Button();
            this.checkBox_Overlay3 = new System.Windows.Forms.CheckBox();
            this.button_PLC3 = new System.Windows.Forms.Button();
            this.button_PC3 = new System.Windows.Forms.Button();
            this.lblScore3 = new System.Windows.Forms.Label();
            this.lblSearchResult3 = new System.Windows.Forms.Label();
            this.cogDS3 = new Cognex.VisionPro.Display.CogDisplay();
            this.lb3 = new System.Windows.Forms.Label();
            this.lbAlign3 = new System.Windows.Forms.Label();
            this.pn2 = new System.Windows.Forms.Panel();
            this.btn2 = new System.Windows.Forms.Button();
            this.cbSideImageSize2 = new System.Windows.Forms.ComboBox();
            this.cbLive2 = new System.Windows.Forms.CheckBox();
            this.button_PLC12 = new System.Windows.Forms.Button();
            this.checkBox_Overlay2 = new System.Windows.Forms.CheckBox();
            this.button_PLC2 = new System.Windows.Forms.Button();
            this.button_PC2 = new System.Windows.Forms.Button();
            this.lblScore2 = new System.Windows.Forms.Label();
            this.lblSearchResult2 = new System.Windows.Forms.Label();
            this.cogDS2 = new Cognex.VisionPro.Display.CogDisplay();
            this.lb2 = new System.Windows.Forms.Label();
            this.lbAlign2 = new System.Windows.Forms.Label();
            this.pn1 = new System.Windows.Forms.Panel();
            this.btn1 = new System.Windows.Forms.Button();
            this.cbSideImageSize1 = new System.Windows.Forms.ComboBox();
            this.cbLive1 = new System.Windows.Forms.CheckBox();
            this.checkBox_Overlay1 = new System.Windows.Forms.CheckBox();
            this.button_PLC11 = new System.Windows.Forms.Button();
            this.button_PLC1 = new System.Windows.Forms.Button();
            this.button_PC1 = new System.Windows.Forms.Button();
            this.lblScore1 = new System.Windows.Forms.Label();
            this.lblSearchResult1 = new System.Windows.Forms.Label();
            this.cogDS1 = new Cognex.VisionPro.Display.CogDisplay();
            this.lb1 = new System.Windows.Forms.Label();
            this.lbAlign1 = new System.Windows.Forms.Label();
            this.lblRightScore2 = new System.Windows.Forms.Label();
            this.pnResult1 = new System.Windows.Forms.GroupBox();
            this.gbBendResult1 = new System.Windows.Forms.GroupBox();
            this.lblOFFSET1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.dgvSpec1 = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.dgvResult1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbResult1Title = new System.Windows.Forms.Label();
            this.dgvSpec2 = new System.Windows.Forms.DataGridView();
            this.gbBendResult2 = new System.Windows.Forms.GroupBox();
            this.lbResult2Title = new System.Windows.Forms.Label();
            this.btnCPKReset = new System.Windows.Forms.Button();
            this.lblRetryCount1 = new System.Windows.Forms.Label();
            this.lblCycleTime1 = new System.Windows.Forms.Label();
            this.lblPPID1 = new System.Windows.Forms.Label();
            this.pn8 = new System.Windows.Forms.Panel();
            this.pnHeightDisp = new System.Windows.Forms.Panel();
            this.pnInfo5 = new System.Windows.Forms.Panel();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.listBox5 = new System.Windows.Forms.ListBox();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.dgvAlign5 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.dgvError5 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn78 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn79 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblPPID5 = new System.Windows.Forms.Label();
            this.lblCycleTime5 = new System.Windows.Forms.Label();
            this.lblRetryCount5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.cbSideImageSize8 = new System.Windows.Forms.ComboBox();
            this.cbLive8 = new System.Windows.Forms.CheckBox();
            this.button_PLC18 = new System.Windows.Forms.Button();
            this.checkBox_Overlay8 = new System.Windows.Forms.CheckBox();
            this.button_PLC8 = new System.Windows.Forms.Button();
            this.button_PC8 = new System.Windows.Forms.Button();
            this.lblScore8 = new System.Windows.Forms.Label();
            this.lblSearchResult8 = new System.Windows.Forms.Label();
            this.cogDS8 = new Cognex.VisionPro.Display.CogDisplay();
            this.lb8 = new System.Windows.Forms.Label();
            this.lbAlign8 = new System.Windows.Forms.Label();
            this.pn6 = new System.Windows.Forms.Panel();
            this.cbSideImageSize6 = new System.Windows.Forms.ComboBox();
            this.cbLive6 = new System.Windows.Forms.CheckBox();
            this.button_PLC16 = new System.Windows.Forms.Button();
            this.button_PLC6 = new System.Windows.Forms.Button();
            this.button_PC6 = new System.Windows.Forms.Button();
            this.lblScore6 = new System.Windows.Forms.Label();
            this.checkBox_Overlay6 = new System.Windows.Forms.CheckBox();
            this.lblSearchResult6 = new System.Windows.Forms.Label();
            this.cogDS6 = new Cognex.VisionPro.Display.CogDisplay();
            this.lb6 = new System.Windows.Forms.Label();
            this.lbAlign6 = new System.Windows.Forms.Label();
            this.dgvOKNG = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pn5 = new System.Windows.Forms.Panel();
            this.cbSideImageSize5 = new System.Windows.Forms.ComboBox();
            this.cbLive5 = new System.Windows.Forms.CheckBox();
            this.button_PLC15 = new System.Windows.Forms.Button();
            this.button_PLC5 = new System.Windows.Forms.Button();
            this.button_PC5 = new System.Windows.Forms.Button();
            this.checkBox_Overlay5 = new System.Windows.Forms.CheckBox();
            this.lblScore5 = new System.Windows.Forms.Label();
            this.lblSearchResult5 = new System.Windows.Forms.Label();
            this.cogDS5 = new Cognex.VisionPro.Display.CogDisplay();
            this.lb5 = new System.Windows.Forms.Label();
            this.pngraph = new System.Windows.Forms.Panel();
            this.pnGrahpData = new System.Windows.Forms.Panel();
            this.btnClearDisp = new System.Windows.Forms.Button();
            this.btnDispReset = new System.Windows.Forms.Button();
            this.dtpStart = new System.Windows.Forms.DateTimePicker();
            this.btnDisp1 = new System.Windows.Forms.Button();
            this.dtpEnd = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tcGraph = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pnSquareLength = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtSuareX1 = new System.Windows.Forms.TextBox();
            this.txtSuareY1 = new System.Windows.Forms.TextBox();
            this.lblSpecOut1_4 = new System.Windows.Forms.Label();
            this.lblSpecOut1_3 = new System.Windows.Forms.Label();
            this.ct1_Yspec1_4 = new System.Windows.Forms.Label();
            this.ct1_Yspec1_3 = new System.Windows.Forms.Label();
            this.ct1_Xspec1_4 = new System.Windows.Forms.Label();
            this.ct1_Xspec1_3 = new System.Windows.Forms.Label();
            this.ctDisp1_4 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ctDisp1_3 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.lblSpecOut1_2 = new System.Windows.Forms.Label();
            this.lblSpecOut1_1 = new System.Windows.Forms.Label();
            this.ct1_Yspec1_2 = new System.Windows.Forms.Label();
            this.ct1_Xspec1_2 = new System.Windows.Forms.Label();
            this.ct1_Yspec1_1 = new System.Windows.Forms.Label();
            this.ct1_Xspec1_1 = new System.Windows.Forms.Label();
            this.ctDisp1_2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ctDisp1_1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblSpecOut2_2 = new System.Windows.Forms.Label();
            this.lblSpecOut2_1 = new System.Windows.Forms.Label();
            this.ct2_YSpec2_2 = new System.Windows.Forms.Label();
            this.ct2_XSpec2_2 = new System.Windows.Forms.Label();
            this.ct2_YSpec2_1 = new System.Windows.Forms.Label();
            this.ct2_XSpec2_1 = new System.Windows.Forms.Label();
            this.ctDisp2_2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ctDisp2_1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lblSpecOut3_2 = new System.Windows.Forms.Label();
            this.lblSpecOut3_1 = new System.Windows.Forms.Label();
            this.ct3_YSpec3_2 = new System.Windows.Forms.Label();
            this.ct3_XSpec3_2 = new System.Windows.Forms.Label();
            this.ct3_YSpec3_1 = new System.Windows.Forms.Label();
            this.ct3_XSpec3_1 = new System.Windows.Forms.Label();
            this.ctDisp3_2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ctDisp3_1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtSuareY = new System.Windows.Forms.TextBox();
            this.txtSuareX = new System.Windows.Forms.TextBox();
            this.lblSpecOut4_2 = new System.Windows.Forms.Label();
            this.lblSpecOut4_1 = new System.Windows.Forms.Label();
            this.rbGraphBD3 = new System.Windows.Forms.RadioButton();
            this.rbGraphBD2 = new System.Windows.Forms.RadioButton();
            this.rbGraphBD1 = new System.Windows.Forms.RadioButton();
            this.rbGraphTotal = new System.Windows.Forms.RadioButton();
            this.ct4_Yspec4_2 = new System.Windows.Forms.Label();
            this.ct4_Xspec4_2 = new System.Windows.Forms.Label();
            this.ct4_Yspec4_1 = new System.Windows.Forms.Label();
            this.ct4_Xspec4_1 = new System.Windows.Forms.Label();
            this.ctDisp4_2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ctDisp4_1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pnAPC = new System.Windows.Forms.Panel();
            this.dgvAPC2 = new System.Windows.Forms.DataGridView();
            this.dgvAPC1 = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pn7 = new System.Windows.Forms.Panel();
            this.lblRightScore1 = new System.Windows.Forms.Label();
            this.cbSideImageSize7 = new System.Windows.Forms.ComboBox();
            this.cbLive7 = new System.Windows.Forms.CheckBox();
            this.button_PLC17 = new System.Windows.Forms.Button();
            this.button_PLC7 = new System.Windows.Forms.Button();
            this.button_PC7 = new System.Windows.Forms.Button();
            this.lblScore7 = new System.Windows.Forms.Label();
            this.checkBox_Overlay7 = new System.Windows.Forms.CheckBox();
            this.lblSearchResult7 = new System.Windows.Forms.Label();
            this.cogDS7 = new Cognex.VisionPro.Display.CogDisplay();
            this.lb7 = new System.Windows.Forms.Label();
            this.lbAlign7 = new System.Windows.Forms.Label();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.dgvAlign3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn53 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn54 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn55 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn56 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn57 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn58 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn59 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn87 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn88 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.dgvError3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn74 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn75 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.listBox4 = new System.Windows.Forms.ListBox();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.dgvAlign4 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn60 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn61 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn62 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn63 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn64 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn65 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn66 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn68 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn69 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn89 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn90 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.dgvError4 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn76 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn77 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tmrSave = new System.Windows.Forms.Timer(this.components);
            this.pnResult2 = new System.Windows.Forms.GroupBox();
            this.gbBendResult3 = new System.Windows.Forms.GroupBox();
            this.dgvSpec3 = new System.Windows.Forms.DataGridView();
            this.lblOFFSET2 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.dgvResult3 = new System.Windows.Forms.DataGridView();
            this.Column18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn81 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn82 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbResult3Title = new System.Windows.Forms.Label();
            this.gbBendResult4 = new System.Windows.Forms.GroupBox();
            this.lblOFFSET3 = new System.Windows.Forms.Label();
            this.dgvSpec4 = new System.Windows.Forms.DataGridView();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.dgvResult4 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn80 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lbResult4Title = new System.Windows.Forms.Label();
            this.pnOKNG = new System.Windows.Forms.Panel();
            this.cbSCFInspResult = new System.Windows.Forms.CheckBox();
            this.btnManualMark = new System.Windows.Forms.Button();
            this.pnTimeData = new System.Windows.Forms.Panel();
            this.btnTodayDisp = new System.Windows.Forms.Button();
            this.btnDisp = new System.Windows.Forms.Button();
            this.dtpokngStart = new System.Windows.Forms.DateTimePicker();
            this.dtpokngEnd = new System.Windows.Forms.DateTimePicker();
            this.label19 = new System.Windows.Forms.Label();
            this.cbResult = new System.Windows.Forms.CheckBox();
            this.label15 = new System.Windows.Forms.Label();
            this.pnInfo1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.btnOff = new System.Windows.Forms.Button();
            this.btnOn = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.PCYTEST = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.dgvAlign1 = new System.Windows.Forms.DataGridView();
            this.Column16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.dgvError1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn70 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn71 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pnInfo2 = new System.Windows.Forms.Panel();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.dgvAlign2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn67 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn85 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn86 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.dgvError2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn72 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn73 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblCycleTime2 = new System.Windows.Forms.Label();
            this.lblRetryCount2 = new System.Windows.Forms.Label();
            this.lblPPID2 = new System.Windows.Forms.Label();
            this.pnInfo3 = new System.Windows.Forms.Panel();
            this.lblPPID4 = new System.Windows.Forms.Label();
            this.lblCycleTime4 = new System.Windows.Forms.Label();
            this.lblRetryCount4 = new System.Windows.Forms.Label();
            this.pnInfo4 = new System.Windows.Forms.Panel();
            this.lblPPID3 = new System.Windows.Forms.Label();
            this.lblCycleTime3 = new System.Windows.Forms.Label();
            this.lblRetryCount3 = new System.Windows.Forms.Label();
            this.dataGridViewTextBoxColumn101 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn100 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn99 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn98 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn97 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn96 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn95 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn94 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn93 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn92 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn91 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tmr1Sec = new System.Windows.Forms.Timer(this.components);
            this.tmrDispChart = new System.Windows.Forms.Timer(this.components);
            this.dgvResult2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblOFFSET0 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.pn4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogDS4)).BeginInit();
            this.pn3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogDS3)).BeginInit();
            this.pn2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogDS2)).BeginInit();
            this.pn1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogDS1)).BeginInit();
            this.pnResult1.SuspendLayout();
            this.gbBendResult1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpec1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpec2)).BeginInit();
            this.gbBendResult2.SuspendLayout();
            this.pn8.SuspendLayout();
            this.pnHeightDisp.SuspendLayout();
            this.pnInfo5.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage18.SuspendLayout();
            this.tabPage19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlign5)).BeginInit();
            this.tabPage20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvError5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cogDS8)).BeginInit();
            this.pn6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogDS6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOKNG)).BeginInit();
            this.pn5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogDS5)).BeginInit();
            this.pngraph.SuspendLayout();
            this.pnGrahpData.SuspendLayout();
            this.tcGraph.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.pnSquareLength.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp1_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp1_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp1_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp1_1)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp2_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp2_1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp3_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp3_1)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp4_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp4_1)).BeginInit();
            this.pnAPC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAPC2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAPC1)).BeginInit();
            this.panel1.SuspendLayout();
            this.pn7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cogDS7)).BeginInit();
            this.tabControl3.SuspendLayout();
            this.tabPage9.SuspendLayout();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlign3)).BeginInit();
            this.tabPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvError3)).BeginInit();
            this.tabControl4.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlign4)).BeginInit();
            this.tabPage16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvError4)).BeginInit();
            this.pnResult2.SuspendLayout();
            this.gbBendResult3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpec3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult3)).BeginInit();
            this.gbBendResult4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpec4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult4)).BeginInit();
            this.pnOKNG.SuspendLayout();
            this.pnTimeData.SuspendLayout();
            this.pnInfo1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlign1)).BeginInit();
            this.tabPage13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvError1)).BeginInit();
            this.pnInfo2.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlign2)).BeginInit();
            this.tabPage14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvError2)).BeginInit();
            this.pnInfo3.SuspendLayout();
            this.pnInfo4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult2)).BeginInit();
            this.SuspendLayout();
            // 
            // tmrIF
            // 
            this.tmrIF.Interval = 50;
            this.tmrIF.Tick += new System.EventHandler(this.tmrIF_Tick);
            // 
            // spLight1
            // 
            this.spLight1.BaudRate = 19200;
            // 
            // spLight2
            // 
            this.spLight2.BaudRate = 19200;
            // 
            // spLight3
            // 
            this.spLight3.BaudRate = 19200;
            // 
            // pn4
            // 
            this.pn4.BackColor = System.Drawing.Color.Gray;
            this.pn4.Controls.Add(this.btn4);
            this.pn4.Controls.Add(this.cbSideImageSize4);
            this.pn4.Controls.Add(this.cbLive4);
            this.pn4.Controls.Add(this.button_PLC14);
            this.pn4.Controls.Add(this.checkBox_Overlay4);
            this.pn4.Controls.Add(this.button_PLC4);
            this.pn4.Controls.Add(this.button_PC4);
            this.pn4.Controls.Add(this.lblScore4);
            this.pn4.Controls.Add(this.lblSearchResult4);
            this.pn4.Controls.Add(this.cogDS4);
            this.pn4.Controls.Add(this.lb4);
            this.pn4.Controls.Add(this.lbAlign4);
            this.pn4.Location = new System.Drawing.Point(1224, 331);
            this.pn4.Name = "pn4";
            this.pn4.Size = new System.Drawing.Size(680, 430);
            this.pn4.TabIndex = 89;
            // 
            // btn4
            // 
            this.btn4.Location = new System.Drawing.Point(314, 404);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(75, 23);
            this.btn4.TabIndex = 314;
            this.btn4.Text = "Img";
            this.btn4.UseVisualStyleBackColor = true;
            this.btn4.Visible = false;
            // 
            // cbSideImageSize4
            // 
            this.cbSideImageSize4.FormattingEnabled = true;
            this.cbSideImageSize4.Items.AddRange(new object[] {
            "100%",
            "200%",
            "300%",
            "400%"});
            this.cbSideImageSize4.Location = new System.Drawing.Point(567, 407);
            this.cbSideImageSize4.Name = "cbSideImageSize4";
            this.cbSideImageSize4.Size = new System.Drawing.Size(60, 20);
            this.cbSideImageSize4.TabIndex = 303;
            // 
            // cbLive4
            // 
            this.cbLive4.ForeColor = System.Drawing.Color.White;
            this.cbLive4.Location = new System.Drawing.Point(630, 407);
            this.cbLive4.Name = "cbLive4";
            this.cbLive4.Size = new System.Drawing.Size(47, 20);
            this.cbLive4.TabIndex = 302;
            this.cbLive4.Text = "Live";
            this.cbLive4.UseVisualStyleBackColor = true;
            this.cbLive4.Visible = false;
            // 
            // button_PLC14
            // 
            this.button_PLC14.Location = new System.Drawing.Point(512, 2);
            this.button_PLC14.Name = "button_PLC14";
            this.button_PLC14.Size = new System.Drawing.Size(23, 20);
            this.button_PLC14.TabIndex = 301;
            this.button_PLC14.UseVisualStyleBackColor = true;
            // 
            // checkBox_Overlay4
            // 
            this.checkBox_Overlay4.ForeColor = System.Drawing.Color.White;
            this.checkBox_Overlay4.Location = new System.Drawing.Point(5, 407);
            this.checkBox_Overlay4.Name = "checkBox_Overlay4";
            this.checkBox_Overlay4.Size = new System.Drawing.Size(71, 20);
            this.checkBox_Overlay4.TabIndex = 298;
            this.checkBox_Overlay4.Text = "OverLay";
            this.checkBox_Overlay4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_Overlay4.UseVisualStyleBackColor = true;
            this.checkBox_Overlay4.CheckedChanged += new System.EventHandler(this.checkBox_Overlay4_CheckedChanged);
            // 
            // button_PLC4
            // 
            this.button_PLC4.Location = new System.Drawing.Point(488, 2);
            this.button_PLC4.Name = "button_PLC4";
            this.button_PLC4.Size = new System.Drawing.Size(23, 20);
            this.button_PLC4.TabIndex = 300;
            this.button_PLC4.UseVisualStyleBackColor = true;
            // 
            // button_PC4
            // 
            this.button_PC4.Location = new System.Drawing.Point(536, 2);
            this.button_PC4.Name = "button_PC4";
            this.button_PC4.Size = new System.Drawing.Size(36, 20);
            this.button_PC4.TabIndex = 299;
            this.button_PC4.Text = "0";
            this.button_PC4.UseVisualStyleBackColor = true;
            // 
            // lblScore4
            // 
            this.lblScore4.BackColor = System.Drawing.Color.Black;
            this.lblScore4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblScore4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblScore4.ForeColor = System.Drawing.Color.Yellow;
            this.lblScore4.Location = new System.Drawing.Point(578, 2);
            this.lblScore4.Name = "lblScore4";
            this.lblScore4.Size = new System.Drawing.Size(49, 20);
            this.lblScore4.TabIndex = 116;
            this.lblScore4.Text = "Score";
            this.lblScore4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSearchResult4
            // 
            this.lblSearchResult4.BackColor = System.Drawing.Color.Silver;
            this.lblSearchResult4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSearchResult4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchResult4.ForeColor = System.Drawing.Color.GreenYellow;
            this.lblSearchResult4.Location = new System.Drawing.Point(633, 0);
            this.lblSearchResult4.Name = "lblSearchResult4";
            this.lblSearchResult4.Size = new System.Drawing.Size(47, 25);
            this.lblSearchResult4.TabIndex = 115;
            this.lblSearchResult4.Text = "-";
            this.lblSearchResult4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cogDS4
            // 
            this.cogDS4.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDS4.ColorMapLowerRoiLimit = 0D;
            this.cogDS4.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDS4.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDS4.ColorMapUpperRoiLimit = 1D;
            this.cogDS4.DoubleTapZoomCycleLength = 2;
            this.cogDS4.DoubleTapZoomSensitivity = 2.5D;
            this.cogDS4.Location = new System.Drawing.Point(1, 25);
            this.cogDS4.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDS4.MouseWheelSensitivity = 1D;
            this.cogDS4.Name = "cogDS4";
            this.cogDS4.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDS4.OcxState")));
            this.cogDS4.Size = new System.Drawing.Size(679, 405);
            this.cogDS4.TabIndex = 9;
            this.cogDS4.DoubleClick += new System.EventHandler(this.cogDS_DoubleClick);
            // 
            // lb4
            // 
            this.lb4.BackColor = System.Drawing.Color.Black;
            this.lb4.ForeColor = System.Drawing.Color.Yellow;
            this.lb4.Location = new System.Drawing.Point(2, 2);
            this.lb4.Name = "lb4";
            this.lb4.Size = new System.Drawing.Size(480, 20);
            this.lb4.TabIndex = 0;
            this.lb4.Text = "    CAM1";
            this.lb4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbAlign4
            // 
            this.lbAlign4.BackColor = System.Drawing.Color.DimGray;
            this.lbAlign4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlign4.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlign4.ForeColor = System.Drawing.Color.White;
            this.lbAlign4.Location = new System.Drawing.Point(5, 255);
            this.lbAlign4.Name = "lbAlign4";
            this.lbAlign4.Size = new System.Drawing.Size(36, 18);
            this.lbAlign4.TabIndex = 94;
            this.lbAlign4.Text = "Align";
            this.lbAlign4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbAlign4.Visible = false;
            // 
            // pn3
            // 
            this.pn3.BackColor = System.Drawing.Color.Gray;
            this.pn3.Controls.Add(this.btn3);
            this.pn3.Controls.Add(this.cbSideImageSize3);
            this.pn3.Controls.Add(this.cbLive3);
            this.pn3.Controls.Add(this.button_PLC13);
            this.pn3.Controls.Add(this.checkBox_Overlay3);
            this.pn3.Controls.Add(this.button_PLC3);
            this.pn3.Controls.Add(this.button_PC3);
            this.pn3.Controls.Add(this.lblScore3);
            this.pn3.Controls.Add(this.lblSearchResult3);
            this.pn3.Controls.Add(this.cogDS3);
            this.pn3.Controls.Add(this.lb3);
            this.pn3.Controls.Add(this.lbAlign3);
            this.pn3.Location = new System.Drawing.Point(538, 331);
            this.pn3.Name = "pn3";
            this.pn3.Size = new System.Drawing.Size(680, 430);
            this.pn3.TabIndex = 88;
            // 
            // btn3
            // 
            this.btn3.Location = new System.Drawing.Point(293, 404);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(75, 23);
            this.btn3.TabIndex = 313;
            this.btn3.Text = "Img";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Visible = false;
            // 
            // cbSideImageSize3
            // 
            this.cbSideImageSize3.FormattingEnabled = true;
            this.cbSideImageSize3.Items.AddRange(new object[] {
            "100%",
            "200%",
            "300%",
            "400%"});
            this.cbSideImageSize3.Location = new System.Drawing.Point(569, 407);
            this.cbSideImageSize3.Name = "cbSideImageSize3";
            this.cbSideImageSize3.Size = new System.Drawing.Size(60, 20);
            this.cbSideImageSize3.TabIndex = 299;
            // 
            // cbLive3
            // 
            this.cbLive3.ForeColor = System.Drawing.Color.White;
            this.cbLive3.Location = new System.Drawing.Point(632, 407);
            this.cbLive3.Name = "cbLive3";
            this.cbLive3.Size = new System.Drawing.Size(47, 20);
            this.cbLive3.TabIndex = 298;
            this.cbLive3.Text = "Live";
            this.cbLive3.UseVisualStyleBackColor = true;
            this.cbLive3.Visible = false;
            this.cbLive3.CheckedChanged += new System.EventHandler(this.cbLive3_CheckedChanged);
            // 
            // button_PLC13
            // 
            this.button_PLC13.Location = new System.Drawing.Point(514, 1);
            this.button_PLC13.Name = "button_PLC13";
            this.button_PLC13.Size = new System.Drawing.Size(23, 20);
            this.button_PLC13.TabIndex = 297;
            this.button_PLC13.UseVisualStyleBackColor = true;
            // 
            // checkBox_Overlay3
            // 
            this.checkBox_Overlay3.ForeColor = System.Drawing.Color.White;
            this.checkBox_Overlay3.Location = new System.Drawing.Point(3, 407);
            this.checkBox_Overlay3.Name = "checkBox_Overlay3";
            this.checkBox_Overlay3.Size = new System.Drawing.Size(71, 20);
            this.checkBox_Overlay3.TabIndex = 294;
            this.checkBox_Overlay3.Text = "OverLay";
            this.checkBox_Overlay3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_Overlay3.UseVisualStyleBackColor = true;
            this.checkBox_Overlay3.CheckedChanged += new System.EventHandler(this.checkBox_Overlay3_CheckedChanged);
            // 
            // button_PLC3
            // 
            this.button_PLC3.Location = new System.Drawing.Point(490, 1);
            this.button_PLC3.Name = "button_PLC3";
            this.button_PLC3.Size = new System.Drawing.Size(23, 20);
            this.button_PLC3.TabIndex = 296;
            this.button_PLC3.UseVisualStyleBackColor = true;
            // 
            // button_PC3
            // 
            this.button_PC3.Location = new System.Drawing.Point(538, 1);
            this.button_PC3.Name = "button_PC3";
            this.button_PC3.Size = new System.Drawing.Size(36, 20);
            this.button_PC3.TabIndex = 295;
            this.button_PC3.Text = "0";
            this.button_PC3.UseVisualStyleBackColor = true;
            // 
            // lblScore3
            // 
            this.lblScore3.BackColor = System.Drawing.Color.Black;
            this.lblScore3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblScore3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblScore3.ForeColor = System.Drawing.Color.Yellow;
            this.lblScore3.Location = new System.Drawing.Point(580, 1);
            this.lblScore3.Name = "lblScore3";
            this.lblScore3.Size = new System.Drawing.Size(49, 20);
            this.lblScore3.TabIndex = 116;
            this.lblScore3.Text = "Score";
            this.lblScore3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSearchResult3
            // 
            this.lblSearchResult3.BackColor = System.Drawing.Color.Silver;
            this.lblSearchResult3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSearchResult3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchResult3.ForeColor = System.Drawing.Color.GreenYellow;
            this.lblSearchResult3.Location = new System.Drawing.Point(632, 0);
            this.lblSearchResult3.Name = "lblSearchResult3";
            this.lblSearchResult3.Size = new System.Drawing.Size(47, 25);
            this.lblSearchResult3.TabIndex = 115;
            this.lblSearchResult3.Text = "-";
            this.lblSearchResult3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cogDS3
            // 
            this.cogDS3.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDS3.ColorMapLowerRoiLimit = 0D;
            this.cogDS3.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDS3.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDS3.ColorMapUpperRoiLimit = 1D;
            this.cogDS3.DoubleTapZoomCycleLength = 2;
            this.cogDS3.DoubleTapZoomSensitivity = 2.5D;
            this.cogDS3.Location = new System.Drawing.Point(0, 25);
            this.cogDS3.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDS3.MouseWheelSensitivity = 1D;
            this.cogDS3.Name = "cogDS3";
            this.cogDS3.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDS3.OcxState")));
            this.cogDS3.Size = new System.Drawing.Size(680, 405);
            this.cogDS3.TabIndex = 9;
            this.cogDS3.DoubleClick += new System.EventHandler(this.cogDS_DoubleClick);
            // 
            // lb3
            // 
            this.lb3.BackColor = System.Drawing.Color.Black;
            this.lb3.ForeColor = System.Drawing.Color.Yellow;
            this.lb3.Location = new System.Drawing.Point(0, 2);
            this.lb3.Name = "lb3";
            this.lb3.Size = new System.Drawing.Size(484, 20);
            this.lb3.TabIndex = 0;
            this.lb3.Text = "    CAM1";
            this.lb3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbAlign3
            // 
            this.lbAlign3.BackColor = System.Drawing.Color.DimGray;
            this.lbAlign3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlign3.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlign3.ForeColor = System.Drawing.Color.White;
            this.lbAlign3.Location = new System.Drawing.Point(5, 255);
            this.lbAlign3.Name = "lbAlign3";
            this.lbAlign3.Size = new System.Drawing.Size(36, 18);
            this.lbAlign3.TabIndex = 94;
            this.lbAlign3.Text = "Align";
            this.lbAlign3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbAlign3.Visible = false;
            // 
            // pn2
            // 
            this.pn2.BackColor = System.Drawing.Color.Gray;
            this.pn2.Controls.Add(this.btn2);
            this.pn2.Controls.Add(this.cbSideImageSize2);
            this.pn2.Controls.Add(this.cbLive2);
            this.pn2.Controls.Add(this.button_PLC12);
            this.pn2.Controls.Add(this.checkBox_Overlay2);
            this.pn2.Controls.Add(this.button_PLC2);
            this.pn2.Controls.Add(this.button_PC2);
            this.pn2.Controls.Add(this.lblScore2);
            this.pn2.Controls.Add(this.lblSearchResult2);
            this.pn2.Controls.Add(this.cogDS2);
            this.pn2.Controls.Add(this.lb2);
            this.pn2.Controls.Add(this.lbAlign2);
            this.pn2.Location = new System.Drawing.Point(881, 5);
            this.pn2.Name = "pn2";
            this.pn2.Size = new System.Drawing.Size(337, 298);
            this.pn2.TabIndex = 87;
            // 
            // btn2
            // 
            this.btn2.Location = new System.Drawing.Point(121, 275);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(75, 23);
            this.btn2.TabIndex = 314;
            this.btn2.Text = "Img";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Visible = false;
            // 
            // cbSideImageSize2
            // 
            this.cbSideImageSize2.FormattingEnabled = true;
            this.cbSideImageSize2.Items.AddRange(new object[] {
            "100%",
            "200%",
            "300%",
            "400%"});
            this.cbSideImageSize2.Location = new System.Drawing.Point(226, 277);
            this.cbSideImageSize2.Name = "cbSideImageSize2";
            this.cbSideImageSize2.Size = new System.Drawing.Size(60, 20);
            this.cbSideImageSize2.TabIndex = 298;
            // 
            // cbLive2
            // 
            this.cbLive2.ForeColor = System.Drawing.Color.White;
            this.cbLive2.Location = new System.Drawing.Point(289, 277);
            this.cbLive2.Name = "cbLive2";
            this.cbLive2.Size = new System.Drawing.Size(47, 20);
            this.cbLive2.TabIndex = 297;
            this.cbLive2.Text = "Live";
            this.cbLive2.UseVisualStyleBackColor = true;
            this.cbLive2.Visible = false;
            // 
            // button_PLC12
            // 
            this.button_PLC12.Location = new System.Drawing.Point(173, 2);
            this.button_PLC12.Name = "button_PLC12";
            this.button_PLC12.Size = new System.Drawing.Size(23, 20);
            this.button_PLC12.TabIndex = 293;
            this.button_PLC12.UseVisualStyleBackColor = true;
            // 
            // checkBox_Overlay2
            // 
            this.checkBox_Overlay2.ForeColor = System.Drawing.Color.White;
            this.checkBox_Overlay2.Location = new System.Drawing.Point(3, 280);
            this.checkBox_Overlay2.Name = "checkBox_Overlay2";
            this.checkBox_Overlay2.Size = new System.Drawing.Size(71, 20);
            this.checkBox_Overlay2.TabIndex = 290;
            this.checkBox_Overlay2.Text = "OverLay";
            this.checkBox_Overlay2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_Overlay2.UseVisualStyleBackColor = true;
            this.checkBox_Overlay2.CheckedChanged += new System.EventHandler(this.checkBox_Overlay2_CheckedChanged);
            // 
            // button_PLC2
            // 
            this.button_PLC2.Location = new System.Drawing.Point(149, 2);
            this.button_PLC2.Name = "button_PLC2";
            this.button_PLC2.Size = new System.Drawing.Size(23, 20);
            this.button_PLC2.TabIndex = 292;
            this.button_PLC2.UseVisualStyleBackColor = true;
            // 
            // button_PC2
            // 
            this.button_PC2.Location = new System.Drawing.Point(197, 2);
            this.button_PC2.Name = "button_PC2";
            this.button_PC2.Size = new System.Drawing.Size(36, 20);
            this.button_PC2.TabIndex = 291;
            this.button_PC2.Text = "0";
            this.button_PC2.UseVisualStyleBackColor = true;
            // 
            // lblScore2
            // 
            this.lblScore2.BackColor = System.Drawing.Color.Black;
            this.lblScore2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblScore2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblScore2.ForeColor = System.Drawing.Color.Yellow;
            this.lblScore2.Location = new System.Drawing.Point(239, 2);
            this.lblScore2.Name = "lblScore2";
            this.lblScore2.Size = new System.Drawing.Size(49, 20);
            this.lblScore2.TabIndex = 116;
            this.lblScore2.Text = "Score";
            this.lblScore2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSearchResult2
            // 
            this.lblSearchResult2.BackColor = System.Drawing.Color.Silver;
            this.lblSearchResult2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSearchResult2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchResult2.ForeColor = System.Drawing.Color.GreenYellow;
            this.lblSearchResult2.Location = new System.Drawing.Point(289, 0);
            this.lblSearchResult2.Name = "lblSearchResult2";
            this.lblSearchResult2.Size = new System.Drawing.Size(47, 23);
            this.lblSearchResult2.TabIndex = 115;
            this.lblSearchResult2.Text = "-";
            this.lblSearchResult2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cogDS2
            // 
            this.cogDS2.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDS2.ColorMapLowerRoiLimit = 0D;
            this.cogDS2.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDS2.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDS2.ColorMapUpperRoiLimit = 1D;
            this.cogDS2.DoubleTapZoomCycleLength = 2;
            this.cogDS2.DoubleTapZoomSensitivity = 2.5D;
            this.cogDS2.Location = new System.Drawing.Point(1, 22);
            this.cogDS2.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDS2.MouseWheelSensitivity = 1D;
            this.cogDS2.Name = "cogDS2";
            this.cogDS2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDS2.OcxState")));
            this.cogDS2.Size = new System.Drawing.Size(335, 278);
            this.cogDS2.TabIndex = 9;
            this.cogDS2.DoubleClick += new System.EventHandler(this.cogDS_DoubleClick);
            // 
            // lb2
            // 
            this.lb2.BackColor = System.Drawing.Color.Black;
            this.lb2.ForeColor = System.Drawing.Color.Yellow;
            this.lb2.Location = new System.Drawing.Point(2, 2);
            this.lb2.Name = "lb2";
            this.lb2.Size = new System.Drawing.Size(234, 20);
            this.lb2.TabIndex = 0;
            this.lb2.Text = "    CAM1";
            this.lb2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbAlign2
            // 
            this.lbAlign2.BackColor = System.Drawing.Color.DimGray;
            this.lbAlign2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlign2.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlign2.ForeColor = System.Drawing.Color.White;
            this.lbAlign2.Location = new System.Drawing.Point(5, 255);
            this.lbAlign2.Name = "lbAlign2";
            this.lbAlign2.Size = new System.Drawing.Size(36, 18);
            this.lbAlign2.TabIndex = 94;
            this.lbAlign2.Text = "Align";
            this.lbAlign2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbAlign2.Visible = false;
            // 
            // pn1
            // 
            this.pn1.BackColor = System.Drawing.Color.Gray;
            this.pn1.Controls.Add(this.btn1);
            this.pn1.Controls.Add(this.cbSideImageSize1);
            this.pn1.Controls.Add(this.cbLive1);
            this.pn1.Controls.Add(this.checkBox_Overlay1);
            this.pn1.Controls.Add(this.button_PLC11);
            this.pn1.Controls.Add(this.button_PLC1);
            this.pn1.Controls.Add(this.button_PC1);
            this.pn1.Controls.Add(this.lblScore1);
            this.pn1.Controls.Add(this.lblSearchResult1);
            this.pn1.Controls.Add(this.cogDS1);
            this.pn1.Controls.Add(this.lb1);
            this.pn1.Controls.Add(this.lbAlign1);
            this.pn1.Location = new System.Drawing.Point(538, 3);
            this.pn1.Name = "pn1";
            this.pn1.Size = new System.Drawing.Size(337, 300);
            this.pn1.TabIndex = 86;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(117, 277);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 23);
            this.btn1.TabIndex = 313;
            this.btn1.Text = "Img";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Visible = false;
            // 
            // cbSideImageSize1
            // 
            this.cbSideImageSize1.FormattingEnabled = true;
            this.cbSideImageSize1.Items.AddRange(new object[] {
            "100%",
            "200%",
            "300%",
            "400%"});
            this.cbSideImageSize1.Location = new System.Drawing.Point(226, 277);
            this.cbSideImageSize1.Name = "cbSideImageSize1";
            this.cbSideImageSize1.Size = new System.Drawing.Size(60, 20);
            this.cbSideImageSize1.TabIndex = 296;
            // 
            // cbLive1
            // 
            this.cbLive1.ForeColor = System.Drawing.Color.White;
            this.cbLive1.Location = new System.Drawing.Point(289, 277);
            this.cbLive1.Name = "cbLive1";
            this.cbLive1.Size = new System.Drawing.Size(47, 20);
            this.cbLive1.TabIndex = 295;
            this.cbLive1.Text = "Live";
            this.cbLive1.UseVisualStyleBackColor = true;
            this.cbLive1.Visible = false;
            // 
            // checkBox_Overlay1
            // 
            this.checkBox_Overlay1.ForeColor = System.Drawing.Color.White;
            this.checkBox_Overlay1.Location = new System.Drawing.Point(0, 280);
            this.checkBox_Overlay1.Name = "checkBox_Overlay1";
            this.checkBox_Overlay1.Size = new System.Drawing.Size(71, 20);
            this.checkBox_Overlay1.TabIndex = 286;
            this.checkBox_Overlay1.Text = "OverLay";
            this.checkBox_Overlay1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_Overlay1.UseVisualStyleBackColor = true;
            this.checkBox_Overlay1.CheckedChanged += new System.EventHandler(this.checkBox_Overlay1_CheckedChanged);
            // 
            // button_PLC11
            // 
            this.button_PLC11.Location = new System.Drawing.Point(173, 3);
            this.button_PLC11.Name = "button_PLC11";
            this.button_PLC11.Size = new System.Drawing.Size(23, 20);
            this.button_PLC11.TabIndex = 289;
            this.button_PLC11.UseVisualStyleBackColor = true;
            // 
            // button_PLC1
            // 
            this.button_PLC1.Location = new System.Drawing.Point(149, 3);
            this.button_PLC1.Name = "button_PLC1";
            this.button_PLC1.Size = new System.Drawing.Size(23, 20);
            this.button_PLC1.TabIndex = 288;
            this.button_PLC1.UseVisualStyleBackColor = true;
            // 
            // button_PC1
            // 
            this.button_PC1.Location = new System.Drawing.Point(197, 3);
            this.button_PC1.Name = "button_PC1";
            this.button_PC1.Size = new System.Drawing.Size(36, 20);
            this.button_PC1.TabIndex = 287;
            this.button_PC1.Text = "0";
            this.button_PC1.UseVisualStyleBackColor = true;
            // 
            // lblScore1
            // 
            this.lblScore1.BackColor = System.Drawing.Color.Black;
            this.lblScore1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblScore1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblScore1.ForeColor = System.Drawing.Color.Yellow;
            this.lblScore1.Location = new System.Drawing.Point(239, 2);
            this.lblScore1.Name = "lblScore1";
            this.lblScore1.Size = new System.Drawing.Size(49, 20);
            this.lblScore1.TabIndex = 115;
            this.lblScore1.Text = "Score";
            this.lblScore1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSearchResult1
            // 
            this.lblSearchResult1.BackColor = System.Drawing.Color.Silver;
            this.lblSearchResult1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSearchResult1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchResult1.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblSearchResult1.Location = new System.Drawing.Point(289, 0);
            this.lblSearchResult1.Name = "lblSearchResult1";
            this.lblSearchResult1.Size = new System.Drawing.Size(47, 25);
            this.lblSearchResult1.TabIndex = 114;
            this.lblSearchResult1.Text = "-";
            this.lblSearchResult1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cogDS1
            // 
            this.cogDS1.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDS1.ColorMapLowerRoiLimit = 0D;
            this.cogDS1.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDS1.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDS1.ColorMapUpperRoiLimit = 1D;
            this.cogDS1.DoubleTapZoomCycleLength = 2;
            this.cogDS1.DoubleTapZoomSensitivity = 2.5D;
            this.cogDS1.Location = new System.Drawing.Point(3, 25);
            this.cogDS1.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDS1.MouseWheelSensitivity = 1D;
            this.cogDS1.Name = "cogDS1";
            this.cogDS1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDS1.OcxState")));
            this.cogDS1.Size = new System.Drawing.Size(334, 275);
            this.cogDS1.TabIndex = 9;
            this.cogDS1.DoubleClick += new System.EventHandler(this.cogDS_DoubleClick);
            // 
            // lb1
            // 
            this.lb1.BackColor = System.Drawing.Color.Black;
            this.lb1.ForeColor = System.Drawing.Color.Yellow;
            this.lb1.Location = new System.Drawing.Point(2, 2);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(234, 20);
            this.lb1.TabIndex = 0;
            this.lb1.Text = "    CAM1";
            this.lb1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbAlign1
            // 
            this.lbAlign1.BackColor = System.Drawing.Color.DimGray;
            this.lbAlign1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlign1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlign1.ForeColor = System.Drawing.Color.White;
            this.lbAlign1.Location = new System.Drawing.Point(5, 255);
            this.lbAlign1.Name = "lbAlign1";
            this.lbAlign1.Size = new System.Drawing.Size(36, 18);
            this.lbAlign1.TabIndex = 94;
            this.lbAlign1.Text = "Align";
            this.lbAlign1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbAlign1.Visible = false;
            // 
            // lblRightScore2
            // 
            this.lblRightScore2.BackColor = System.Drawing.Color.Black;
            this.lblRightScore2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRightScore2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblRightScore2.ForeColor = System.Drawing.Color.Yellow;
            this.lblRightScore2.Location = new System.Drawing.Point(239, 28);
            this.lblRightScore2.Name = "lblRightScore2";
            this.lblRightScore2.Size = new System.Drawing.Size(49, 20);
            this.lblRightScore2.TabIndex = 291;
            this.lblRightScore2.Text = "0.0";
            this.lblRightScore2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRightScore2.Visible = false;
            // 
            // pnResult1
            // 
            this.pnResult1.Controls.Add(this.gbBendResult1);
            this.pnResult1.Controls.Add(this.gbBendResult2);
            this.pnResult1.Location = new System.Drawing.Point(0, 25);
            this.pnResult1.Name = "pnResult1";
            this.pnResult1.Size = new System.Drawing.Size(523, 420);
            this.pnResult1.TabIndex = 305;
            this.pnResult1.TabStop = false;
            // 
            // gbBendResult1
            // 
            this.gbBendResult1.Controls.Add(this.dgvSpec1);
            this.gbBendResult1.Controls.Add(this.lblOFFSET0);
            this.gbBendResult1.Controls.Add(this.dgvResult1);
            this.gbBendResult1.Controls.Add(this.lbResult1Title);
            this.gbBendResult1.Controls.Add(this.label1);
            this.gbBendResult1.Controls.Add(this.label3);
            this.gbBendResult1.Controls.Add(this.label2);
            this.gbBendResult1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gbBendResult1.Location = new System.Drawing.Point(2, 12);
            this.gbBendResult1.Name = "gbBendResult1";
            this.gbBendResult1.Size = new System.Drawing.Size(257, 400);
            this.gbBendResult1.TabIndex = 260;
            this.gbBendResult1.TabStop = false;
            this.gbBendResult1.Text = "Foam Align Result";
            // 
            // lblOFFSET1
            // 
            this.lblOFFSET1.BackColor = System.Drawing.Color.Black;
            this.lblOFFSET1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOFFSET1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblOFFSET1.ForeColor = System.Drawing.Color.Yellow;
            this.lblOFFSET1.Location = new System.Drawing.Point(204, 375);
            this.lblOFFSET1.Name = "lblOFFSET1";
            this.lblOFFSET1.Size = new System.Drawing.Size(51, 20);
            this.lblOFFSET1.TabIndex = 135;
            this.lblOFFSET1.Text = "OFFSET";
            this.lblOFFSET1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.ForeColor = System.Drawing.Color.Yellow;
            this.label4.Location = new System.Drawing.Point(204, 350);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 20);
            this.label4.TabIndex = 133;
            this.label4.Text = "MAX";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvSpec1
            // 
            this.dgvSpec1.AllowUserToAddRows = false;
            this.dgvSpec1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSpec1.ColumnHeadersVisible = false;
            this.dgvSpec1.Location = new System.Drawing.Point(5, 299);
            this.dgvSpec1.Name = "dgvSpec1";
            this.dgvSpec1.ReadOnly = true;
            this.dgvSpec1.RowHeadersVisible = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            this.dgvSpec1.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSpec1.RowTemplate.Height = 23;
            this.dgvSpec1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dgvSpec1.Size = new System.Drawing.Size(194, 96);
            this.dgvSpec1.TabIndex = 134;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Black;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.ForeColor = System.Drawing.Color.Yellow;
            this.label5.Location = new System.Drawing.Point(204, 325);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 20);
            this.label5.TabIndex = 132;
            this.label5.Text = "SPEC.";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.Black;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.ForeColor = System.Drawing.Color.Yellow;
            this.label6.Location = new System.Drawing.Point(204, 300);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 20);
            this.label6.TabIndex = 131;
            this.label6.Text = "MIN";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvResult1
            // 
            this.dgvResult1.AllowUserToAddRows = false;
            this.dgvResult1.AllowUserToDeleteRows = false;
            this.dgvResult1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column28,
            this.Column15,
            this.Column5});
            this.dgvResult1.Location = new System.Drawing.Point(3, 26);
            this.dgvResult1.Name = "dgvResult1";
            this.dgvResult1.ReadOnly = true;
            this.dgvResult1.RowHeadersVisible = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.White;
            this.dgvResult1.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dgvResult1.RowTemplate.Height = 23;
            this.dgvResult1.Size = new System.Drawing.Size(250, 266);
            this.dgvResult1.TabIndex = 130;
            // 
            // Column1
            // 
            dataGridViewCellStyle2.NullValue = "0";
            this.Column1.DefaultCellStyle = dataGridViewCellStyle2;
            this.Column1.HeaderText = "LX";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column1.Width = 48;
            // 
            // Column2
            // 
            dataGridViewCellStyle3.NullValue = "0";
            this.Column2.DefaultCellStyle = dataGridViewCellStyle3;
            this.Column2.HeaderText = "LY";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column2.Width = 48;
            // 
            // Column3
            // 
            dataGridViewCellStyle4.NullValue = "0";
            this.Column3.DefaultCellStyle = dataGridViewCellStyle4;
            this.Column3.HeaderText = "RX";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column3.Width = 48;
            // 
            // Column4
            // 
            dataGridViewCellStyle5.NullValue = "0";
            this.Column4.DefaultCellStyle = dataGridViewCellStyle5;
            this.Column4.HeaderText = "RY";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column4.Width = 48;
            // 
            // Column28
            // 
            this.Column28.HeaderText = "PanelID";
            this.Column28.Name = "Column28";
            this.Column28.ReadOnly = true;
            this.Column28.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column28.Width = 200;
            // 
            // Column15
            // 
            this.Column15.HeaderText = "APNCode";
            this.Column15.Name = "Column15";
            this.Column15.ReadOnly = true;
            // 
            // Column5
            // 
            this.Column5.HeaderText = "No";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 40;
            // 
            // lbResult1Title
            // 
            this.lbResult1Title.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbResult1Title.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResult1Title.ForeColor = System.Drawing.Color.White;
            this.lbResult1Title.Location = new System.Drawing.Point(4, -2);
            this.lbResult1Title.Name = "lbResult1Title";
            this.lbResult1Title.Size = new System.Drawing.Size(250, 27);
            this.lbResult1Title.TabIndex = 129;
            this.lbResult1Title.Text = "Inspection Result";
            this.lbResult1Title.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbResult1Title.DoubleClick += new System.EventHandler(this.lbResultTitle_Click);
            // 
            // dgvSpec2
            // 
            this.dgvSpec2.AllowUserToAddRows = false;
            this.dgvSpec2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSpec2.ColumnHeadersVisible = false;
            this.dgvSpec2.Location = new System.Drawing.Point(5, 299);
            this.dgvSpec2.Name = "dgvSpec2";
            this.dgvSpec2.ReadOnly = true;
            this.dgvSpec2.RowHeadersVisible = false;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.White;
            this.dgvSpec2.RowsDefaultCellStyle = dataGridViewCellStyle12;
            this.dgvSpec2.RowTemplate.Height = 23;
            this.dgvSpec2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dgvSpec2.Size = new System.Drawing.Size(194, 96);
            this.dgvSpec2.TabIndex = 134;
            // 
            // gbBendResult2
            // 
            this.gbBendResult2.Controls.Add(this.lblOFFSET1);
            this.gbBendResult2.Controls.Add(this.label4);
            this.gbBendResult2.Controls.Add(this.dgvResult2);
            this.gbBendResult2.Controls.Add(this.label5);
            this.gbBendResult2.Controls.Add(this.label6);
            this.gbBendResult2.Controls.Add(this.dgvSpec2);
            this.gbBendResult2.Controls.Add(this.lbResult2Title);
            this.gbBendResult2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gbBendResult2.Location = new System.Drawing.Point(262, 12);
            this.gbBendResult2.Name = "gbBendResult2";
            this.gbBendResult2.Size = new System.Drawing.Size(257, 400);
            this.gbBendResult2.TabIndex = 261;
            this.gbBendResult2.TabStop = false;
            this.gbBendResult2.Text = "Foam Align Result";
            // 
            // lbResult2Title
            // 
            this.lbResult2Title.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbResult2Title.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResult2Title.ForeColor = System.Drawing.Color.White;
            this.lbResult2Title.Location = new System.Drawing.Point(4, -2);
            this.lbResult2Title.Name = "lbResult2Title";
            this.lbResult2Title.Size = new System.Drawing.Size(250, 27);
            this.lbResult2Title.TabIndex = 129;
            this.lbResult2Title.Text = "Inspection Result";
            this.lbResult2Title.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbResult2Title.DoubleClick += new System.EventHandler(this.lbResultTitle_Click);
            // 
            // btnCPKReset
            // 
            this.btnCPKReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btnCPKReset.Location = new System.Drawing.Point(128, 2);
            this.btnCPKReset.Name = "btnCPKReset";
            this.btnCPKReset.Size = new System.Drawing.Size(89, 23);
            this.btnCPKReset.TabIndex = 280;
            this.btnCPKReset.Text = "CPKReset";
            this.btnCPKReset.UseVisualStyleBackColor = true;
            this.btnCPKReset.Click += new System.EventHandler(this.btnCPK_Click);
            // 
            // lblRetryCount1
            // 
            this.lblRetryCount1.BackColor = System.Drawing.Color.Black;
            this.lblRetryCount1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRetryCount1.ForeColor = System.Drawing.Color.Yellow;
            this.lblRetryCount1.Location = new System.Drawing.Point(827, 306);
            this.lblRetryCount1.Name = "lblRetryCount1";
            this.lblRetryCount1.Size = new System.Drawing.Size(48, 20);
            this.lblRetryCount1.TabIndex = 290;
            this.lblRetryCount1.Text = "Retry";
            this.lblRetryCount1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCycleTime1
            // 
            this.lblCycleTime1.BackColor = System.Drawing.Color.Black;
            this.lblCycleTime1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCycleTime1.ForeColor = System.Drawing.Color.Yellow;
            this.lblCycleTime1.Location = new System.Drawing.Point(711, 306);
            this.lblCycleTime1.Name = "lblCycleTime1";
            this.lblCycleTime1.Size = new System.Drawing.Size(115, 20);
            this.lblCycleTime1.TabIndex = 290;
            this.lblCycleTime1.Text = "C/T";
            this.lblCycleTime1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPPID1
            // 
            this.lblPPID1.BackColor = System.Drawing.Color.Black;
            this.lblPPID1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPPID1.ForeColor = System.Drawing.Color.Yellow;
            this.lblPPID1.Location = new System.Drawing.Point(538, 306);
            this.lblPPID1.Name = "lblPPID1";
            this.lblPPID1.Size = new System.Drawing.Size(172, 20);
            this.lblPPID1.TabIndex = 290;
            this.lblPPID1.Text = "Cell ID";
            this.lblPPID1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pn8
            // 
            this.pn8.BackColor = System.Drawing.Color.Gray;
            this.pn8.Controls.Add(this.pnHeightDisp);
            this.pn8.Controls.Add(this.cbSideImageSize8);
            this.pn8.Controls.Add(this.cbLive8);
            this.pn8.Controls.Add(this.button_PLC18);
            this.pn8.Controls.Add(this.checkBox_Overlay8);
            this.pn8.Controls.Add(this.button_PLC8);
            this.pn8.Controls.Add(this.button_PC8);
            this.pn8.Controls.Add(this.lblScore8);
            this.pn8.Controls.Add(this.lblSearchResult8);
            this.pn8.Controls.Add(this.cogDS8);
            this.pn8.Controls.Add(this.lb8);
            this.pn8.Controls.Add(this.lbAlign8);
            this.pn8.Location = new System.Drawing.Point(1034, 3);
            this.pn8.Name = "pn8";
            this.pn8.Size = new System.Drawing.Size(337, 300);
            this.pn8.TabIndex = 92;
            // 
            // pnHeightDisp
            // 
            this.pnHeightDisp.BackColor = System.Drawing.Color.Black;
            this.pnHeightDisp.Controls.Add(this.pnInfo5);
            this.pnHeightDisp.Controls.Add(this.pictureBox1);
            this.pnHeightDisp.Location = new System.Drawing.Point(3, 28);
            this.pnHeightDisp.Name = "pnHeightDisp";
            this.pnHeightDisp.Size = new System.Drawing.Size(233, 224);
            this.pnHeightDisp.TabIndex = 299;
            // 
            // pnInfo5
            // 
            this.pnInfo5.Controls.Add(this.tabControl5);
            this.pnInfo5.Controls.Add(this.lblPPID5);
            this.pnInfo5.Controls.Add(this.lblCycleTime5);
            this.pnInfo5.Controls.Add(this.lblRetryCount5);
            this.pnInfo5.Location = new System.Drawing.Point(1, 275);
            this.pnInfo5.Name = "pnInfo5";
            this.pnInfo5.Size = new System.Drawing.Size(674, 141);
            this.pnInfo5.TabIndex = 312;
            // 
            // tabControl5
            // 
            this.tabControl5.Controls.Add(this.tabPage18);
            this.tabControl5.Controls.Add(this.tabPage19);
            this.tabControl5.Controls.Add(this.tabPage20);
            this.tabControl5.Location = new System.Drawing.Point(3, 23);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(665, 118);
            this.tabControl5.TabIndex = 292;
            // 
            // tabPage18
            // 
            this.tabPage18.Controls.Add(this.listBox5);
            this.tabPage18.Location = new System.Drawing.Point(4, 22);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage18.Size = new System.Drawing.Size(657, 92);
            this.tabPage18.TabIndex = 0;
            this.tabPage18.Text = "Log";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // listBox5
            // 
            this.listBox5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox5.FormattingEnabled = true;
            this.listBox5.HorizontalScrollbar = true;
            this.listBox5.ItemHeight = 12;
            this.listBox5.Location = new System.Drawing.Point(3, 3);
            this.listBox5.Name = "listBox5";
            this.listBox5.Size = new System.Drawing.Size(651, 86);
            this.listBox5.TabIndex = 132;
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.dgvAlign5);
            this.tabPage19.Location = new System.Drawing.Point(4, 22);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage19.Size = new System.Drawing.Size(657, 92);
            this.tabPage19.TabIndex = 1;
            this.tabPage19.Text = "Align";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // dgvAlign5
            // 
            this.dgvAlign5.AllowUserToAddRows = false;
            this.dgvAlign5.AllowUserToDeleteRows = false;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAlign5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgvAlign5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAlign5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn34});
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAlign5.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgvAlign5.Location = new System.Drawing.Point(3, 3);
            this.dgvAlign5.Name = "dgvAlign5";
            this.dgvAlign5.ReadOnly = true;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAlign5.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgvAlign5.RowHeadersVisible = false;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.White;
            this.dgvAlign5.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dgvAlign5.RowTemplate.Height = 23;
            this.dgvAlign5.Size = new System.Drawing.Size(664, 87);
            this.dgvAlign5.TabIndex = 133;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "CellID";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Width = 120;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.HeaderText = "LX";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn15.Width = 50;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.HeaderText = "LY";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn16.Width = 50;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.HeaderText = "RX";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn17.Width = 50;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.HeaderText = "RY";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn18.Width = 50;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.HeaderText = "X";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn19.Width = 50;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.HeaderText = "Y";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn20.Width = 50;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.HeaderText = "T";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn21.Width = 50;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.HeaderText = "Retry";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn22.Width = 40;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.HeaderText = "Score1";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Width = 50;
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.HeaderText = "Score2";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            this.dataGridViewTextBoxColumn34.Width = 50;
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.dgvError5);
            this.tabPage20.Location = new System.Drawing.Point(4, 22);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Size = new System.Drawing.Size(657, 92);
            this.tabPage20.TabIndex = 2;
            this.tabPage20.Text = "Error";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // dgvError5
            // 
            this.dgvError5.AllowUserToAddRows = false;
            this.dgvError5.AllowUserToDeleteRows = false;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvError5.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle17;
            this.dgvError5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvError5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn78,
            this.dataGridViewTextBoxColumn79});
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvError5.DefaultCellStyle = dataGridViewCellStyle18;
            this.dgvError5.Location = new System.Drawing.Point(3, 3);
            this.dgvError5.Name = "dgvError5";
            this.dgvError5.ReadOnly = true;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvError5.RowHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dgvError5.RowHeadersVisible = false;
            dataGridViewCellStyle20.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.Color.White;
            this.dgvError5.RowsDefaultCellStyle = dataGridViewCellStyle20;
            this.dgvError5.RowTemplate.Height = 23;
            this.dgvError5.Size = new System.Drawing.Size(664, 87);
            this.dgvError5.TabIndex = 134;
            // 
            // dataGridViewTextBoxColumn78
            // 
            this.dataGridViewTextBoxColumn78.HeaderText = "CellID";
            this.dataGridViewTextBoxColumn78.Name = "dataGridViewTextBoxColumn78";
            this.dataGridViewTextBoxColumn78.ReadOnly = true;
            this.dataGridViewTextBoxColumn78.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn78.Width = 170;
            // 
            // dataGridViewTextBoxColumn79
            // 
            this.dataGridViewTextBoxColumn79.HeaderText = "Error";
            this.dataGridViewTextBoxColumn79.Name = "dataGridViewTextBoxColumn79";
            this.dataGridViewTextBoxColumn79.ReadOnly = true;
            this.dataGridViewTextBoxColumn79.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn79.Width = 150;
            // 
            // lblPPID5
            // 
            this.lblPPID5.BackColor = System.Drawing.Color.Black;
            this.lblPPID5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPPID5.ForeColor = System.Drawing.Color.Yellow;
            this.lblPPID5.Location = new System.Drawing.Point(0, 0);
            this.lblPPID5.Name = "lblPPID5";
            this.lblPPID5.Size = new System.Drawing.Size(337, 20);
            this.lblPPID5.TabIndex = 290;
            this.lblPPID5.Text = "Cell ID";
            this.lblPPID5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCycleTime5
            // 
            this.lblCycleTime5.BackColor = System.Drawing.Color.Black;
            this.lblCycleTime5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCycleTime5.ForeColor = System.Drawing.Color.Yellow;
            this.lblCycleTime5.Location = new System.Drawing.Point(337, 0);
            this.lblCycleTime5.Name = "lblCycleTime5";
            this.lblCycleTime5.Size = new System.Drawing.Size(174, 20);
            this.lblCycleTime5.TabIndex = 290;
            this.lblCycleTime5.Text = "C/T";
            this.lblCycleTime5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRetryCount5
            // 
            this.lblRetryCount5.BackColor = System.Drawing.Color.Black;
            this.lblRetryCount5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRetryCount5.ForeColor = System.Drawing.Color.Yellow;
            this.lblRetryCount5.Location = new System.Drawing.Point(511, 0);
            this.lblRetryCount5.Name = "lblRetryCount5";
            this.lblRetryCount5.Size = new System.Drawing.Size(163, 20);
            this.lblRetryCount5.TabIndex = 290;
            this.lblRetryCount5.Text = "Retry";
            this.lblRetryCount5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::LaserMarking.Properties.Resources.A71;
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(671, 149);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // cbSideImageSize8
            // 
            this.cbSideImageSize8.FormattingEnabled = true;
            this.cbSideImageSize8.Items.AddRange(new object[] {
            "100%",
            "200%",
            "300%",
            "400%"});
            this.cbSideImageSize8.Location = new System.Drawing.Point(226, 277);
            this.cbSideImageSize8.Name = "cbSideImageSize8";
            this.cbSideImageSize8.Size = new System.Drawing.Size(60, 20);
            this.cbSideImageSize8.TabIndex = 298;
            // 
            // cbLive8
            // 
            this.cbLive8.ForeColor = System.Drawing.Color.White;
            this.cbLive8.Location = new System.Drawing.Point(289, 277);
            this.cbLive8.Name = "cbLive8";
            this.cbLive8.Size = new System.Drawing.Size(47, 20);
            this.cbLive8.TabIndex = 297;
            this.cbLive8.Text = "Live";
            this.cbLive8.UseVisualStyleBackColor = true;
            this.cbLive8.Visible = false;
            // 
            // button_PLC18
            // 
            this.button_PLC18.Location = new System.Drawing.Point(173, 2);
            this.button_PLC18.Name = "button_PLC18";
            this.button_PLC18.Size = new System.Drawing.Size(23, 20);
            this.button_PLC18.TabIndex = 147;
            this.button_PLC18.UseVisualStyleBackColor = true;
            // 
            // checkBox_Overlay8
            // 
            this.checkBox_Overlay8.ForeColor = System.Drawing.Color.White;
            this.checkBox_Overlay8.Location = new System.Drawing.Point(3, 280);
            this.checkBox_Overlay8.Name = "checkBox_Overlay8";
            this.checkBox_Overlay8.Size = new System.Drawing.Size(71, 20);
            this.checkBox_Overlay8.TabIndex = 144;
            this.checkBox_Overlay8.Text = "OverLay";
            this.checkBox_Overlay8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_Overlay8.UseVisualStyleBackColor = true;
            this.checkBox_Overlay8.CheckedChanged += new System.EventHandler(this.checkBox_Overlay8_CheckedChanged);
            // 
            // button_PLC8
            // 
            this.button_PLC8.Location = new System.Drawing.Point(149, 2);
            this.button_PLC8.Name = "button_PLC8";
            this.button_PLC8.Size = new System.Drawing.Size(23, 20);
            this.button_PLC8.TabIndex = 146;
            this.button_PLC8.UseVisualStyleBackColor = true;
            // 
            // button_PC8
            // 
            this.button_PC8.Location = new System.Drawing.Point(197, 2);
            this.button_PC8.Name = "button_PC8";
            this.button_PC8.Size = new System.Drawing.Size(36, 20);
            this.button_PC8.TabIndex = 145;
            this.button_PC8.Text = "0";
            this.button_PC8.UseVisualStyleBackColor = true;
            // 
            // lblScore8
            // 
            this.lblScore8.BackColor = System.Drawing.Color.Black;
            this.lblScore8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblScore8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblScore8.ForeColor = System.Drawing.Color.Yellow;
            this.lblScore8.Location = new System.Drawing.Point(239, 2);
            this.lblScore8.Name = "lblScore8";
            this.lblScore8.Size = new System.Drawing.Size(49, 20);
            this.lblScore8.TabIndex = 116;
            this.lblScore8.Text = "Score";
            this.lblScore8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSearchResult8
            // 
            this.lblSearchResult8.BackColor = System.Drawing.Color.Silver;
            this.lblSearchResult8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSearchResult8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchResult8.ForeColor = System.Drawing.Color.GreenYellow;
            this.lblSearchResult8.Location = new System.Drawing.Point(289, 0);
            this.lblSearchResult8.Name = "lblSearchResult8";
            this.lblSearchResult8.Size = new System.Drawing.Size(47, 25);
            this.lblSearchResult8.TabIndex = 115;
            this.lblSearchResult8.Text = "-";
            this.lblSearchResult8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cogDS8
            // 
            this.cogDS8.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDS8.ColorMapLowerRoiLimit = 0D;
            this.cogDS8.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDS8.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDS8.ColorMapUpperRoiLimit = 1D;
            this.cogDS8.DoubleTapZoomCycleLength = 2;
            this.cogDS8.DoubleTapZoomSensitivity = 2.5D;
            this.cogDS8.Location = new System.Drawing.Point(3, 25);
            this.cogDS8.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDS8.MouseWheelSensitivity = 1D;
            this.cogDS8.Name = "cogDS8";
            this.cogDS8.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDS8.OcxState")));
            this.cogDS8.Size = new System.Drawing.Size(334, 275);
            this.cogDS8.TabIndex = 9;
            this.cogDS8.DoubleClick += new System.EventHandler(this.cogDS_DoubleClick);
            // 
            // lb8
            // 
            this.lb8.BackColor = System.Drawing.Color.Black;
            this.lb8.ForeColor = System.Drawing.Color.Yellow;
            this.lb8.Location = new System.Drawing.Point(2, 2);
            this.lb8.Name = "lb8";
            this.lb8.Size = new System.Drawing.Size(234, 20);
            this.lb8.TabIndex = 0;
            this.lb8.Text = "    CAM1";
            this.lb8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbAlign8
            // 
            this.lbAlign8.BackColor = System.Drawing.Color.DimGray;
            this.lbAlign8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlign8.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlign8.ForeColor = System.Drawing.Color.White;
            this.lbAlign8.Location = new System.Drawing.Point(5, 255);
            this.lbAlign8.Name = "lbAlign8";
            this.lbAlign8.Size = new System.Drawing.Size(36, 18);
            this.lbAlign8.TabIndex = 94;
            this.lbAlign8.Text = "Align";
            this.lbAlign8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbAlign8.Visible = false;
            // 
            // pn6
            // 
            this.pn6.BackColor = System.Drawing.Color.Gray;
            this.pn6.Controls.Add(this.cbSideImageSize6);
            this.pn6.Controls.Add(this.cbLive6);
            this.pn6.Controls.Add(this.button_PLC16);
            this.pn6.Controls.Add(this.button_PLC6);
            this.pn6.Controls.Add(this.button_PC6);
            this.pn6.Controls.Add(this.lblScore6);
            this.pn6.Controls.Add(this.checkBox_Overlay6);
            this.pn6.Controls.Add(this.lblSearchResult6);
            this.pn6.Controls.Add(this.cogDS6);
            this.pn6.Controls.Add(this.lb6);
            this.pn6.Controls.Add(this.lbAlign6);
            this.pn6.Location = new System.Drawing.Point(348, 2);
            this.pn6.Name = "pn6";
            this.pn6.Size = new System.Drawing.Size(337, 300);
            this.pn6.TabIndex = 93;
            // 
            // cbSideImageSize6
            // 
            this.cbSideImageSize6.FormattingEnabled = true;
            this.cbSideImageSize6.Items.AddRange(new object[] {
            "100%",
            "200%",
            "300%",
            "400%"});
            this.cbSideImageSize6.Location = new System.Drawing.Point(226, 277);
            this.cbSideImageSize6.Name = "cbSideImageSize6";
            this.cbSideImageSize6.Size = new System.Drawing.Size(60, 20);
            this.cbSideImageSize6.TabIndex = 298;
            // 
            // cbLive6
            // 
            this.cbLive6.ForeColor = System.Drawing.Color.White;
            this.cbLive6.Location = new System.Drawing.Point(289, 277);
            this.cbLive6.Name = "cbLive6";
            this.cbLive6.Size = new System.Drawing.Size(47, 20);
            this.cbLive6.TabIndex = 297;
            this.cbLive6.Text = "Live";
            this.cbLive6.UseVisualStyleBackColor = true;
            this.cbLive6.Visible = false;
            // 
            // button_PLC16
            // 
            this.button_PLC16.Location = new System.Drawing.Point(173, 2);
            this.button_PLC16.Name = "button_PLC16";
            this.button_PLC16.Size = new System.Drawing.Size(23, 20);
            this.button_PLC16.TabIndex = 139;
            this.button_PLC16.UseVisualStyleBackColor = true;
            // 
            // button_PLC6
            // 
            this.button_PLC6.Location = new System.Drawing.Point(149, 2);
            this.button_PLC6.Name = "button_PLC6";
            this.button_PLC6.Size = new System.Drawing.Size(23, 20);
            this.button_PLC6.TabIndex = 138;
            this.button_PLC6.UseVisualStyleBackColor = true;
            // 
            // button_PC6
            // 
            this.button_PC6.Location = new System.Drawing.Point(197, 2);
            this.button_PC6.Name = "button_PC6";
            this.button_PC6.Size = new System.Drawing.Size(36, 20);
            this.button_PC6.TabIndex = 137;
            this.button_PC6.Text = "0";
            this.button_PC6.UseVisualStyleBackColor = true;
            // 
            // lblScore6
            // 
            this.lblScore6.BackColor = System.Drawing.Color.Black;
            this.lblScore6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblScore6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblScore6.ForeColor = System.Drawing.Color.Yellow;
            this.lblScore6.Location = new System.Drawing.Point(239, 2);
            this.lblScore6.Name = "lblScore6";
            this.lblScore6.Size = new System.Drawing.Size(49, 20);
            this.lblScore6.TabIndex = 116;
            this.lblScore6.Text = "Score";
            this.lblScore6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox_Overlay6
            // 
            this.checkBox_Overlay6.ForeColor = System.Drawing.Color.White;
            this.checkBox_Overlay6.Location = new System.Drawing.Point(3, 280);
            this.checkBox_Overlay6.Name = "checkBox_Overlay6";
            this.checkBox_Overlay6.Size = new System.Drawing.Size(71, 20);
            this.checkBox_Overlay6.TabIndex = 136;
            this.checkBox_Overlay6.Text = "OverLay";
            this.checkBox_Overlay6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_Overlay6.UseVisualStyleBackColor = true;
            this.checkBox_Overlay6.CheckedChanged += new System.EventHandler(this.checkBox_Overlay6_CheckedChanged);
            // 
            // lblSearchResult6
            // 
            this.lblSearchResult6.BackColor = System.Drawing.Color.Silver;
            this.lblSearchResult6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSearchResult6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchResult6.ForeColor = System.Drawing.Color.GreenYellow;
            this.lblSearchResult6.Location = new System.Drawing.Point(289, 0);
            this.lblSearchResult6.Name = "lblSearchResult6";
            this.lblSearchResult6.Size = new System.Drawing.Size(47, 25);
            this.lblSearchResult6.TabIndex = 115;
            this.lblSearchResult6.Text = "-";
            this.lblSearchResult6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cogDS6
            // 
            this.cogDS6.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDS6.ColorMapLowerRoiLimit = 0D;
            this.cogDS6.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDS6.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDS6.ColorMapUpperRoiLimit = 1D;
            this.cogDS6.DoubleTapZoomCycleLength = 2;
            this.cogDS6.DoubleTapZoomSensitivity = 2.5D;
            this.cogDS6.Location = new System.Drawing.Point(3, 24);
            this.cogDS6.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDS6.MouseWheelSensitivity = 1D;
            this.cogDS6.Name = "cogDS6";
            this.cogDS6.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDS6.OcxState")));
            this.cogDS6.Size = new System.Drawing.Size(334, 275);
            this.cogDS6.TabIndex = 9;
            this.cogDS6.DoubleClick += new System.EventHandler(this.cogDS_DoubleClick);
            // 
            // lb6
            // 
            this.lb6.BackColor = System.Drawing.Color.Black;
            this.lb6.ForeColor = System.Drawing.Color.Yellow;
            this.lb6.Location = new System.Drawing.Point(2, 2);
            this.lb6.Name = "lb6";
            this.lb6.Size = new System.Drawing.Size(234, 20);
            this.lb6.TabIndex = 0;
            this.lb6.Text = "    CAM1";
            this.lb6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbAlign6
            // 
            this.lbAlign6.BackColor = System.Drawing.Color.DimGray;
            this.lbAlign6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlign6.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlign6.ForeColor = System.Drawing.Color.White;
            this.lbAlign6.Location = new System.Drawing.Point(5, 255);
            this.lbAlign6.Name = "lbAlign6";
            this.lbAlign6.Size = new System.Drawing.Size(36, 18);
            this.lbAlign6.TabIndex = 94;
            this.lbAlign6.Text = "Align";
            this.lbAlign6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbAlign6.Visible = false;
            // 
            // dgvOKNG
            // 
            this.dgvOKNG.AllowUserToAddRows = false;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOKNG.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.dgvOKNG.ColumnHeadersHeight = 60;
            this.dgvOKNG.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column13,
            this.Column6,
            this.Column8,
            this.Column9,
            this.Column10,
            this.Column11,
            this.Column12});
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvOKNG.DefaultCellStyle = dataGridViewCellStyle22;
            this.dgvOKNG.Location = new System.Drawing.Point(2, 69);
            this.dgvOKNG.Name = "dgvOKNG";
            this.dgvOKNG.ReadOnly = true;
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOKNG.RowHeadersDefaultCellStyle = dataGridViewCellStyle23;
            this.dgvOKNG.RowHeadersWidth = 127;
            this.dgvOKNG.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvOKNG.Size = new System.Drawing.Size(522, 376);
            this.dgvOKNG.TabIndex = 296;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "OK";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column7.Width = 47;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Find Error";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column13.Width = 47;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Limit Over";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column6.Width = 47;
            // 
            // Column8
            // 
            this.Column8.HeaderText = "Size Over";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column8.Width = 47;
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Retry Over";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column9.Width = 47;
            // 
            // Column10
            // 
            this.Column10.HeaderText = "Find Line NG";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            this.Column10.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column10.Width = 52;
            // 
            // Column11
            // 
            this.Column11.HeaderText = "Attach Insp NG";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column11.Width = 52;
            // 
            // Column12
            // 
            this.Column12.HeaderText = "Inspection NG";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column12.Width = 52;
            // 
            // pn5
            // 
            this.pn5.BackColor = System.Drawing.Color.Gray;
            this.pn5.Controls.Add(this.cbSideImageSize5);
            this.pn5.Controls.Add(this.cbLive5);
            this.pn5.Controls.Add(this.lblRightScore2);
            this.pn5.Controls.Add(this.button_PLC15);
            this.pn5.Controls.Add(this.button_PLC5);
            this.pn5.Controls.Add(this.button_PC5);
            this.pn5.Controls.Add(this.checkBox_Overlay5);
            this.pn5.Controls.Add(this.lblScore5);
            this.pn5.Controls.Add(this.lblSearchResult5);
            this.pn5.Controls.Add(this.cogDS5);
            this.pn5.Controls.Add(this.lb5);
            this.pn5.Location = new System.Drawing.Point(8, 7);
            this.pn5.Name = "pn5";
            this.pn5.Size = new System.Drawing.Size(337, 300);
            this.pn5.TabIndex = 91;
            // 
            // cbSideImageSize5
            // 
            this.cbSideImageSize5.FormattingEnabled = true;
            this.cbSideImageSize5.Items.AddRange(new object[] {
            "100%",
            "200%",
            "300%",
            "400%"});
            this.cbSideImageSize5.Location = new System.Drawing.Point(226, 279);
            this.cbSideImageSize5.Name = "cbSideImageSize5";
            this.cbSideImageSize5.Size = new System.Drawing.Size(60, 20);
            this.cbSideImageSize5.TabIndex = 298;
            // 
            // cbLive5
            // 
            this.cbLive5.ForeColor = System.Drawing.Color.White;
            this.cbLive5.Location = new System.Drawing.Point(289, 279);
            this.cbLive5.Name = "cbLive5";
            this.cbLive5.Size = new System.Drawing.Size(47, 20);
            this.cbLive5.TabIndex = 297;
            this.cbLive5.Text = "Live";
            this.cbLive5.UseVisualStyleBackColor = true;
            this.cbLive5.Visible = false;
            // 
            // button_PLC15
            // 
            this.button_PLC15.Location = new System.Drawing.Point(173, 2);
            this.button_PLC15.Name = "button_PLC15";
            this.button_PLC15.Size = new System.Drawing.Size(23, 20);
            this.button_PLC15.TabIndex = 135;
            this.button_PLC15.UseVisualStyleBackColor = true;
            // 
            // button_PLC5
            // 
            this.button_PLC5.Location = new System.Drawing.Point(149, 2);
            this.button_PLC5.Name = "button_PLC5";
            this.button_PLC5.Size = new System.Drawing.Size(23, 20);
            this.button_PLC5.TabIndex = 134;
            this.button_PLC5.UseVisualStyleBackColor = true;
            // 
            // button_PC5
            // 
            this.button_PC5.Location = new System.Drawing.Point(197, 2);
            this.button_PC5.Name = "button_PC5";
            this.button_PC5.Size = new System.Drawing.Size(36, 20);
            this.button_PC5.TabIndex = 133;
            this.button_PC5.Text = "0";
            this.button_PC5.UseVisualStyleBackColor = true;
            // 
            // checkBox_Overlay5
            // 
            this.checkBox_Overlay5.ForeColor = System.Drawing.Color.White;
            this.checkBox_Overlay5.Location = new System.Drawing.Point(0, 280);
            this.checkBox_Overlay5.Name = "checkBox_Overlay5";
            this.checkBox_Overlay5.Size = new System.Drawing.Size(71, 20);
            this.checkBox_Overlay5.TabIndex = 132;
            this.checkBox_Overlay5.Text = "OverLay";
            this.checkBox_Overlay5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_Overlay5.UseVisualStyleBackColor = true;
            this.checkBox_Overlay5.CheckedChanged += new System.EventHandler(this.checkBox_Overlay5_CheckedChanged);
            // 
            // lblScore5
            // 
            this.lblScore5.BackColor = System.Drawing.Color.Black;
            this.lblScore5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblScore5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblScore5.ForeColor = System.Drawing.Color.Yellow;
            this.lblScore5.Location = new System.Drawing.Point(239, 2);
            this.lblScore5.Name = "lblScore5";
            this.lblScore5.Size = new System.Drawing.Size(49, 20);
            this.lblScore5.TabIndex = 116;
            this.lblScore5.Text = "Score";
            this.lblScore5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSearchResult5
            // 
            this.lblSearchResult5.BackColor = System.Drawing.Color.Silver;
            this.lblSearchResult5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSearchResult5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchResult5.ForeColor = System.Drawing.Color.GreenYellow;
            this.lblSearchResult5.Location = new System.Drawing.Point(289, 0);
            this.lblSearchResult5.Name = "lblSearchResult5";
            this.lblSearchResult5.Size = new System.Drawing.Size(47, 25);
            this.lblSearchResult5.TabIndex = 115;
            this.lblSearchResult5.Text = "-";
            this.lblSearchResult5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cogDS5
            // 
            this.cogDS5.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDS5.ColorMapLowerRoiLimit = 0D;
            this.cogDS5.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDS5.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDS5.ColorMapUpperRoiLimit = 1D;
            this.cogDS5.DoubleTapZoomCycleLength = 2;
            this.cogDS5.DoubleTapZoomSensitivity = 2.5D;
            this.cogDS5.Location = new System.Drawing.Point(3, 25);
            this.cogDS5.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDS5.MouseWheelSensitivity = 1D;
            this.cogDS5.Name = "cogDS5";
            this.cogDS5.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDS5.OcxState")));
            this.cogDS5.Size = new System.Drawing.Size(334, 275);
            this.cogDS5.TabIndex = 9;
            this.cogDS5.DoubleClick += new System.EventHandler(this.cogDS_DoubleClick);
            // 
            // lb5
            // 
            this.lb5.BackColor = System.Drawing.Color.Black;
            this.lb5.ForeColor = System.Drawing.Color.Yellow;
            this.lb5.Location = new System.Drawing.Point(2, 2);
            this.lb5.Name = "lb5";
            this.lb5.Size = new System.Drawing.Size(234, 20);
            this.lb5.TabIndex = 0;
            this.lb5.Text = "    CAM1";
            this.lb5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pngraph
            // 
            this.pngraph.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pngraph.Controls.Add(this.pnGrahpData);
            this.pngraph.Controls.Add(this.tcGraph);
            this.pngraph.Location = new System.Drawing.Point(1, 451);
            this.pngraph.Name = "pngraph";
            this.pngraph.Size = new System.Drawing.Size(529, 409);
            this.pngraph.TabIndex = 257;
            // 
            // pnGrahpData
            // 
            this.pnGrahpData.BackColor = System.Drawing.Color.Black;
            this.pnGrahpData.Controls.Add(this.btnClearDisp);
            this.pnGrahpData.Controls.Add(this.btnDispReset);
            this.pnGrahpData.Controls.Add(this.dtpStart);
            this.pnGrahpData.Controls.Add(this.btnDisp1);
            this.pnGrahpData.Controls.Add(this.dtpEnd);
            this.pnGrahpData.Controls.Add(this.label8);
            this.pnGrahpData.Controls.Add(this.label9);
            this.pnGrahpData.Controls.Add(this.label10);
            this.pnGrahpData.Location = new System.Drawing.Point(1, 6);
            this.pnGrahpData.Name = "pnGrahpData";
            this.pnGrahpData.Size = new System.Drawing.Size(528, 40);
            this.pnGrahpData.TabIndex = 306;
            // 
            // btnClearDisp
            // 
            this.btnClearDisp.Location = new System.Drawing.Point(389, 15);
            this.btnClearDisp.Name = "btnClearDisp";
            this.btnClearDisp.Size = new System.Drawing.Size(61, 23);
            this.btnClearDisp.TabIndex = 280;
            this.btnClearDisp.Text = "Clear";
            this.btnClearDisp.UseVisualStyleBackColor = true;
            this.btnClearDisp.Click += new System.EventHandler(this.btnClearDisp_Click);
            // 
            // btnDispReset
            // 
            this.btnDispReset.Location = new System.Drawing.Point(389, 15);
            this.btnDispReset.Name = "btnDispReset";
            this.btnDispReset.Size = new System.Drawing.Size(61, 23);
            this.btnDispReset.TabIndex = 279;
            this.btnDispReset.Text = "Remove";
            this.btnDispReset.UseVisualStyleBackColor = true;
            this.btnDispReset.Visible = false;
            this.btnDispReset.Click += new System.EventHandler(this.btnDispReset_Click);
            // 
            // dtpStart
            // 
            this.dtpStart.Location = new System.Drawing.Point(3, 18);
            this.dtpStart.Name = "dtpStart";
            this.dtpStart.Size = new System.Drawing.Size(170, 21);
            this.dtpStart.TabIndex = 273;
            // 
            // btnDisp1
            // 
            this.btnDisp1.Location = new System.Drawing.Point(456, 15);
            this.btnDisp1.Name = "btnDisp1";
            this.btnDisp1.Size = new System.Drawing.Size(61, 23);
            this.btnDisp1.TabIndex = 272;
            this.btnDisp1.Text = "Display";
            this.btnDisp1.UseVisualStyleBackColor = true;
            this.btnDisp1.Click += new System.EventHandler(this.btnDisp1_Click);
            // 
            // dtpEnd
            // 
            this.dtpEnd.Location = new System.Drawing.Point(209, 18);
            this.dtpEnd.Name = "dtpEnd";
            this.dtpEnd.Size = new System.Drawing.Size(170, 21);
            this.dtpEnd.TabIndex = 274;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(3, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 12);
            this.label8.TabIndex = 276;
            this.label8.Text = "START";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(246, 2);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 12);
            this.label9.TabIndex = 277;
            this.label9.Text = "END";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(185, 25);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 12);
            this.label10.TabIndex = 278;
            this.label10.Text = "~";
            // 
            // tcGraph
            // 
            this.tcGraph.Controls.Add(this.tabPage1);
            this.tcGraph.Controls.Add(this.tabPage2);
            this.tcGraph.Controls.Add(this.tabPage3);
            this.tcGraph.Controls.Add(this.tabPage4);
            this.tcGraph.Location = new System.Drawing.Point(1, 52);
            this.tcGraph.Name = "tcGraph";
            this.tcGraph.Padding = new System.Drawing.Point(20, 5);
            this.tcGraph.SelectedIndex = 0;
            this.tcGraph.Size = new System.Drawing.Size(524, 369);
            this.tcGraph.TabIndex = 294;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.pnSquareLength);
            this.tabPage1.Controls.Add(this.lblSpecOut1_4);
            this.tabPage1.Controls.Add(this.lblSpecOut1_3);
            this.tabPage1.Controls.Add(this.ct1_Yspec1_4);
            this.tabPage1.Controls.Add(this.ct1_Yspec1_3);
            this.tabPage1.Controls.Add(this.ct1_Xspec1_4);
            this.tabPage1.Controls.Add(this.ct1_Xspec1_3);
            this.tabPage1.Controls.Add(this.ctDisp1_4);
            this.tabPage1.Controls.Add(this.ctDisp1_3);
            this.tabPage1.Controls.Add(this.lblSpecOut1_2);
            this.tabPage1.Controls.Add(this.lblSpecOut1_1);
            this.tabPage1.Controls.Add(this.ct1_Yspec1_2);
            this.tabPage1.Controls.Add(this.ct1_Xspec1_2);
            this.tabPage1.Controls.Add(this.ct1_Yspec1_1);
            this.tabPage1.Controls.Add(this.ct1_Xspec1_1);
            this.tabPage1.Controls.Add(this.ctDisp1_2);
            this.tabPage1.Controls.Add(this.ctDisp1_1);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(516, 339);
            this.tabPage1.TabIndex = 2;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // pnSquareLength
            // 
            this.pnSquareLength.Controls.Add(this.label13);
            this.pnSquareLength.Controls.Add(this.label7);
            this.pnSquareLength.Controls.Add(this.txtSuareX1);
            this.pnSquareLength.Controls.Add(this.txtSuareY1);
            this.pnSquareLength.Location = new System.Drawing.Point(412, 0);
            this.pnSquareLength.Name = "pnSquareLength";
            this.pnSquareLength.Size = new System.Drawing.Size(103, 54);
            this.pnSquareLength.TabIndex = 319;
            this.pnSquareLength.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Location = new System.Drawing.Point(1, 8);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 12);
            this.label13.TabIndex = 317;
            this.label13.Text = "SquareX";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 12);
            this.label7.TabIndex = 318;
            this.label7.Text = "SquareY";
            // 
            // txtSuareX1
            // 
            this.txtSuareX1.Location = new System.Drawing.Point(57, 3);
            this.txtSuareX1.Name = "txtSuareX1";
            this.txtSuareX1.Size = new System.Drawing.Size(41, 21);
            this.txtSuareX1.TabIndex = 315;
            this.txtSuareX1.Text = "0";
            // 
            // txtSuareY1
            // 
            this.txtSuareY1.Location = new System.Drawing.Point(57, 30);
            this.txtSuareY1.Name = "txtSuareY1";
            this.txtSuareY1.Size = new System.Drawing.Size(41, 21);
            this.txtSuareY1.TabIndex = 316;
            this.txtSuareY1.Text = "0";
            // 
            // lblSpecOut1_4
            // 
            this.lblSpecOut1_4.AutoSize = true;
            this.lblSpecOut1_4.Location = new System.Drawing.Point(352, 548);
            this.lblSpecOut1_4.Name = "lblSpecOut1_4";
            this.lblSpecOut1_4.Size = new System.Drawing.Size(23, 12);
            this.lblSpecOut1_4.TabIndex = 314;
            this.lblSpecOut1_4.Text = "NG";
            // 
            // lblSpecOut1_3
            // 
            this.lblSpecOut1_3.AutoSize = true;
            this.lblSpecOut1_3.Location = new System.Drawing.Point(104, 548);
            this.lblSpecOut1_3.Name = "lblSpecOut1_3";
            this.lblSpecOut1_3.Size = new System.Drawing.Size(23, 12);
            this.lblSpecOut1_3.TabIndex = 313;
            this.lblSpecOut1_3.Text = "NG";
            // 
            // ct1_Yspec1_4
            // 
            this.ct1_Yspec1_4.AutoSize = true;
            this.ct1_Yspec1_4.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct1_Yspec1_4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct1_Yspec1_4.Location = new System.Drawing.Point(468, 390);
            this.ct1_Yspec1_4.Name = "ct1_Yspec1_4";
            this.ct1_Yspec1_4.Size = new System.Drawing.Size(14, 14);
            this.ct1_Yspec1_4.TabIndex = 312;
            this.ct1_Yspec1_4.Text = "1";
            // 
            // ct1_Yspec1_3
            // 
            this.ct1_Yspec1_3.AutoSize = true;
            this.ct1_Yspec1_3.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct1_Yspec1_3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct1_Yspec1_3.Location = new System.Drawing.Point(218, 390);
            this.ct1_Yspec1_3.Name = "ct1_Yspec1_3";
            this.ct1_Yspec1_3.Size = new System.Drawing.Size(14, 14);
            this.ct1_Yspec1_3.TabIndex = 311;
            this.ct1_Yspec1_3.Text = "1";
            // 
            // ct1_Xspec1_4
            // 
            this.ct1_Xspec1_4.AutoSize = true;
            this.ct1_Xspec1_4.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct1_Xspec1_4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct1_Xspec1_4.Location = new System.Drawing.Point(391, 307);
            this.ct1_Xspec1_4.Name = "ct1_Xspec1_4";
            this.ct1_Xspec1_4.Size = new System.Drawing.Size(14, 14);
            this.ct1_Xspec1_4.TabIndex = 310;
            this.ct1_Xspec1_4.Text = "1";
            this.ct1_Xspec1_4.Visible = false;
            // 
            // ct1_Xspec1_3
            // 
            this.ct1_Xspec1_3.AutoSize = true;
            this.ct1_Xspec1_3.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct1_Xspec1_3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct1_Xspec1_3.Location = new System.Drawing.Point(127, 307);
            this.ct1_Xspec1_3.Name = "ct1_Xspec1_3";
            this.ct1_Xspec1_3.Size = new System.Drawing.Size(14, 14);
            this.ct1_Xspec1_3.TabIndex = 309;
            this.ct1_Xspec1_3.Text = "1";
            this.ct1_Xspec1_3.Visible = false;
            // 
            // ctDisp1_4
            // 
            this.ctDisp1_4.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.ctDisp1_4.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea1.AxisX.Interval = 0.05D;
            chartArea1.AxisX.IsMarginVisible = false;
            chartArea1.AxisX.LabelStyle.Format = "{0:0.00}";
            chartArea1.AxisX.MajorGrid.Interval = 0.1D;
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea1.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea1.AxisX.Maximum = 0.3D;
            chartArea1.AxisX.Minimum = -0.3D;
            chartArea1.AxisY.Interval = 0.05D;
            chartArea1.AxisY.IsMarginVisible = false;
            chartArea1.AxisY.LabelStyle.Format = "{0:0.00}";
            chartArea1.AxisY.MajorGrid.Interval = 0.1D;
            chartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea1.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea1.AxisY.Maximum = 0.3D;
            chartArea1.AxisY.Minimum = -0.3D;
            chartArea1.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.Name = "ChartArea1";
            chartArea1.Position.Auto = false;
            chartArea1.Position.Height = 94F;
            chartArea1.Position.Width = 94F;
            chartArea1.Position.X = 3F;
            chartArea1.Position.Y = 3F;
            this.ctDisp1_4.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.ctDisp1_4.Legends.Add(legend1);
            this.ctDisp1_4.Location = new System.Drawing.Point(259, 300);
            this.ctDisp1_4.Name = "ctDisp1_4";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series1.Legend = "Legend1";
            series1.MarkerColor = System.Drawing.Color.DarkGreen;
            series1.Name = "Series1";
            this.ctDisp1_4.Series.Add(series1);
            this.ctDisp1_4.Size = new System.Drawing.Size(253, 229);
            this.ctDisp1_4.TabIndex = 308;
            this.ctDisp1_4.Text = "chart1";
            this.ctDisp1_4.Visible = false;
            this.ctDisp1_4.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDoubleClick);
            // 
            // ctDisp1_3
            // 
            this.ctDisp1_3.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.ctDisp1_3.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea2.AxisX.Interval = 0.05D;
            chartArea2.AxisX.IsMarginVisible = false;
            chartArea2.AxisX.LabelStyle.Format = "{0:0.00}";
            chartArea2.AxisX.MajorGrid.Interval = 0.1D;
            chartArea2.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea2.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea2.AxisX.Maximum = 4.2D;
            chartArea2.AxisX.Minimum = 3.9D;
            chartArea2.AxisY.Interval = 0.05D;
            chartArea2.AxisY.IsMarginVisible = false;
            chartArea2.AxisY.LabelStyle.Format = "{0:0.00}";
            chartArea2.AxisY.MajorGrid.Interval = 0.1D;
            chartArea2.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea2.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea2.AxisY.Maximum = 1.6D;
            chartArea2.AxisY.Minimum = 1.2D;
            chartArea2.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.Name = "ChartArea1";
            chartArea2.Position.Auto = false;
            chartArea2.Position.Height = 94F;
            chartArea2.Position.Width = 94F;
            chartArea2.Position.X = 3F;
            chartArea2.Position.Y = 3F;
            this.ctDisp1_3.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.ctDisp1_3.Legends.Add(legend2);
            this.ctDisp1_3.Location = new System.Drawing.Point(4, 300);
            this.ctDisp1_3.Name = "ctDisp1_3";
            this.ctDisp1_3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series2.Legend = "Legend1";
            series2.MarkerColor = System.Drawing.Color.DarkGreen;
            series2.Name = "Series1";
            this.ctDisp1_3.Series.Add(series2);
            this.ctDisp1_3.Size = new System.Drawing.Size(253, 229);
            this.ctDisp1_3.TabIndex = 307;
            this.ctDisp1_3.Text = "chart1";
            this.ctDisp1_3.Visible = false;
            this.ctDisp1_3.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDoubleClick);
            // 
            // lblSpecOut1_2
            // 
            this.lblSpecOut1_2.AutoSize = true;
            this.lblSpecOut1_2.Location = new System.Drawing.Point(352, 288);
            this.lblSpecOut1_2.Name = "lblSpecOut1_2";
            this.lblSpecOut1_2.Size = new System.Drawing.Size(23, 12);
            this.lblSpecOut1_2.TabIndex = 303;
            this.lblSpecOut1_2.Text = "NG";
            // 
            // lblSpecOut1_1
            // 
            this.lblSpecOut1_1.AutoSize = true;
            this.lblSpecOut1_1.Location = new System.Drawing.Point(104, 288);
            this.lblSpecOut1_1.Name = "lblSpecOut1_1";
            this.lblSpecOut1_1.Size = new System.Drawing.Size(23, 12);
            this.lblSpecOut1_1.TabIndex = 302;
            this.lblSpecOut1_1.Text = "NG";
            // 
            // ct1_Yspec1_2
            // 
            this.ct1_Yspec1_2.AutoSize = true;
            this.ct1_Yspec1_2.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct1_Yspec1_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct1_Yspec1_2.Location = new System.Drawing.Point(468, 130);
            this.ct1_Yspec1_2.Name = "ct1_Yspec1_2";
            this.ct1_Yspec1_2.Size = new System.Drawing.Size(14, 14);
            this.ct1_Yspec1_2.TabIndex = 292;
            this.ct1_Yspec1_2.Text = "1";
            // 
            // ct1_Xspec1_2
            // 
            this.ct1_Xspec1_2.AutoSize = true;
            this.ct1_Xspec1_2.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct1_Xspec1_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct1_Xspec1_2.Location = new System.Drawing.Point(391, 47);
            this.ct1_Xspec1_2.Name = "ct1_Xspec1_2";
            this.ct1_Xspec1_2.Size = new System.Drawing.Size(14, 14);
            this.ct1_Xspec1_2.TabIndex = 291;
            this.ct1_Xspec1_2.Text = "1";
            // 
            // ct1_Yspec1_1
            // 
            this.ct1_Yspec1_1.AutoSize = true;
            this.ct1_Yspec1_1.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct1_Yspec1_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct1_Yspec1_1.Location = new System.Drawing.Point(218, 130);
            this.ct1_Yspec1_1.Name = "ct1_Yspec1_1";
            this.ct1_Yspec1_1.Size = new System.Drawing.Size(14, 14);
            this.ct1_Yspec1_1.TabIndex = 290;
            this.ct1_Yspec1_1.Text = "1";
            // 
            // ct1_Xspec1_1
            // 
            this.ct1_Xspec1_1.AutoSize = true;
            this.ct1_Xspec1_1.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct1_Xspec1_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct1_Xspec1_1.Location = new System.Drawing.Point(127, 47);
            this.ct1_Xspec1_1.Name = "ct1_Xspec1_1";
            this.ct1_Xspec1_1.Size = new System.Drawing.Size(14, 14);
            this.ct1_Xspec1_1.TabIndex = 289;
            this.ct1_Xspec1_1.Text = "1";
            // 
            // ctDisp1_2
            // 
            this.ctDisp1_2.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.ctDisp1_2.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea3.AxisX.Interval = 0.05D;
            chartArea3.AxisX.IsMarginVisible = false;
            chartArea3.AxisX.LabelStyle.Format = "{0:0.00}";
            chartArea3.AxisX.MajorGrid.Interval = 0.1D;
            chartArea3.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea3.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea3.AxisX.Maximum = 0.3D;
            chartArea3.AxisX.Minimum = -0.3D;
            chartArea3.AxisY.Interval = 0.05D;
            chartArea3.AxisY.IsMarginVisible = false;
            chartArea3.AxisY.LabelStyle.Format = "{0:0.00}";
            chartArea3.AxisY.MajorGrid.Interval = 0.1D;
            chartArea3.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea3.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea3.AxisY.Maximum = 0.3D;
            chartArea3.AxisY.Minimum = -0.3D;
            chartArea3.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea3.Name = "ChartArea1";
            chartArea3.Position.Auto = false;
            chartArea3.Position.Height = 94F;
            chartArea3.Position.Width = 94F;
            chartArea3.Position.X = 3F;
            chartArea3.Position.Y = 3F;
            this.ctDisp1_2.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.ctDisp1_2.Legends.Add(legend3);
            this.ctDisp1_2.Location = new System.Drawing.Point(259, 47);
            this.ctDisp1_2.Name = "ctDisp1_2";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series3.Legend = "Legend1";
            series3.MarkerColor = System.Drawing.Color.DarkGreen;
            series3.Name = "Series1";
            this.ctDisp1_2.Series.Add(series3);
            this.ctDisp1_2.Size = new System.Drawing.Size(253, 229);
            this.ctDisp1_2.TabIndex = 288;
            this.ctDisp1_2.Text = "chart1";
            this.ctDisp1_2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDoubleClick);
            // 
            // ctDisp1_1
            // 
            this.ctDisp1_1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.ctDisp1_1.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea4.AxisX.Interval = 0.05D;
            chartArea4.AxisX.IsMarginVisible = false;
            chartArea4.AxisX.LabelStyle.Format = "{0:0.00}";
            chartArea4.AxisX.MajorGrid.Interval = 0.1D;
            chartArea4.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea4.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea4.AxisX.Maximum = 4.2D;
            chartArea4.AxisX.Minimum = 3.9D;
            chartArea4.AxisY.Interval = 0.05D;
            chartArea4.AxisY.IsMarginVisible = false;
            chartArea4.AxisY.LabelStyle.Format = "{0:0.00}";
            chartArea4.AxisY.MajorGrid.Interval = 0.1D;
            chartArea4.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea4.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea4.AxisY.Maximum = 1.6D;
            chartArea4.AxisY.Minimum = 1.2D;
            chartArea4.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea4.Name = "ChartArea1";
            chartArea4.Position.Auto = false;
            chartArea4.Position.Height = 94F;
            chartArea4.Position.Width = 94F;
            chartArea4.Position.X = 3F;
            chartArea4.Position.Y = 3F;
            this.ctDisp1_1.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.ctDisp1_1.Legends.Add(legend4);
            this.ctDisp1_1.Location = new System.Drawing.Point(4, 47);
            this.ctDisp1_1.Name = "ctDisp1_1";
            this.ctDisp1_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series4.Legend = "Legend1";
            series4.MarkerColor = System.Drawing.Color.DarkGreen;
            series4.Name = "Series1";
            this.ctDisp1_1.Series.Add(series4);
            this.ctDisp1_1.Size = new System.Drawing.Size(253, 229);
            this.ctDisp1_1.TabIndex = 287;
            this.ctDisp1_1.Text = "chart1";
            this.ctDisp1_1.Click += new System.EventHandler(this.ctDisp1_1_Click);
            this.ctDisp1_1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDoubleClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lblSpecOut2_2);
            this.tabPage2.Controls.Add(this.lblSpecOut2_1);
            this.tabPage2.Controls.Add(this.ct2_YSpec2_2);
            this.tabPage2.Controls.Add(this.ct2_XSpec2_2);
            this.tabPage2.Controls.Add(this.ct2_YSpec2_1);
            this.tabPage2.Controls.Add(this.ct2_XSpec2_1);
            this.tabPage2.Controls.Add(this.ctDisp2_2);
            this.tabPage2.Controls.Add(this.ctDisp2_1);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(516, 339);
            this.tabPage2.TabIndex = 4;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblSpecOut2_2
            // 
            this.lblSpecOut2_2.AutoSize = true;
            this.lblSpecOut2_2.Location = new System.Drawing.Point(352, 288);
            this.lblSpecOut2_2.Name = "lblSpecOut2_2";
            this.lblSpecOut2_2.Size = new System.Drawing.Size(23, 12);
            this.lblSpecOut2_2.TabIndex = 303;
            this.lblSpecOut2_2.Text = "NG";
            // 
            // lblSpecOut2_1
            // 
            this.lblSpecOut2_1.AutoSize = true;
            this.lblSpecOut2_1.Location = new System.Drawing.Point(104, 288);
            this.lblSpecOut2_1.Name = "lblSpecOut2_1";
            this.lblSpecOut2_1.Size = new System.Drawing.Size(23, 12);
            this.lblSpecOut2_1.TabIndex = 302;
            this.lblSpecOut2_1.Text = "NG";
            // 
            // ct2_YSpec2_2
            // 
            this.ct2_YSpec2_2.AutoSize = true;
            this.ct2_YSpec2_2.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct2_YSpec2_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct2_YSpec2_2.Location = new System.Drawing.Point(468, 130);
            this.ct2_YSpec2_2.Name = "ct2_YSpec2_2";
            this.ct2_YSpec2_2.Size = new System.Drawing.Size(0, 14);
            this.ct2_YSpec2_2.TabIndex = 297;
            // 
            // ct2_XSpec2_2
            // 
            this.ct2_XSpec2_2.AutoSize = true;
            this.ct2_XSpec2_2.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct2_XSpec2_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct2_XSpec2_2.Location = new System.Drawing.Point(391, 47);
            this.ct2_XSpec2_2.Name = "ct2_XSpec2_2";
            this.ct2_XSpec2_2.Size = new System.Drawing.Size(0, 14);
            this.ct2_XSpec2_2.TabIndex = 296;
            // 
            // ct2_YSpec2_1
            // 
            this.ct2_YSpec2_1.AutoSize = true;
            this.ct2_YSpec2_1.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct2_YSpec2_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct2_YSpec2_1.Location = new System.Drawing.Point(218, 130);
            this.ct2_YSpec2_1.Name = "ct2_YSpec2_1";
            this.ct2_YSpec2_1.Size = new System.Drawing.Size(0, 14);
            this.ct2_YSpec2_1.TabIndex = 295;
            // 
            // ct2_XSpec2_1
            // 
            this.ct2_XSpec2_1.AutoSize = true;
            this.ct2_XSpec2_1.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct2_XSpec2_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct2_XSpec2_1.Location = new System.Drawing.Point(127, 47);
            this.ct2_XSpec2_1.Name = "ct2_XSpec2_1";
            this.ct2_XSpec2_1.Size = new System.Drawing.Size(0, 14);
            this.ct2_XSpec2_1.TabIndex = 294;
            // 
            // ctDisp2_2
            // 
            this.ctDisp2_2.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.ctDisp2_2.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea5.AxisX.Interval = 0.05D;
            chartArea5.AxisX.IsMarginVisible = false;
            chartArea5.AxisX.LabelStyle.Format = "{0:0.00}";
            chartArea5.AxisX.MajorGrid.Interval = 0.1D;
            chartArea5.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea5.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea5.AxisX.Maximum = 0.3D;
            chartArea5.AxisX.Minimum = -0.3D;
            chartArea5.AxisY.Interval = 0.05D;
            chartArea5.AxisY.IsMarginVisible = false;
            chartArea5.AxisY.LabelStyle.Format = "{0:0.00}";
            chartArea5.AxisY.MajorGrid.Interval = 0.1D;
            chartArea5.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea5.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea5.AxisY.Maximum = 0.3D;
            chartArea5.AxisY.Minimum = -0.3D;
            chartArea5.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea5.Name = "ChartArea1";
            chartArea5.Position.Auto = false;
            chartArea5.Position.Height = 94F;
            chartArea5.Position.Width = 94F;
            chartArea5.Position.X = 3F;
            chartArea5.Position.Y = 3F;
            this.ctDisp2_2.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.ctDisp2_2.Legends.Add(legend5);
            this.ctDisp2_2.Location = new System.Drawing.Point(259, 47);
            this.ctDisp2_2.Name = "ctDisp2_2";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series5.Legend = "Legend1";
            series5.MarkerColor = System.Drawing.Color.DarkGreen;
            series5.Name = "Series1";
            this.ctDisp2_2.Series.Add(series5);
            this.ctDisp2_2.Size = new System.Drawing.Size(253, 229);
            this.ctDisp2_2.TabIndex = 293;
            this.ctDisp2_2.Text = "chart1";
            this.ctDisp2_2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDoubleClick);
            // 
            // ctDisp2_1
            // 
            this.ctDisp2_1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.ctDisp2_1.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea6.AxisX.Interval = 0.05D;
            chartArea6.AxisX.IsMarginVisible = false;
            chartArea6.AxisX.LabelStyle.Format = "{0:0.00}";
            chartArea6.AxisX.MajorGrid.Interval = 0.1D;
            chartArea6.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea6.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea6.AxisX.Maximum = 4.2D;
            chartArea6.AxisX.Minimum = 3.9D;
            chartArea6.AxisY.Interval = 0.05D;
            chartArea6.AxisY.IsMarginVisible = false;
            chartArea6.AxisY.LabelStyle.Format = "{0:0.00}";
            chartArea6.AxisY.MajorGrid.Interval = 0.1D;
            chartArea6.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea6.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea6.AxisY.Maximum = 1.6D;
            chartArea6.AxisY.Minimum = 1.2D;
            chartArea6.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea6.Name = "ChartArea1";
            chartArea6.Position.Auto = false;
            chartArea6.Position.Height = 94F;
            chartArea6.Position.Width = 94F;
            chartArea6.Position.X = 3F;
            chartArea6.Position.Y = 3F;
            this.ctDisp2_1.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.ctDisp2_1.Legends.Add(legend6);
            this.ctDisp2_1.Location = new System.Drawing.Point(4, 47);
            this.ctDisp2_1.Name = "ctDisp2_1";
            this.ctDisp2_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series6.Legend = "Legend1";
            series6.MarkerColor = System.Drawing.Color.DarkGreen;
            series6.Name = "Series1";
            this.ctDisp2_1.Series.Add(series6);
            this.ctDisp2_1.Size = new System.Drawing.Size(253, 229);
            this.ctDisp2_1.TabIndex = 292;
            this.ctDisp2_1.Text = "chart1";
            this.ctDisp2_1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDoubleClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.lblSpecOut3_2);
            this.tabPage3.Controls.Add(this.lblSpecOut3_1);
            this.tabPage3.Controls.Add(this.ct3_YSpec3_2);
            this.tabPage3.Controls.Add(this.ct3_XSpec3_2);
            this.tabPage3.Controls.Add(this.ct3_YSpec3_1);
            this.tabPage3.Controls.Add(this.ct3_XSpec3_1);
            this.tabPage3.Controls.Add(this.ctDisp3_2);
            this.tabPage3.Controls.Add(this.ctDisp3_1);
            this.tabPage3.Location = new System.Drawing.Point(4, 26);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(516, 339);
            this.tabPage3.TabIndex = 5;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // lblSpecOut3_2
            // 
            this.lblSpecOut3_2.AutoSize = true;
            this.lblSpecOut3_2.Location = new System.Drawing.Point(352, 288);
            this.lblSpecOut3_2.Name = "lblSpecOut3_2";
            this.lblSpecOut3_2.Size = new System.Drawing.Size(23, 12);
            this.lblSpecOut3_2.TabIndex = 305;
            this.lblSpecOut3_2.Text = "NG";
            // 
            // lblSpecOut3_1
            // 
            this.lblSpecOut3_1.AutoSize = true;
            this.lblSpecOut3_1.Location = new System.Drawing.Point(104, 288);
            this.lblSpecOut3_1.Name = "lblSpecOut3_1";
            this.lblSpecOut3_1.Size = new System.Drawing.Size(23, 12);
            this.lblSpecOut3_1.TabIndex = 304;
            this.lblSpecOut3_1.Text = "NG";
            // 
            // ct3_YSpec3_2
            // 
            this.ct3_YSpec3_2.AutoSize = true;
            this.ct3_YSpec3_2.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct3_YSpec3_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct3_YSpec3_2.Location = new System.Drawing.Point(468, 130);
            this.ct3_YSpec3_2.Name = "ct3_YSpec3_2";
            this.ct3_YSpec3_2.Size = new System.Drawing.Size(0, 14);
            this.ct3_YSpec3_2.TabIndex = 297;
            // 
            // ct3_XSpec3_2
            // 
            this.ct3_XSpec3_2.AutoSize = true;
            this.ct3_XSpec3_2.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct3_XSpec3_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct3_XSpec3_2.Location = new System.Drawing.Point(391, 47);
            this.ct3_XSpec3_2.Name = "ct3_XSpec3_2";
            this.ct3_XSpec3_2.Size = new System.Drawing.Size(0, 14);
            this.ct3_XSpec3_2.TabIndex = 296;
            // 
            // ct3_YSpec3_1
            // 
            this.ct3_YSpec3_1.AutoSize = true;
            this.ct3_YSpec3_1.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct3_YSpec3_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct3_YSpec3_1.Location = new System.Drawing.Point(218, 130);
            this.ct3_YSpec3_1.Name = "ct3_YSpec3_1";
            this.ct3_YSpec3_1.Size = new System.Drawing.Size(0, 14);
            this.ct3_YSpec3_1.TabIndex = 295;
            // 
            // ct3_XSpec3_1
            // 
            this.ct3_XSpec3_1.AutoSize = true;
            this.ct3_XSpec3_1.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct3_XSpec3_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct3_XSpec3_1.Location = new System.Drawing.Point(127, 47);
            this.ct3_XSpec3_1.Name = "ct3_XSpec3_1";
            this.ct3_XSpec3_1.Size = new System.Drawing.Size(0, 14);
            this.ct3_XSpec3_1.TabIndex = 294;
            // 
            // ctDisp3_2
            // 
            this.ctDisp3_2.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.ctDisp3_2.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea7.AxisX.Interval = 0.05D;
            chartArea7.AxisX.IsMarginVisible = false;
            chartArea7.AxisX.LabelStyle.Format = "{0:0.00}";
            chartArea7.AxisX.MajorGrid.Interval = 0.1D;
            chartArea7.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea7.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea7.AxisX.Maximum = 0.3D;
            chartArea7.AxisX.Minimum = -0.3D;
            chartArea7.AxisY.Interval = 0.05D;
            chartArea7.AxisY.IsMarginVisible = false;
            chartArea7.AxisY.LabelStyle.Format = "{0:0.00}";
            chartArea7.AxisY.MajorGrid.Interval = 0.1D;
            chartArea7.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea7.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea7.AxisY.Maximum = 0.3D;
            chartArea7.AxisY.Minimum = -0.3D;
            chartArea7.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea7.Name = "ChartArea1";
            chartArea7.Position.Auto = false;
            chartArea7.Position.Height = 94F;
            chartArea7.Position.Width = 94F;
            chartArea7.Position.X = 3F;
            chartArea7.Position.Y = 3F;
            this.ctDisp3_2.ChartAreas.Add(chartArea7);
            legend7.Name = "Legend1";
            this.ctDisp3_2.Legends.Add(legend7);
            this.ctDisp3_2.Location = new System.Drawing.Point(259, 47);
            this.ctDisp3_2.Name = "ctDisp3_2";
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series7.Legend = "Legend1";
            series7.MarkerColor = System.Drawing.Color.DarkGreen;
            series7.Name = "Series1";
            this.ctDisp3_2.Series.Add(series7);
            this.ctDisp3_2.Size = new System.Drawing.Size(253, 229);
            this.ctDisp3_2.TabIndex = 293;
            this.ctDisp3_2.Text = "chart1";
            this.ctDisp3_2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDoubleClick);
            // 
            // ctDisp3_1
            // 
            this.ctDisp3_1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.ctDisp3_1.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea8.AxisX.Interval = 0.05D;
            chartArea8.AxisX.IsMarginVisible = false;
            chartArea8.AxisX.LabelStyle.Format = "{0:0.00}";
            chartArea8.AxisX.MajorGrid.Interval = 0.1D;
            chartArea8.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea8.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea8.AxisX.Maximum = 4.2D;
            chartArea8.AxisX.Minimum = 3.9D;
            chartArea8.AxisY.Interval = 0.05D;
            chartArea8.AxisY.IsMarginVisible = false;
            chartArea8.AxisY.LabelStyle.Format = "{0:0.00}";
            chartArea8.AxisY.MajorGrid.Interval = 0.1D;
            chartArea8.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea8.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea8.AxisY.Maximum = 1.6D;
            chartArea8.AxisY.Minimum = 1.2D;
            chartArea8.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea8.Name = "ChartArea1";
            chartArea8.Position.Auto = false;
            chartArea8.Position.Height = 94F;
            chartArea8.Position.Width = 94F;
            chartArea8.Position.X = 3F;
            chartArea8.Position.Y = 3F;
            this.ctDisp3_1.ChartAreas.Add(chartArea8);
            legend8.Name = "Legend1";
            this.ctDisp3_1.Legends.Add(legend8);
            this.ctDisp3_1.Location = new System.Drawing.Point(4, 47);
            this.ctDisp3_1.Name = "ctDisp3_1";
            this.ctDisp3_1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series8.Legend = "Legend1";
            series8.MarkerColor = System.Drawing.Color.DarkGreen;
            series8.Name = "Series1";
            this.ctDisp3_1.Series.Add(series8);
            this.ctDisp3_1.Size = new System.Drawing.Size(253, 229);
            this.ctDisp3_1.TabIndex = 292;
            this.ctDisp3_1.Text = "chart1";
            this.ctDisp3_1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDoubleClick);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Controls.Add(this.txtSuareY);
            this.tabPage4.Controls.Add(this.txtSuareX);
            this.tabPage4.Controls.Add(this.lblSpecOut4_2);
            this.tabPage4.Controls.Add(this.lblSpecOut4_1);
            this.tabPage4.Controls.Add(this.rbGraphBD3);
            this.tabPage4.Controls.Add(this.rbGraphBD2);
            this.tabPage4.Controls.Add(this.rbGraphBD1);
            this.tabPage4.Controls.Add(this.rbGraphTotal);
            this.tabPage4.Controls.Add(this.ct4_Yspec4_2);
            this.tabPage4.Controls.Add(this.ct4_Xspec4_2);
            this.tabPage4.Controls.Add(this.ct4_Yspec4_1);
            this.tabPage4.Controls.Add(this.ct4_Xspec4_1);
            this.tabPage4.Controls.Add(this.ctDisp4_2);
            this.tabPage4.Controls.Add(this.ctDisp4_1);
            this.tabPage4.Location = new System.Drawing.Point(4, 26);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(516, 339);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(415, 37);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 12);
            this.label23.TabIndex = 307;
            this.label23.Text = "SquareY";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Location = new System.Drawing.Point(415, 10);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(53, 12);
            this.label22.TabIndex = 306;
            this.label22.Text = "SquareX";
            // 
            // txtSuareY
            // 
            this.txtSuareY.Location = new System.Drawing.Point(471, 32);
            this.txtSuareY.Name = "txtSuareY";
            this.txtSuareY.Size = new System.Drawing.Size(41, 21);
            this.txtSuareY.TabIndex = 305;
            this.txtSuareY.Text = "0.3";
            // 
            // txtSuareX
            // 
            this.txtSuareX.Location = new System.Drawing.Point(471, 5);
            this.txtSuareX.Name = "txtSuareX";
            this.txtSuareX.Size = new System.Drawing.Size(41, 21);
            this.txtSuareX.TabIndex = 304;
            this.txtSuareX.Text = "0.3";
            // 
            // lblSpecOut4_2
            // 
            this.lblSpecOut4_2.AutoSize = true;
            this.lblSpecOut4_2.Location = new System.Drawing.Point(304, 288);
            this.lblSpecOut4_2.Name = "lblSpecOut4_2";
            this.lblSpecOut4_2.Size = new System.Drawing.Size(23, 12);
            this.lblSpecOut4_2.TabIndex = 301;
            this.lblSpecOut4_2.Text = "NG";
            // 
            // lblSpecOut4_1
            // 
            this.lblSpecOut4_1.AutoSize = true;
            this.lblSpecOut4_1.Location = new System.Drawing.Point(46, 288);
            this.lblSpecOut4_1.Name = "lblSpecOut4_1";
            this.lblSpecOut4_1.Size = new System.Drawing.Size(23, 12);
            this.lblSpecOut4_1.TabIndex = 300;
            this.lblSpecOut4_1.Text = "NG";
            // 
            // rbGraphBD3
            // 
            this.rbGraphBD3.AutoSize = true;
            this.rbGraphBD3.Location = new System.Drawing.Point(250, 6);
            this.rbGraphBD3.Name = "rbGraphBD3";
            this.rbGraphBD3.Size = new System.Drawing.Size(87, 16);
            this.rbGraphBD3.TabIndex = 297;
            this.rbGraphBD3.Text = "BENDING 3";
            this.rbGraphBD3.UseVisualStyleBackColor = true;
            this.rbGraphBD3.CheckedChanged += new System.EventHandler(this.rbGraphDraw_CheckedChanged);
            // 
            // rbGraphBD2
            // 
            this.rbGraphBD2.AutoSize = true;
            this.rbGraphBD2.Location = new System.Drawing.Point(161, 6);
            this.rbGraphBD2.Name = "rbGraphBD2";
            this.rbGraphBD2.Size = new System.Drawing.Size(87, 16);
            this.rbGraphBD2.TabIndex = 296;
            this.rbGraphBD2.Text = "BENDING 2";
            this.rbGraphBD2.UseVisualStyleBackColor = true;
            this.rbGraphBD2.CheckedChanged += new System.EventHandler(this.rbGraphDraw_CheckedChanged);
            // 
            // rbGraphBD1
            // 
            this.rbGraphBD1.AutoSize = true;
            this.rbGraphBD1.Location = new System.Drawing.Point(72, 6);
            this.rbGraphBD1.Name = "rbGraphBD1";
            this.rbGraphBD1.Size = new System.Drawing.Size(87, 16);
            this.rbGraphBD1.TabIndex = 295;
            this.rbGraphBD1.Text = "BENDING 1";
            this.rbGraphBD1.UseVisualStyleBackColor = true;
            this.rbGraphBD1.CheckedChanged += new System.EventHandler(this.rbGraphDraw_CheckedChanged);
            // 
            // rbGraphTotal
            // 
            this.rbGraphTotal.AutoSize = true;
            this.rbGraphTotal.Checked = true;
            this.rbGraphTotal.Location = new System.Drawing.Point(6, 6);
            this.rbGraphTotal.Name = "rbGraphTotal";
            this.rbGraphTotal.Size = new System.Drawing.Size(63, 16);
            this.rbGraphTotal.TabIndex = 294;
            this.rbGraphTotal.TabStop = true;
            this.rbGraphTotal.Text = "TOTAL";
            this.rbGraphTotal.UseVisualStyleBackColor = true;
            this.rbGraphTotal.CheckedChanged += new System.EventHandler(this.rbGraphDraw_CheckedChanged);
            // 
            // ct4_Yspec4_2
            // 
            this.ct4_Yspec4_2.AutoSize = true;
            this.ct4_Yspec4_2.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct4_Yspec4_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct4_Yspec4_2.Location = new System.Drawing.Point(468, 130);
            this.ct4_Yspec4_2.Name = "ct4_Yspec4_2";
            this.ct4_Yspec4_2.Size = new System.Drawing.Size(0, 14);
            this.ct4_Yspec4_2.TabIndex = 293;
            // 
            // ct4_Xspec4_2
            // 
            this.ct4_Xspec4_2.AutoSize = true;
            this.ct4_Xspec4_2.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct4_Xspec4_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct4_Xspec4_2.Location = new System.Drawing.Point(391, 47);
            this.ct4_Xspec4_2.Name = "ct4_Xspec4_2";
            this.ct4_Xspec4_2.Size = new System.Drawing.Size(0, 14);
            this.ct4_Xspec4_2.TabIndex = 292;
            // 
            // ct4_Yspec4_1
            // 
            this.ct4_Yspec4_1.AutoSize = true;
            this.ct4_Yspec4_1.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct4_Yspec4_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct4_Yspec4_1.Location = new System.Drawing.Point(218, 130);
            this.ct4_Yspec4_1.Name = "ct4_Yspec4_1";
            this.ct4_Yspec4_1.Size = new System.Drawing.Size(0, 14);
            this.ct4_Yspec4_1.TabIndex = 291;
            // 
            // ct4_Xspec4_1
            // 
            this.ct4_Xspec4_1.AutoSize = true;
            this.ct4_Xspec4_1.Font = new System.Drawing.Font("Georgia", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct4_Xspec4_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ct4_Xspec4_1.Location = new System.Drawing.Point(127, 47);
            this.ct4_Xspec4_1.Name = "ct4_Xspec4_1";
            this.ct4_Xspec4_1.Size = new System.Drawing.Size(0, 14);
            this.ct4_Xspec4_1.TabIndex = 290;
            // 
            // ctDisp4_2
            // 
            this.ctDisp4_2.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.ctDisp4_2.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea9.AxisX.Interval = 0.05D;
            chartArea9.AxisX.IsMarginVisible = false;
            chartArea9.AxisX.LabelStyle.Format = "{0:0.00}";
            chartArea9.AxisX.MajorGrid.Interval = 0.1D;
            chartArea9.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea9.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea9.AxisX.Maximum = 0.3D;
            chartArea9.AxisX.Minimum = -0.3D;
            chartArea9.AxisY.Interval = 0.05D;
            chartArea9.AxisY.IsMarginVisible = false;
            chartArea9.AxisY.LabelStyle.Format = "{0:0.00}";
            chartArea9.AxisY.MajorGrid.Interval = 0.1D;
            chartArea9.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea9.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea9.AxisY.Maximum = 0.3D;
            chartArea9.AxisY.Minimum = -0.3D;
            chartArea9.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea9.Name = "ChartArea1";
            chartArea9.Position.Auto = false;
            chartArea9.Position.Height = 94F;
            chartArea9.Position.Width = 94F;
            chartArea9.Position.X = 3F;
            chartArea9.Position.Y = 3F;
            this.ctDisp4_2.ChartAreas.Add(chartArea9);
            legend9.Name = "Legend1";
            this.ctDisp4_2.Legends.Add(legend9);
            this.ctDisp4_2.Location = new System.Drawing.Point(259, 47);
            this.ctDisp4_2.Name = "ctDisp4_2";
            series9.ChartArea = "ChartArea1";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series9.Legend = "Legend1";
            series9.MarkerColor = System.Drawing.Color.DarkGreen;
            series9.Name = "Series1";
            this.ctDisp4_2.Series.Add(series9);
            this.ctDisp4_2.Size = new System.Drawing.Size(253, 229);
            this.ctDisp4_2.TabIndex = 288;
            this.ctDisp4_2.Text = "chart1";
            this.ctDisp4_2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDoubleClick);
            // 
            // ctDisp4_1
            // 
            this.ctDisp4_1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            this.ctDisp4_1.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea10.AxisX.Interval = 0.05D;
            chartArea10.AxisX.IsMarginVisible = false;
            chartArea10.AxisX.LabelStyle.Format = "{0:0.00}";
            chartArea10.AxisX.MajorGrid.Interval = 0.1D;
            chartArea10.AxisX.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea10.AxisX.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea10.AxisX.Maximum = 0.3D;
            chartArea10.AxisX.Minimum = -0.3D;
            chartArea10.AxisY.Interval = 0.05D;
            chartArea10.AxisY.IsMarginVisible = false;
            chartArea10.AxisY.LabelStyle.Format = "{0:0.00}";
            chartArea10.AxisY.MajorGrid.Interval = 0.1D;
            chartArea10.AxisY.MajorGrid.LineColor = System.Drawing.Color.LightGray;
            chartArea10.AxisY.MajorGrid.LineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.DashDot;
            chartArea10.AxisY.Maximum = 0.3D;
            chartArea10.AxisY.Minimum = -0.3D;
            chartArea10.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea10.Name = "ChartArea1";
            chartArea10.Position.Auto = false;
            chartArea10.Position.Height = 94F;
            chartArea10.Position.Width = 94F;
            chartArea10.Position.X = 3F;
            chartArea10.Position.Y = 3F;
            this.ctDisp4_1.ChartAreas.Add(chartArea10);
            legend10.ItemColumnSpacing = 30;
            legend10.Name = "Legend1";
            this.ctDisp4_1.Legends.Add(legend10);
            this.ctDisp4_1.Location = new System.Drawing.Point(4, 47);
            this.ctDisp4_1.Name = "ctDisp4_1";
            series10.ChartArea = "ChartArea1";
            series10.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series10.Legend = "Legend1";
            series10.MarkerColor = System.Drawing.Color.DarkGreen;
            series10.Name = "Series1";
            this.ctDisp4_1.Series.Add(series10);
            this.ctDisp4_1.Size = new System.Drawing.Size(253, 229);
            this.ctDisp4_1.TabIndex = 287;
            this.ctDisp4_1.Text = "chart1";
            this.ctDisp4_1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.Chart_MouseDoubleClick);
            // 
            // pnAPC
            // 
            this.pnAPC.BackColor = System.Drawing.Color.Black;
            this.pnAPC.Controls.Add(this.dgvAPC2);
            this.pnAPC.Controls.Add(this.dgvAPC1);
            this.pnAPC.Controls.Add(this.panel1);
            this.pnAPC.Location = new System.Drawing.Point(1579, 7);
            this.pnAPC.Name = "pnAPC";
            this.pnAPC.Size = new System.Drawing.Size(335, 252);
            this.pnAPC.TabIndex = 306;
            // 
            // dgvAPC2
            // 
            this.dgvAPC2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvAPC2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvAPC2.BackgroundColor = System.Drawing.Color.DimGray;
            this.dgvAPC2.Location = new System.Drawing.Point(0, 100);
            this.dgvAPC2.Name = "dgvAPC2";
            this.dgvAPC2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvAPC2.RowTemplate.Height = 23;
            this.dgvAPC2.Size = new System.Drawing.Size(335, 100);
            this.dgvAPC2.TabIndex = 2;
            // 
            // dgvAPC1
            // 
            this.dgvAPC1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvAPC1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvAPC1.BackgroundColor = System.Drawing.Color.DimGray;
            this.dgvAPC1.Location = new System.Drawing.Point(0, 0);
            this.dgvAPC1.Name = "dgvAPC1";
            this.dgvAPC1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders;
            this.dgvAPC1.RowTemplate.Height = 23;
            this.dgvAPC1.Size = new System.Drawing.Size(335, 100);
            this.dgvAPC1.TabIndex = 1;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.pn5);
            this.panel1.Controls.Add(this.pn6);
            this.panel1.Controls.Add(this.pn7);
            this.panel1.Controls.Add(this.pn8);
            this.panel1.Location = new System.Drawing.Point(292, 9);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1379, 310);
            this.panel1.TabIndex = 299;
            this.panel1.Visible = false;
            // 
            // pn7
            // 
            this.pn7.BackColor = System.Drawing.Color.Gray;
            this.pn7.Controls.Add(this.lblRightScore1);
            this.pn7.Controls.Add(this.cbSideImageSize7);
            this.pn7.Controls.Add(this.cbLive7);
            this.pn7.Controls.Add(this.button_PLC17);
            this.pn7.Controls.Add(this.button_PLC7);
            this.pn7.Controls.Add(this.button_PC7);
            this.pn7.Controls.Add(this.lblScore7);
            this.pn7.Controls.Add(this.checkBox_Overlay7);
            this.pn7.Controls.Add(this.lblSearchResult7);
            this.pn7.Controls.Add(this.cogDS7);
            this.pn7.Controls.Add(this.lb7);
            this.pn7.Controls.Add(this.lbAlign7);
            this.pn7.Location = new System.Drawing.Point(691, 0);
            this.pn7.Name = "pn7";
            this.pn7.Size = new System.Drawing.Size(337, 300);
            this.pn7.TabIndex = 90;
            // 
            // lblRightScore1
            // 
            this.lblRightScore1.BackColor = System.Drawing.Color.Black;
            this.lblRightScore1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblRightScore1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblRightScore1.ForeColor = System.Drawing.Color.Yellow;
            this.lblRightScore1.Location = new System.Drawing.Point(239, 28);
            this.lblRightScore1.Name = "lblRightScore1";
            this.lblRightScore1.Size = new System.Drawing.Size(49, 20);
            this.lblRightScore1.TabIndex = 299;
            this.lblRightScore1.Text = "0.0";
            this.lblRightScore1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRightScore1.Visible = false;
            // 
            // cbSideImageSize7
            // 
            this.cbSideImageSize7.FormattingEnabled = true;
            this.cbSideImageSize7.Items.AddRange(new object[] {
            "100%",
            "200%",
            "300%",
            "400%"});
            this.cbSideImageSize7.Location = new System.Drawing.Point(226, 279);
            this.cbSideImageSize7.Name = "cbSideImageSize7";
            this.cbSideImageSize7.Size = new System.Drawing.Size(60, 20);
            this.cbSideImageSize7.TabIndex = 298;
            // 
            // cbLive7
            // 
            this.cbLive7.ForeColor = System.Drawing.Color.White;
            this.cbLive7.Location = new System.Drawing.Point(289, 279);
            this.cbLive7.Name = "cbLive7";
            this.cbLive7.Size = new System.Drawing.Size(47, 20);
            this.cbLive7.TabIndex = 297;
            this.cbLive7.Text = "Live";
            this.cbLive7.UseVisualStyleBackColor = true;
            this.cbLive7.Visible = false;
            // 
            // button_PLC17
            // 
            this.button_PLC17.Location = new System.Drawing.Point(173, 2);
            this.button_PLC17.Name = "button_PLC17";
            this.button_PLC17.Size = new System.Drawing.Size(23, 20);
            this.button_PLC17.TabIndex = 143;
            this.button_PLC17.UseVisualStyleBackColor = true;
            // 
            // button_PLC7
            // 
            this.button_PLC7.Location = new System.Drawing.Point(149, 2);
            this.button_PLC7.Name = "button_PLC7";
            this.button_PLC7.Size = new System.Drawing.Size(23, 20);
            this.button_PLC7.TabIndex = 142;
            this.button_PLC7.UseVisualStyleBackColor = true;
            // 
            // button_PC7
            // 
            this.button_PC7.Location = new System.Drawing.Point(197, 2);
            this.button_PC7.Name = "button_PC7";
            this.button_PC7.Size = new System.Drawing.Size(36, 20);
            this.button_PC7.TabIndex = 141;
            this.button_PC7.Text = "0";
            this.button_PC7.UseVisualStyleBackColor = true;
            // 
            // lblScore7
            // 
            this.lblScore7.BackColor = System.Drawing.Color.Black;
            this.lblScore7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblScore7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblScore7.ForeColor = System.Drawing.Color.Yellow;
            this.lblScore7.Location = new System.Drawing.Point(239, 2);
            this.lblScore7.Name = "lblScore7";
            this.lblScore7.Size = new System.Drawing.Size(49, 20);
            this.lblScore7.TabIndex = 116;
            this.lblScore7.Text = "Score";
            this.lblScore7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // checkBox_Overlay7
            // 
            this.checkBox_Overlay7.ForeColor = System.Drawing.Color.White;
            this.checkBox_Overlay7.Location = new System.Drawing.Point(0, 280);
            this.checkBox_Overlay7.Name = "checkBox_Overlay7";
            this.checkBox_Overlay7.Size = new System.Drawing.Size(71, 20);
            this.checkBox_Overlay7.TabIndex = 140;
            this.checkBox_Overlay7.Text = "OverLay";
            this.checkBox_Overlay7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBox_Overlay7.UseVisualStyleBackColor = true;
            this.checkBox_Overlay7.CheckedChanged += new System.EventHandler(this.checkBox_Overlay7_CheckedChanged);
            // 
            // lblSearchResult7
            // 
            this.lblSearchResult7.BackColor = System.Drawing.Color.Silver;
            this.lblSearchResult7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSearchResult7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSearchResult7.ForeColor = System.Drawing.Color.GreenYellow;
            this.lblSearchResult7.Location = new System.Drawing.Point(289, 0);
            this.lblSearchResult7.Name = "lblSearchResult7";
            this.lblSearchResult7.Size = new System.Drawing.Size(47, 25);
            this.lblSearchResult7.TabIndex = 115;
            this.lblSearchResult7.Text = "-";
            this.lblSearchResult7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // cogDS7
            // 
            this.cogDS7.ColorMapLowerClipColor = System.Drawing.Color.Black;
            this.cogDS7.ColorMapLowerRoiLimit = 0D;
            this.cogDS7.ColorMapPredefined = Cognex.VisionPro.Display.CogDisplayColorMapPredefinedConstants.None;
            this.cogDS7.ColorMapUpperClipColor = System.Drawing.Color.Black;
            this.cogDS7.ColorMapUpperRoiLimit = 1D;
            this.cogDS7.DoubleTapZoomCycleLength = 2;
            this.cogDS7.DoubleTapZoomSensitivity = 2.5D;
            this.cogDS7.Location = new System.Drawing.Point(3, 25);
            this.cogDS7.MouseWheelMode = Cognex.VisionPro.Display.CogDisplayMouseWheelModeConstants.Zoom1;
            this.cogDS7.MouseWheelSensitivity = 1D;
            this.cogDS7.Name = "cogDS7";
            this.cogDS7.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("cogDS7.OcxState")));
            this.cogDS7.Size = new System.Drawing.Size(334, 275);
            this.cogDS7.TabIndex = 9;
            this.cogDS7.DoubleClick += new System.EventHandler(this.cogDS_DoubleClick);
            // 
            // lb7
            // 
            this.lb7.BackColor = System.Drawing.Color.Black;
            this.lb7.ForeColor = System.Drawing.Color.Yellow;
            this.lb7.Location = new System.Drawing.Point(2, 2);
            this.lb7.Name = "lb7";
            this.lb7.Size = new System.Drawing.Size(234, 20);
            this.lb7.TabIndex = 0;
            this.lb7.Text = "    CAM1";
            this.lb7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbAlign7
            // 
            this.lbAlign7.BackColor = System.Drawing.Color.DimGray;
            this.lbAlign7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbAlign7.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAlign7.ForeColor = System.Drawing.Color.White;
            this.lbAlign7.Location = new System.Drawing.Point(5, 255);
            this.lbAlign7.Name = "lbAlign7";
            this.lbAlign7.Size = new System.Drawing.Size(36, 18);
            this.lbAlign7.TabIndex = 94;
            this.lbAlign7.Text = "Align";
            this.lbAlign7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbAlign7.Visible = false;
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage9);
            this.tabControl3.Controls.Add(this.tabPage10);
            this.tabControl3.Controls.Add(this.tabPage15);
            this.tabControl3.Location = new System.Drawing.Point(0, 0);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(676, 106);
            this.tabControl3.TabIndex = 291;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.listBox3);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(668, 80);
            this.tabPage9.TabIndex = 0;
            this.tabPage9.Text = "Data";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // listBox3
            // 
            this.listBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox3.FormattingEnabled = true;
            this.listBox3.HorizontalScrollbar = true;
            this.listBox3.ItemHeight = 12;
            this.listBox3.Location = new System.Drawing.Point(3, 3);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(662, 74);
            this.listBox3.TabIndex = 132;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.dgvAlign3);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(668, 80);
            this.tabPage10.TabIndex = 1;
            this.tabPage10.Text = "Align";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // dgvAlign3
            // 
            this.dgvAlign3.AllowUserToAddRows = false;
            this.dgvAlign3.AllowUserToDeleteRows = false;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAlign3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dgvAlign3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAlign3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn51,
            this.dataGridViewTextBoxColumn52,
            this.dataGridViewTextBoxColumn53,
            this.dataGridViewTextBoxColumn54,
            this.dataGridViewTextBoxColumn55,
            this.dataGridViewTextBoxColumn56,
            this.dataGridViewTextBoxColumn57,
            this.dataGridViewTextBoxColumn58,
            this.dataGridViewTextBoxColumn59,
            this.dataGridViewTextBoxColumn87,
            this.dataGridViewTextBoxColumn88});
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle25.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle25.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle25.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle25.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle25.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAlign3.DefaultCellStyle = dataGridViewCellStyle25;
            this.dgvAlign3.Location = new System.Drawing.Point(3, 3);
            this.dgvAlign3.Name = "dgvAlign3";
            this.dgvAlign3.ReadOnly = true;
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle26.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle26.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle26.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle26.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle26.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAlign3.RowHeadersDefaultCellStyle = dataGridViewCellStyle26;
            this.dgvAlign3.RowHeadersVisible = false;
            dataGridViewCellStyle27.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle27.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle27.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle27.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle27.SelectionForeColor = System.Drawing.Color.White;
            this.dgvAlign3.RowsDefaultCellStyle = dataGridViewCellStyle27;
            this.dgvAlign3.RowTemplate.Height = 23;
            this.dgvAlign3.Size = new System.Drawing.Size(664, 179);
            this.dgvAlign3.TabIndex = 133;
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.HeaderText = "CellID";
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            this.dataGridViewTextBoxColumn51.ReadOnly = true;
            this.dataGridViewTextBoxColumn51.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn51.Width = 120;
            // 
            // dataGridViewTextBoxColumn52
            // 
            this.dataGridViewTextBoxColumn52.HeaderText = "LX";
            this.dataGridViewTextBoxColumn52.Name = "dataGridViewTextBoxColumn52";
            this.dataGridViewTextBoxColumn52.ReadOnly = true;
            this.dataGridViewTextBoxColumn52.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn52.Width = 50;
            // 
            // dataGridViewTextBoxColumn53
            // 
            this.dataGridViewTextBoxColumn53.HeaderText = "LY";
            this.dataGridViewTextBoxColumn53.Name = "dataGridViewTextBoxColumn53";
            this.dataGridViewTextBoxColumn53.ReadOnly = true;
            this.dataGridViewTextBoxColumn53.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn53.Width = 50;
            // 
            // dataGridViewTextBoxColumn54
            // 
            this.dataGridViewTextBoxColumn54.HeaderText = "RX";
            this.dataGridViewTextBoxColumn54.Name = "dataGridViewTextBoxColumn54";
            this.dataGridViewTextBoxColumn54.ReadOnly = true;
            this.dataGridViewTextBoxColumn54.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn54.Width = 50;
            // 
            // dataGridViewTextBoxColumn55
            // 
            this.dataGridViewTextBoxColumn55.HeaderText = "RY";
            this.dataGridViewTextBoxColumn55.Name = "dataGridViewTextBoxColumn55";
            this.dataGridViewTextBoxColumn55.ReadOnly = true;
            this.dataGridViewTextBoxColumn55.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn55.Width = 50;
            // 
            // dataGridViewTextBoxColumn56
            // 
            this.dataGridViewTextBoxColumn56.HeaderText = "X";
            this.dataGridViewTextBoxColumn56.Name = "dataGridViewTextBoxColumn56";
            this.dataGridViewTextBoxColumn56.ReadOnly = true;
            this.dataGridViewTextBoxColumn56.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn56.Width = 50;
            // 
            // dataGridViewTextBoxColumn57
            // 
            this.dataGridViewTextBoxColumn57.HeaderText = "Y";
            this.dataGridViewTextBoxColumn57.Name = "dataGridViewTextBoxColumn57";
            this.dataGridViewTextBoxColumn57.ReadOnly = true;
            this.dataGridViewTextBoxColumn57.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn57.Width = 50;
            // 
            // dataGridViewTextBoxColumn58
            // 
            this.dataGridViewTextBoxColumn58.HeaderText = "T";
            this.dataGridViewTextBoxColumn58.Name = "dataGridViewTextBoxColumn58";
            this.dataGridViewTextBoxColumn58.ReadOnly = true;
            this.dataGridViewTextBoxColumn58.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn58.Width = 50;
            // 
            // dataGridViewTextBoxColumn59
            // 
            this.dataGridViewTextBoxColumn59.HeaderText = "Retry";
            this.dataGridViewTextBoxColumn59.Name = "dataGridViewTextBoxColumn59";
            this.dataGridViewTextBoxColumn59.ReadOnly = true;
            this.dataGridViewTextBoxColumn59.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn59.Width = 40;
            // 
            // dataGridViewTextBoxColumn87
            // 
            this.dataGridViewTextBoxColumn87.HeaderText = "Score1";
            this.dataGridViewTextBoxColumn87.Name = "dataGridViewTextBoxColumn87";
            this.dataGridViewTextBoxColumn87.ReadOnly = true;
            this.dataGridViewTextBoxColumn87.Width = 50;
            // 
            // dataGridViewTextBoxColumn88
            // 
            this.dataGridViewTextBoxColumn88.HeaderText = "Score2";
            this.dataGridViewTextBoxColumn88.Name = "dataGridViewTextBoxColumn88";
            this.dataGridViewTextBoxColumn88.ReadOnly = true;
            this.dataGridViewTextBoxColumn88.Width = 50;
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.dgvError3);
            this.tabPage15.Location = new System.Drawing.Point(4, 22);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Size = new System.Drawing.Size(668, 80);
            this.tabPage15.TabIndex = 2;
            this.tabPage15.Text = "Error";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // dgvError3
            // 
            this.dgvError3.AllowUserToAddRows = false;
            this.dgvError3.AllowUserToDeleteRows = false;
            dataGridViewCellStyle28.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle28.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle28.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle28.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle28.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle28.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle28.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvError3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle28;
            this.dgvError3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvError3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn74,
            this.dataGridViewTextBoxColumn75});
            dataGridViewCellStyle29.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle29.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle29.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle29.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle29.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle29.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvError3.DefaultCellStyle = dataGridViewCellStyle29;
            this.dgvError3.Location = new System.Drawing.Point(3, 3);
            this.dgvError3.Name = "dgvError3";
            this.dgvError3.ReadOnly = true;
            dataGridViewCellStyle30.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle30.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle30.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle30.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle30.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle30.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvError3.RowHeadersDefaultCellStyle = dataGridViewCellStyle30;
            this.dgvError3.RowHeadersVisible = false;
            dataGridViewCellStyle31.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle31.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle31.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle31.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle31.SelectionForeColor = System.Drawing.Color.White;
            this.dgvError3.RowsDefaultCellStyle = dataGridViewCellStyle31;
            this.dgvError3.RowTemplate.Height = 23;
            this.dgvError3.Size = new System.Drawing.Size(664, 182);
            this.dgvError3.TabIndex = 134;
            // 
            // dataGridViewTextBoxColumn74
            // 
            this.dataGridViewTextBoxColumn74.HeaderText = "CellID";
            this.dataGridViewTextBoxColumn74.Name = "dataGridViewTextBoxColumn74";
            this.dataGridViewTextBoxColumn74.ReadOnly = true;
            this.dataGridViewTextBoxColumn74.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn74.Width = 170;
            // 
            // dataGridViewTextBoxColumn75
            // 
            this.dataGridViewTextBoxColumn75.HeaderText = "Error";
            this.dataGridViewTextBoxColumn75.Name = "dataGridViewTextBoxColumn75";
            this.dataGridViewTextBoxColumn75.ReadOnly = true;
            this.dataGridViewTextBoxColumn75.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn75.Width = 150;
            // 
            // tabControl4
            // 
            this.tabControl4.Controls.Add(this.tabPage11);
            this.tabControl4.Controls.Add(this.tabPage12);
            this.tabControl4.Controls.Add(this.tabPage16);
            this.tabControl4.Location = new System.Drawing.Point(0, 0);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(679, 105);
            this.tabControl4.TabIndex = 292;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.listBox4);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(671, 79);
            this.tabPage11.TabIndex = 0;
            this.tabPage11.Text = "Log";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // listBox4
            // 
            this.listBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox4.FormattingEnabled = true;
            this.listBox4.HorizontalScrollbar = true;
            this.listBox4.ItemHeight = 12;
            this.listBox4.Location = new System.Drawing.Point(3, 3);
            this.listBox4.Name = "listBox4";
            this.listBox4.Size = new System.Drawing.Size(665, 73);
            this.listBox4.TabIndex = 132;
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.dgvAlign4);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(671, 79);
            this.tabPage12.TabIndex = 1;
            this.tabPage12.Text = "Align";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // dgvAlign4
            // 
            this.dgvAlign4.AllowUserToAddRows = false;
            this.dgvAlign4.AllowUserToDeleteRows = false;
            dataGridViewCellStyle32.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle32.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle32.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle32.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle32.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle32.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle32.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAlign4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle32;
            this.dgvAlign4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAlign4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn60,
            this.dataGridViewTextBoxColumn61,
            this.dataGridViewTextBoxColumn62,
            this.dataGridViewTextBoxColumn63,
            this.dataGridViewTextBoxColumn64,
            this.dataGridViewTextBoxColumn65,
            this.dataGridViewTextBoxColumn66,
            this.dataGridViewTextBoxColumn68,
            this.dataGridViewTextBoxColumn69,
            this.dataGridViewTextBoxColumn89,
            this.dataGridViewTextBoxColumn90});
            dataGridViewCellStyle33.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle33.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle33.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle33.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle33.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle33.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAlign4.DefaultCellStyle = dataGridViewCellStyle33;
            this.dgvAlign4.Location = new System.Drawing.Point(3, 3);
            this.dgvAlign4.Name = "dgvAlign4";
            this.dgvAlign4.ReadOnly = true;
            dataGridViewCellStyle34.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle34.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle34.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle34.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle34.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle34.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAlign4.RowHeadersDefaultCellStyle = dataGridViewCellStyle34;
            this.dgvAlign4.RowHeadersVisible = false;
            dataGridViewCellStyle35.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle35.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle35.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle35.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle35.SelectionForeColor = System.Drawing.Color.White;
            this.dgvAlign4.RowsDefaultCellStyle = dataGridViewCellStyle35;
            this.dgvAlign4.RowTemplate.Height = 23;
            this.dgvAlign4.Size = new System.Drawing.Size(664, 194);
            this.dgvAlign4.TabIndex = 133;
            // 
            // dataGridViewTextBoxColumn60
            // 
            this.dataGridViewTextBoxColumn60.HeaderText = "CellID";
            this.dataGridViewTextBoxColumn60.Name = "dataGridViewTextBoxColumn60";
            this.dataGridViewTextBoxColumn60.ReadOnly = true;
            this.dataGridViewTextBoxColumn60.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn60.Width = 120;
            // 
            // dataGridViewTextBoxColumn61
            // 
            this.dataGridViewTextBoxColumn61.HeaderText = "LX";
            this.dataGridViewTextBoxColumn61.Name = "dataGridViewTextBoxColumn61";
            this.dataGridViewTextBoxColumn61.ReadOnly = true;
            this.dataGridViewTextBoxColumn61.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn61.Width = 50;
            // 
            // dataGridViewTextBoxColumn62
            // 
            this.dataGridViewTextBoxColumn62.HeaderText = "LY";
            this.dataGridViewTextBoxColumn62.Name = "dataGridViewTextBoxColumn62";
            this.dataGridViewTextBoxColumn62.ReadOnly = true;
            this.dataGridViewTextBoxColumn62.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn62.Width = 50;
            // 
            // dataGridViewTextBoxColumn63
            // 
            this.dataGridViewTextBoxColumn63.HeaderText = "RX";
            this.dataGridViewTextBoxColumn63.Name = "dataGridViewTextBoxColumn63";
            this.dataGridViewTextBoxColumn63.ReadOnly = true;
            this.dataGridViewTextBoxColumn63.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn63.Width = 50;
            // 
            // dataGridViewTextBoxColumn64
            // 
            this.dataGridViewTextBoxColumn64.HeaderText = "RY";
            this.dataGridViewTextBoxColumn64.Name = "dataGridViewTextBoxColumn64";
            this.dataGridViewTextBoxColumn64.ReadOnly = true;
            this.dataGridViewTextBoxColumn64.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn64.Width = 50;
            // 
            // dataGridViewTextBoxColumn65
            // 
            this.dataGridViewTextBoxColumn65.HeaderText = "X";
            this.dataGridViewTextBoxColumn65.Name = "dataGridViewTextBoxColumn65";
            this.dataGridViewTextBoxColumn65.ReadOnly = true;
            this.dataGridViewTextBoxColumn65.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn65.Width = 50;
            // 
            // dataGridViewTextBoxColumn66
            // 
            this.dataGridViewTextBoxColumn66.HeaderText = "Y";
            this.dataGridViewTextBoxColumn66.Name = "dataGridViewTextBoxColumn66";
            this.dataGridViewTextBoxColumn66.ReadOnly = true;
            this.dataGridViewTextBoxColumn66.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn66.Width = 50;
            // 
            // dataGridViewTextBoxColumn68
            // 
            this.dataGridViewTextBoxColumn68.HeaderText = "T";
            this.dataGridViewTextBoxColumn68.Name = "dataGridViewTextBoxColumn68";
            this.dataGridViewTextBoxColumn68.ReadOnly = true;
            this.dataGridViewTextBoxColumn68.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn68.Width = 50;
            // 
            // dataGridViewTextBoxColumn69
            // 
            this.dataGridViewTextBoxColumn69.HeaderText = "Retry";
            this.dataGridViewTextBoxColumn69.Name = "dataGridViewTextBoxColumn69";
            this.dataGridViewTextBoxColumn69.ReadOnly = true;
            this.dataGridViewTextBoxColumn69.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn69.Width = 40;
            // 
            // dataGridViewTextBoxColumn89
            // 
            this.dataGridViewTextBoxColumn89.HeaderText = "Score1";
            this.dataGridViewTextBoxColumn89.Name = "dataGridViewTextBoxColumn89";
            this.dataGridViewTextBoxColumn89.ReadOnly = true;
            this.dataGridViewTextBoxColumn89.Width = 50;
            // 
            // dataGridViewTextBoxColumn90
            // 
            this.dataGridViewTextBoxColumn90.HeaderText = "Score2";
            this.dataGridViewTextBoxColumn90.Name = "dataGridViewTextBoxColumn90";
            this.dataGridViewTextBoxColumn90.ReadOnly = true;
            this.dataGridViewTextBoxColumn90.Width = 50;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.dgvError4);
            this.tabPage16.Location = new System.Drawing.Point(4, 22);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Size = new System.Drawing.Size(671, 79);
            this.tabPage16.TabIndex = 2;
            this.tabPage16.Text = "Error";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // dgvError4
            // 
            this.dgvError4.AllowUserToAddRows = false;
            this.dgvError4.AllowUserToDeleteRows = false;
            dataGridViewCellStyle36.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle36.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle36.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle36.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle36.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle36.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle36.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvError4.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle36;
            this.dgvError4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvError4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn76,
            this.dataGridViewTextBoxColumn77});
            dataGridViewCellStyle37.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle37.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle37.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle37.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle37.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle37.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle37.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvError4.DefaultCellStyle = dataGridViewCellStyle37;
            this.dgvError4.Location = new System.Drawing.Point(3, 3);
            this.dgvError4.Name = "dgvError4";
            this.dgvError4.ReadOnly = true;
            dataGridViewCellStyle38.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle38.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle38.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle38.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle38.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle38.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle38.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvError4.RowHeadersDefaultCellStyle = dataGridViewCellStyle38;
            this.dgvError4.RowHeadersVisible = false;
            dataGridViewCellStyle39.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle39.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle39.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle39.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle39.SelectionForeColor = System.Drawing.Color.White;
            this.dgvError4.RowsDefaultCellStyle = dataGridViewCellStyle39;
            this.dgvError4.RowTemplate.Height = 23;
            this.dgvError4.Size = new System.Drawing.Size(664, 197);
            this.dgvError4.TabIndex = 134;
            // 
            // dataGridViewTextBoxColumn76
            // 
            this.dataGridViewTextBoxColumn76.HeaderText = "CellID";
            this.dataGridViewTextBoxColumn76.Name = "dataGridViewTextBoxColumn76";
            this.dataGridViewTextBoxColumn76.ReadOnly = true;
            this.dataGridViewTextBoxColumn76.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn76.Width = 170;
            // 
            // dataGridViewTextBoxColumn77
            // 
            this.dataGridViewTextBoxColumn77.HeaderText = "Error";
            this.dataGridViewTextBoxColumn77.Name = "dataGridViewTextBoxColumn77";
            this.dataGridViewTextBoxColumn77.ReadOnly = true;
            this.dataGridViewTextBoxColumn77.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn77.Width = 150;
            // 
            // listBox1
            // 
            this.listBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.HorizontalScrollbar = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Location = new System.Drawing.Point(3, 3);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(336, 118);
            this.listBox1.TabIndex = 132;
            // 
            // tmrSave
            // 
            this.tmrSave.Interval = 1000;
            this.tmrSave.Tick += new System.EventHandler(this.tmrSave_Tick);
            // 
            // pnResult2
            // 
            this.pnResult2.Controls.Add(this.gbBendResult3);
            this.pnResult2.Controls.Add(this.gbBendResult4);
            this.pnResult2.Location = new System.Drawing.Point(459, 866);
            this.pnResult2.Name = "pnResult2";
            this.pnResult2.Size = new System.Drawing.Size(521, 424);
            this.pnResult2.TabIndex = 306;
            this.pnResult2.TabStop = false;
            // 
            // gbBendResult3
            // 
            this.gbBendResult3.Controls.Add(this.dgvSpec3);
            this.gbBendResult3.Controls.Add(this.lblOFFSET2);
            this.gbBendResult3.Controls.Add(this.label11);
            this.gbBendResult3.Controls.Add(this.label12);
            this.gbBendResult3.Controls.Add(this.label14);
            this.gbBendResult3.Controls.Add(this.dgvResult3);
            this.gbBendResult3.Controls.Add(this.lbResult3Title);
            this.gbBendResult3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gbBendResult3.Location = new System.Drawing.Point(7, 14);
            this.gbBendResult3.Name = "gbBendResult3";
            this.gbBendResult3.Size = new System.Drawing.Size(255, 400);
            this.gbBendResult3.TabIndex = 260;
            this.gbBendResult3.TabStop = false;
            this.gbBendResult3.Text = "Foam Align Result";
            // 
            // dgvSpec3
            // 
            this.dgvSpec3.AllowUserToAddRows = false;
            this.dgvSpec3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSpec3.ColumnHeadersVisible = false;
            this.dgvSpec3.Location = new System.Drawing.Point(5, 298);
            this.dgvSpec3.Name = "dgvSpec3";
            this.dgvSpec3.ReadOnly = true;
            this.dgvSpec3.RowHeadersVisible = false;
            dataGridViewCellStyle40.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle40.BackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle40.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle40.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle40.SelectionBackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle40.SelectionForeColor = System.Drawing.Color.White;
            this.dgvSpec3.RowsDefaultCellStyle = dataGridViewCellStyle40;
            this.dgvSpec3.RowTemplate.Height = 23;
            this.dgvSpec3.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.dgvSpec3.Size = new System.Drawing.Size(191, 96);
            this.dgvSpec3.TabIndex = 134;
            // 
            // lblOFFSET2
            // 
            this.lblOFFSET2.BackColor = System.Drawing.Color.Black;
            this.lblOFFSET2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOFFSET2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblOFFSET2.ForeColor = System.Drawing.Color.Yellow;
            this.lblOFFSET2.Location = new System.Drawing.Point(200, 374);
            this.lblOFFSET2.Name = "lblOFFSET2";
            this.lblOFFSET2.Size = new System.Drawing.Size(51, 20);
            this.lblOFFSET2.TabIndex = 135;
            this.lblOFFSET2.Text = "OFFSET";
            this.lblOFFSET2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.Black;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.ForeColor = System.Drawing.Color.Yellow;
            this.label11.Location = new System.Drawing.Point(200, 350);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(51, 20);
            this.label11.TabIndex = 133;
            this.label11.Text = "MAX";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.Black;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.ForeColor = System.Drawing.Color.Yellow;
            this.label12.Location = new System.Drawing.Point(200, 324);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(51, 20);
            this.label12.TabIndex = 132;
            this.label12.Text = "SPEC.";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.Black;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.ForeColor = System.Drawing.Color.Yellow;
            this.label14.Location = new System.Drawing.Point(200, 298);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(51, 20);
            this.label14.TabIndex = 131;
            this.label14.Text = "MIN";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvResult3
            // 
            this.dgvResult3.AllowUserToAddRows = false;
            this.dgvResult3.AllowUserToDeleteRows = false;
            this.dgvResult3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column18,
            this.Column19,
            this.Column20,
            this.dataGridViewTextBoxColumn23,
            this.Column21,
            this.dataGridViewTextBoxColumn81,
            this.dataGridViewTextBoxColumn82});
            this.dgvResult3.Location = new System.Drawing.Point(3, 26);
            this.dgvResult3.Name = "dgvResult3";
            this.dgvResult3.ReadOnly = true;
            this.dgvResult3.RowHeadersVisible = false;
            dataGridViewCellStyle45.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle45.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle45.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle45.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle45.SelectionForeColor = System.Drawing.Color.White;
            this.dgvResult3.RowsDefaultCellStyle = dataGridViewCellStyle45;
            this.dgvResult3.RowTemplate.Height = 23;
            this.dgvResult3.Size = new System.Drawing.Size(250, 267);
            this.dgvResult3.TabIndex = 130;
            // 
            // Column18
            // 
            dataGridViewCellStyle41.NullValue = "0";
            this.Column18.DefaultCellStyle = dataGridViewCellStyle41;
            this.Column18.HeaderText = "LX";
            this.Column18.Name = "Column18";
            this.Column18.ReadOnly = true;
            this.Column18.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column18.Width = 50;
            // 
            // Column19
            // 
            dataGridViewCellStyle42.NullValue = "0";
            this.Column19.DefaultCellStyle = dataGridViewCellStyle42;
            this.Column19.HeaderText = "LY";
            this.Column19.Name = "Column19";
            this.Column19.ReadOnly = true;
            this.Column19.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column19.Width = 50;
            // 
            // Column20
            // 
            dataGridViewCellStyle43.NullValue = "0";
            this.Column20.DefaultCellStyle = dataGridViewCellStyle43;
            this.Column20.HeaderText = "RX";
            this.Column20.Name = "Column20";
            this.Column20.ReadOnly = true;
            this.Column20.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column20.Width = 50;
            // 
            // dataGridViewTextBoxColumn23
            // 
            dataGridViewCellStyle44.NullValue = "0";
            this.dataGridViewTextBoxColumn23.DefaultCellStyle = dataGridViewCellStyle44;
            this.dataGridViewTextBoxColumn23.HeaderText = "RY";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn23.Width = 50;
            // 
            // Column21
            // 
            this.Column21.HeaderText = "Retry";
            this.Column21.Name = "Column21";
            this.Column21.ReadOnly = true;
            this.Column21.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column21.Width = 50;
            // 
            // dataGridViewTextBoxColumn81
            // 
            this.dataGridViewTextBoxColumn81.HeaderText = "Tool";
            this.dataGridViewTextBoxColumn81.Name = "dataGridViewTextBoxColumn81";
            this.dataGridViewTextBoxColumn81.ReadOnly = true;
            this.dataGridViewTextBoxColumn81.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn81.Width = 50;
            // 
            // dataGridViewTextBoxColumn82
            // 
            this.dataGridViewTextBoxColumn82.HeaderText = "PanelID";
            this.dataGridViewTextBoxColumn82.Name = "dataGridViewTextBoxColumn82";
            this.dataGridViewTextBoxColumn82.ReadOnly = true;
            this.dataGridViewTextBoxColumn82.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn82.Width = 200;
            // 
            // lbResult3Title
            // 
            this.lbResult3Title.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbResult3Title.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResult3Title.ForeColor = System.Drawing.Color.White;
            this.lbResult3Title.Location = new System.Drawing.Point(3, -3);
            this.lbResult3Title.Name = "lbResult3Title";
            this.lbResult3Title.Size = new System.Drawing.Size(250, 25);
            this.lbResult3Title.TabIndex = 129;
            this.lbResult3Title.Text = "Inspection Result";
            this.lbResult3Title.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbResult3Title.DoubleClick += new System.EventHandler(this.lbResultTitle_Click);
            // 
            // gbBendResult4
            // 
            this.gbBendResult4.Controls.Add(this.lblOFFSET3);
            this.gbBendResult4.Controls.Add(this.dgvSpec4);
            this.gbBendResult4.Controls.Add(this.label16);
            this.gbBendResult4.Controls.Add(this.label17);
            this.gbBendResult4.Controls.Add(this.label18);
            this.gbBendResult4.Controls.Add(this.dgvResult4);
            this.gbBendResult4.Controls.Add(this.lbResult4Title);
            this.gbBendResult4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.gbBendResult4.Location = new System.Drawing.Point(263, 14);
            this.gbBendResult4.Name = "gbBendResult4";
            this.gbBendResult4.Size = new System.Drawing.Size(258, 401);
            this.gbBendResult4.TabIndex = 261;
            this.gbBendResult4.TabStop = false;
            this.gbBendResult4.Text = "Foam Align Result";
            // 
            // lblOFFSET3
            // 
            this.lblOFFSET3.BackColor = System.Drawing.Color.Black;
            this.lblOFFSET3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOFFSET3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblOFFSET3.ForeColor = System.Drawing.Color.Yellow;
            this.lblOFFSET3.Location = new System.Drawing.Point(203, 375);
            this.lblOFFSET3.Name = "lblOFFSET3";
            this.lblOFFSET3.Size = new System.Drawing.Size(51, 20);
            this.lblOFFSET3.TabIndex = 135;
            this.lblOFFSET3.Text = "OFFSET";
            this.lblOFFSET3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvSpec4
            // 
            this.dgvSpec4.AllowUserToAddRows = false;
            this.dgvSpec4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSpec4.ColumnHeadersVisible = false;
            this.dgvSpec4.Location = new System.Drawing.Point(5, 300);
            this.dgvSpec4.Name = "dgvSpec4";
            this.dgvSpec4.ReadOnly = true;
            this.dgvSpec4.RowHeadersVisible = false;
            dataGridViewCellStyle46.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle46.BackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle46.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle46.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle46.SelectionBackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle46.SelectionForeColor = System.Drawing.Color.White;
            this.dgvSpec4.RowsDefaultCellStyle = dataGridViewCellStyle46;
            this.dgvSpec4.RowTemplate.Height = 23;
            this.dgvSpec4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.dgvSpec4.Size = new System.Drawing.Size(193, 96);
            this.dgvSpec4.TabIndex = 134;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.Black;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.ForeColor = System.Drawing.Color.Yellow;
            this.label16.Location = new System.Drawing.Point(203, 352);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(51, 20);
            this.label16.TabIndex = 133;
            this.label16.Text = "MAX";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.Black;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label17.ForeColor = System.Drawing.Color.Yellow;
            this.label17.Location = new System.Drawing.Point(202, 326);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 20);
            this.label17.TabIndex = 132;
            this.label17.Text = "SPEC.";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.Black;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.ForeColor = System.Drawing.Color.Yellow;
            this.label18.Location = new System.Drawing.Point(202, 300);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(51, 20);
            this.label18.TabIndex = 131;
            this.label18.Text = "MIN";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvResult4
            // 
            this.dgvResult4.AllowUserToAddRows = false;
            this.dgvResult4.AllowUserToDeleteRows = false;
            this.dgvResult4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn80});
            this.dgvResult4.Location = new System.Drawing.Point(3, 26);
            this.dgvResult4.Name = "dgvResult4";
            this.dgvResult4.ReadOnly = true;
            this.dgvResult4.RowHeadersVisible = false;
            dataGridViewCellStyle51.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle51.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle51.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle51.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle51.SelectionForeColor = System.Drawing.Color.White;
            this.dgvResult4.RowsDefaultCellStyle = dataGridViewCellStyle51;
            this.dgvResult4.RowTemplate.Height = 23;
            this.dgvResult4.Size = new System.Drawing.Size(250, 268);
            this.dgvResult4.TabIndex = 130;
            // 
            // dataGridViewTextBoxColumn29
            // 
            dataGridViewCellStyle47.NullValue = "0";
            this.dataGridViewTextBoxColumn29.DefaultCellStyle = dataGridViewCellStyle47;
            this.dataGridViewTextBoxColumn29.HeaderText = "LX";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn29.Width = 50;
            // 
            // dataGridViewTextBoxColumn30
            // 
            dataGridViewCellStyle48.NullValue = "0";
            this.dataGridViewTextBoxColumn30.DefaultCellStyle = dataGridViewCellStyle48;
            this.dataGridViewTextBoxColumn30.HeaderText = "LY";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn30.Width = 50;
            // 
            // dataGridViewTextBoxColumn31
            // 
            dataGridViewCellStyle49.NullValue = "0";
            this.dataGridViewTextBoxColumn31.DefaultCellStyle = dataGridViewCellStyle49;
            this.dataGridViewTextBoxColumn31.HeaderText = "RX";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn31.Width = 50;
            // 
            // dataGridViewTextBoxColumn32
            // 
            dataGridViewCellStyle50.NullValue = "0";
            this.dataGridViewTextBoxColumn32.DefaultCellStyle = dataGridViewCellStyle50;
            this.dataGridViewTextBoxColumn32.HeaderText = "RY";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            this.dataGridViewTextBoxColumn32.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn32.Width = 50;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.HeaderText = "Retry";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn33.Width = 50;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.HeaderText = "Tool";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            this.dataGridViewTextBoxColumn35.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn35.Width = 50;
            // 
            // dataGridViewTextBoxColumn80
            // 
            this.dataGridViewTextBoxColumn80.HeaderText = "PanelID";
            this.dataGridViewTextBoxColumn80.Name = "dataGridViewTextBoxColumn80";
            this.dataGridViewTextBoxColumn80.ReadOnly = true;
            this.dataGridViewTextBoxColumn80.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn80.Width = 200;
            // 
            // lbResult4Title
            // 
            this.lbResult4Title.BackColor = System.Drawing.Color.DarkMagenta;
            this.lbResult4Title.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbResult4Title.ForeColor = System.Drawing.Color.White;
            this.lbResult4Title.Location = new System.Drawing.Point(4, -2);
            this.lbResult4Title.Name = "lbResult4Title";
            this.lbResult4Title.Size = new System.Drawing.Size(250, 25);
            this.lbResult4Title.TabIndex = 129;
            this.lbResult4Title.Text = "Inspection Result";
            this.lbResult4Title.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbResult4Title.DoubleClick += new System.EventHandler(this.lbResultTitle_Click);
            // 
            // pnOKNG
            // 
            this.pnOKNG.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnOKNG.Controls.Add(this.pnResult1);
            this.pnOKNG.Controls.Add(this.pnResult2);
            this.pnOKNG.Controls.Add(this.btnCPKReset);
            this.pnOKNG.Controls.Add(this.cbSCFInspResult);
            this.pnOKNG.Controls.Add(this.btnManualMark);
            this.pnOKNG.Controls.Add(this.pngraph);
            this.pnOKNG.Controls.Add(this.pnTimeData);
            this.pnOKNG.Controls.Add(this.cbResult);
            this.pnOKNG.Controls.Add(this.label15);
            this.pnOKNG.Controls.Add(this.dgvOKNG);
            this.pnOKNG.Location = new System.Drawing.Point(3, 3);
            this.pnOKNG.Name = "pnOKNG";
            this.pnOKNG.Size = new System.Drawing.Size(529, 893);
            this.pnOKNG.TabIndex = 307;
            // 
            // cbSCFInspResult
            // 
            this.cbSCFInspResult.AutoSize = true;
            this.cbSCFInspResult.ForeColor = System.Drawing.Color.White;
            this.cbSCFInspResult.Location = new System.Drawing.Point(299, 7);
            this.cbSCFInspResult.Name = "cbSCFInspResult";
            this.cbSCFInspResult.Size = new System.Drawing.Size(107, 16);
            this.cbSCFInspResult.TabIndex = 309;
            this.cbSCFInspResult.Text = "SCFInspResult";
            this.cbSCFInspResult.UseVisualStyleBackColor = true;
            this.cbSCFInspResult.Visible = false;
            this.cbSCFInspResult.CheckedChanged += new System.EventHandler(this.cbSCFInspResult_CheckedChanged);
            // 
            // btnManualMark
            // 
            this.btnManualMark.BackColor = System.Drawing.Color.Red;
            this.btnManualMark.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnManualMark.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnManualMark.Location = new System.Drawing.Point(419, 3);
            this.btnManualMark.Name = "btnManualMark";
            this.btnManualMark.Size = new System.Drawing.Size(105, 23);
            this.btnManualMark.TabIndex = 281;
            this.btnManualMark.Text = "Manual Mark";
            this.btnManualMark.UseVisualStyleBackColor = false;
            this.btnManualMark.Click += new System.EventHandler(this.btnManualMark_Click);
            // 
            // pnTimeData
            // 
            this.pnTimeData.Controls.Add(this.btnTodayDisp);
            this.pnTimeData.Controls.Add(this.btnDisp);
            this.pnTimeData.Controls.Add(this.dtpokngStart);
            this.pnTimeData.Controls.Add(this.dtpokngEnd);
            this.pnTimeData.Controls.Add(this.label19);
            this.pnTimeData.Location = new System.Drawing.Point(2, 29);
            this.pnTimeData.Name = "pnTimeData";
            this.pnTimeData.Size = new System.Drawing.Size(522, 34);
            this.pnTimeData.TabIndex = 308;
            // 
            // btnTodayDisp
            // 
            this.btnTodayDisp.Location = new System.Drawing.Point(429, 5);
            this.btnTodayDisp.Name = "btnTodayDisp";
            this.btnTodayDisp.Size = new System.Drawing.Size(86, 23);
            this.btnTodayDisp.TabIndex = 286;
            this.btnTodayDisp.Text = "Today Display";
            this.btnTodayDisp.UseVisualStyleBackColor = true;
            this.btnTodayDisp.Click += new System.EventHandler(this.btnTodayDisp_Click);
            // 
            // btnDisp
            // 
            this.btnDisp.Location = new System.Drawing.Point(362, 5);
            this.btnDisp.Name = "btnDisp";
            this.btnDisp.Size = new System.Drawing.Size(61, 23);
            this.btnDisp.TabIndex = 285;
            this.btnDisp.Text = "Display";
            this.btnDisp.UseVisualStyleBackColor = true;
            this.btnDisp.Click += new System.EventHandler(this.btnDisp_Click);
            // 
            // dtpokngStart
            // 
            this.dtpokngStart.Location = new System.Drawing.Point(4, 6);
            this.dtpokngStart.Name = "dtpokngStart";
            this.dtpokngStart.Size = new System.Drawing.Size(169, 21);
            this.dtpokngStart.TabIndex = 280;
            // 
            // dtpokngEnd
            // 
            this.dtpokngEnd.Location = new System.Drawing.Point(190, 6);
            this.dtpokngEnd.Name = "dtpokngEnd";
            this.dtpokngEnd.Size = new System.Drawing.Size(166, 21);
            this.dtpokngEnd.TabIndex = 281;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(174, 10);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(14, 12);
            this.label19.TabIndex = 284;
            this.label19.Text = "~";
            // 
            // cbResult
            // 
            this.cbResult.AutoSize = true;
            this.cbResult.ForeColor = System.Drawing.Color.White;
            this.cbResult.Location = new System.Drawing.Point(224, 6);
            this.cbResult.Name = "cbResult";
            this.cbResult.Size = new System.Drawing.Size(59, 16);
            this.cbResult.TabIndex = 307;
            this.cbResult.Text = "Result";
            this.cbResult.UseVisualStyleBackColor = true;
            this.cbResult.CheckedChanged += new System.EventHandler(this.cbResult_CheckedChanged);
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.YellowGreen;
            this.label15.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(-1, 1);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(218, 25);
            this.label15.TabIndex = 271;
            this.label15.Text = "Result Display";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pnInfo1
            // 
            this.pnInfo1.Controls.Add(this.tabControl1);
            this.pnInfo1.Location = new System.Drawing.Point(1224, 6);
            this.pnInfo1.Name = "pnInfo1";
            this.pnInfo1.Size = new System.Drawing.Size(350, 150);
            this.pnInfo1.TabIndex = 308;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.ItemSize = new System.Drawing.Size(48, 18);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(350, 150);
            this.tabControl1.TabIndex = 290;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.btnOff);
            this.tabPage5.Controls.Add(this.btnOn);
            this.tabPage5.Controls.Add(this.comboBox1);
            this.tabPage5.Controls.Add(this.button1);
            this.tabPage5.Controls.Add(this.PCYTEST);
            this.tabPage5.Controls.Add(this.listBox1);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(342, 124);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = "Data";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // btnOff
            // 
            this.btnOff.Location = new System.Drawing.Point(99, 77);
            this.btnOff.Name = "btnOff";
            this.btnOff.Size = new System.Drawing.Size(75, 23);
            this.btnOff.TabIndex = 314;
            this.btnOff.Text = "Off";
            this.btnOff.UseVisualStyleBackColor = true;
            this.btnOff.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // btnOn
            // 
            this.btnOn.Location = new System.Drawing.Point(18, 79);
            this.btnOn.Name = "btnOn";
            this.btnOn.Size = new System.Drawing.Size(75, 23);
            this.btnOn.TabIndex = 313;
            this.btnOn.Text = "On";
            this.btnOn.UseVisualStyleBackColor = true;
            this.btnOn.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20",
            "21",
            "22",
            "23",
            "24",
            "25",
            "26",
            "27",
            "28",
            "29",
            "30",
            "31"});
            this.comboBox1.Location = new System.Drawing.Point(191, 77);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 312;
            this.comboBox1.Visible = false;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Location = new System.Drawing.Point(545, 17);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(80, 52);
            this.button1.TabIndex = 311;
            this.button1.Text = "OFF";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click_2);
            // 
            // PCYTEST
            // 
            this.PCYTEST.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.PCYTEST.Location = new System.Drawing.Point(431, 17);
            this.PCYTEST.Name = "PCYTEST";
            this.PCYTEST.Size = new System.Drawing.Size(80, 52);
            this.PCYTEST.TabIndex = 310;
            this.PCYTEST.Text = "ON";
            this.PCYTEST.UseVisualStyleBackColor = true;
            this.PCYTEST.Visible = false;
            this.PCYTEST.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.dgvAlign1);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(342, 124);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = "Align";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // dgvAlign1
            // 
            this.dgvAlign1.AllowUserToAddRows = false;
            this.dgvAlign1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle52.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle52.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle52.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle52.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle52.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle52.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAlign1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle52;
            this.dgvAlign1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAlign1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column16,
            this.dataGridViewTextBoxColumn36,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39,
            this.dataGridViewTextBoxColumn40,
            this.dataGridViewTextBoxColumn41,
            this.dataGridViewTextBoxColumn42,
            this.Column17,
            this.Column26,
            this.Column27});
            dataGridViewCellStyle53.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle53.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle53.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle53.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle53.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle53.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAlign1.DefaultCellStyle = dataGridViewCellStyle53;
            this.dgvAlign1.Location = new System.Drawing.Point(3, 3);
            this.dgvAlign1.Name = "dgvAlign1";
            this.dgvAlign1.ReadOnly = true;
            dataGridViewCellStyle54.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle54.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle54.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle54.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle54.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle54.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAlign1.RowHeadersDefaultCellStyle = dataGridViewCellStyle54;
            this.dgvAlign1.RowHeadersVisible = false;
            dataGridViewCellStyle55.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle55.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle55.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle55.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle55.SelectionForeColor = System.Drawing.Color.White;
            this.dgvAlign1.RowsDefaultCellStyle = dataGridViewCellStyle55;
            this.dgvAlign1.RowTemplate.Height = 23;
            this.dgvAlign1.Size = new System.Drawing.Size(664, 87);
            this.dgvAlign1.TabIndex = 132;
            // 
            // Column16
            // 
            this.Column16.HeaderText = "CellID";
            this.Column16.Name = "Column16";
            this.Column16.ReadOnly = true;
            this.Column16.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column16.Width = 120;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.HeaderText = "LX";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            this.dataGridViewTextBoxColumn36.ReadOnly = true;
            this.dataGridViewTextBoxColumn36.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn36.Width = 50;
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.HeaderText = "LY";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            this.dataGridViewTextBoxColumn37.ReadOnly = true;
            this.dataGridViewTextBoxColumn37.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn37.Width = 50;
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.HeaderText = "RX";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            this.dataGridViewTextBoxColumn38.ReadOnly = true;
            this.dataGridViewTextBoxColumn38.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn38.Width = 50;
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.HeaderText = "RY";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            this.dataGridViewTextBoxColumn39.ReadOnly = true;
            this.dataGridViewTextBoxColumn39.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn39.Width = 50;
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.HeaderText = "X";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.ReadOnly = true;
            this.dataGridViewTextBoxColumn40.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn40.Width = 50;
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.HeaderText = "Y";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            this.dataGridViewTextBoxColumn41.ReadOnly = true;
            this.dataGridViewTextBoxColumn41.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn41.Width = 50;
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.HeaderText = "T";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            this.dataGridViewTextBoxColumn42.ReadOnly = true;
            this.dataGridViewTextBoxColumn42.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn42.Width = 50;
            // 
            // Column17
            // 
            this.Column17.HeaderText = "Retry";
            this.Column17.Name = "Column17";
            this.Column17.ReadOnly = true;
            this.Column17.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column17.Width = 40;
            // 
            // Column26
            // 
            this.Column26.HeaderText = "Score1";
            this.Column26.Name = "Column26";
            this.Column26.ReadOnly = true;
            this.Column26.Width = 50;
            // 
            // Column27
            // 
            this.Column27.HeaderText = "Score2";
            this.Column27.Name = "Column27";
            this.Column27.ReadOnly = true;
            this.Column27.Width = 50;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.dgvError1);
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Size = new System.Drawing.Size(342, 124);
            this.tabPage13.TabIndex = 2;
            this.tabPage13.Text = "Error";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // dgvError1
            // 
            this.dgvError1.AllowUserToAddRows = false;
            this.dgvError1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle56.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle56.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle56.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle56.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle56.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle56.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvError1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle56;
            this.dgvError1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvError1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn70,
            this.dataGridViewTextBoxColumn71});
            dataGridViewCellStyle57.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle57.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle57.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle57.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle57.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle57.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvError1.DefaultCellStyle = dataGridViewCellStyle57;
            this.dgvError1.Location = new System.Drawing.Point(3, 3);
            this.dgvError1.Name = "dgvError1";
            this.dgvError1.ReadOnly = true;
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle58.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle58.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle58.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle58.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvError1.RowHeadersDefaultCellStyle = dataGridViewCellStyle58;
            this.dgvError1.RowHeadersVisible = false;
            dataGridViewCellStyle59.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle59.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle59.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle59.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle59.SelectionForeColor = System.Drawing.Color.White;
            this.dgvError1.RowsDefaultCellStyle = dataGridViewCellStyle59;
            this.dgvError1.RowTemplate.Height = 23;
            this.dgvError1.Size = new System.Drawing.Size(664, 87);
            this.dgvError1.TabIndex = 133;
            // 
            // dataGridViewTextBoxColumn70
            // 
            this.dataGridViewTextBoxColumn70.HeaderText = "CellID";
            this.dataGridViewTextBoxColumn70.Name = "dataGridViewTextBoxColumn70";
            this.dataGridViewTextBoxColumn70.ReadOnly = true;
            this.dataGridViewTextBoxColumn70.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn70.Width = 170;
            // 
            // dataGridViewTextBoxColumn71
            // 
            this.dataGridViewTextBoxColumn71.HeaderText = "Error";
            this.dataGridViewTextBoxColumn71.Name = "dataGridViewTextBoxColumn71";
            this.dataGridViewTextBoxColumn71.ReadOnly = true;
            this.dataGridViewTextBoxColumn71.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn71.Width = 150;
            // 
            // pnInfo2
            // 
            this.pnInfo2.Controls.Add(this.tabControl2);
            this.pnInfo2.Location = new System.Drawing.Point(1224, 175);
            this.pnInfo2.Name = "pnInfo2";
            this.pnInfo2.Size = new System.Drawing.Size(350, 150);
            this.pnInfo2.TabIndex = 309;
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage14);
            this.tabControl2.Location = new System.Drawing.Point(0, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(350, 150);
            this.tabControl2.TabIndex = 290;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.listBox2);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(342, 124);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "Log";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // listBox2
            // 
            this.listBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox2.FormattingEnabled = true;
            this.listBox2.HorizontalScrollbar = true;
            this.listBox2.ItemHeight = 12;
            this.listBox2.Location = new System.Drawing.Point(3, 3);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(336, 118);
            this.listBox2.TabIndex = 132;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.dgvAlign2);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(342, 124);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "Align";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // dgvAlign2
            // 
            this.dgvAlign2.AllowUserToAddRows = false;
            this.dgvAlign2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle60.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle60.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle60.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle60.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle60.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle60.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle60.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAlign2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle60;
            this.dgvAlign2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAlign2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn43,
            this.dataGridViewTextBoxColumn44,
            this.dataGridViewTextBoxColumn45,
            this.dataGridViewTextBoxColumn46,
            this.dataGridViewTextBoxColumn47,
            this.dataGridViewTextBoxColumn48,
            this.dataGridViewTextBoxColumn49,
            this.dataGridViewTextBoxColumn50,
            this.dataGridViewTextBoxColumn67,
            this.dataGridViewTextBoxColumn85,
            this.dataGridViewTextBoxColumn86});
            dataGridViewCellStyle61.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle61.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle61.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle61.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle61.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle61.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvAlign2.DefaultCellStyle = dataGridViewCellStyle61;
            this.dgvAlign2.Location = new System.Drawing.Point(3, 3);
            this.dgvAlign2.Name = "dgvAlign2";
            this.dgvAlign2.ReadOnly = true;
            dataGridViewCellStyle62.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle62.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle62.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle62.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle62.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle62.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle62.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvAlign2.RowHeadersDefaultCellStyle = dataGridViewCellStyle62;
            this.dgvAlign2.RowHeadersVisible = false;
            dataGridViewCellStyle63.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle63.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle63.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle63.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle63.SelectionForeColor = System.Drawing.Color.White;
            this.dgvAlign2.RowsDefaultCellStyle = dataGridViewCellStyle63;
            this.dgvAlign2.RowTemplate.Height = 23;
            this.dgvAlign2.Size = new System.Drawing.Size(664, 87);
            this.dgvAlign2.TabIndex = 133;
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.HeaderText = "CellID";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            this.dataGridViewTextBoxColumn43.ReadOnly = true;
            this.dataGridViewTextBoxColumn43.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn43.Width = 120;
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.HeaderText = "LX";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            this.dataGridViewTextBoxColumn44.ReadOnly = true;
            this.dataGridViewTextBoxColumn44.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn44.Width = 50;
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.HeaderText = "LY";
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            this.dataGridViewTextBoxColumn45.ReadOnly = true;
            this.dataGridViewTextBoxColumn45.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn45.Width = 50;
            // 
            // dataGridViewTextBoxColumn46
            // 
            this.dataGridViewTextBoxColumn46.HeaderText = "RX";
            this.dataGridViewTextBoxColumn46.Name = "dataGridViewTextBoxColumn46";
            this.dataGridViewTextBoxColumn46.ReadOnly = true;
            this.dataGridViewTextBoxColumn46.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn46.Width = 50;
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.HeaderText = "RY";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            this.dataGridViewTextBoxColumn47.ReadOnly = true;
            this.dataGridViewTextBoxColumn47.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn47.Width = 50;
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.HeaderText = "X";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            this.dataGridViewTextBoxColumn48.ReadOnly = true;
            this.dataGridViewTextBoxColumn48.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn48.Width = 50;
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.HeaderText = "Y";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            this.dataGridViewTextBoxColumn49.ReadOnly = true;
            this.dataGridViewTextBoxColumn49.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn49.Width = 50;
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.HeaderText = "T";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            this.dataGridViewTextBoxColumn50.ReadOnly = true;
            this.dataGridViewTextBoxColumn50.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn50.Width = 50;
            // 
            // dataGridViewTextBoxColumn67
            // 
            this.dataGridViewTextBoxColumn67.HeaderText = "Retry";
            this.dataGridViewTextBoxColumn67.Name = "dataGridViewTextBoxColumn67";
            this.dataGridViewTextBoxColumn67.ReadOnly = true;
            this.dataGridViewTextBoxColumn67.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn67.Width = 40;
            // 
            // dataGridViewTextBoxColumn85
            // 
            this.dataGridViewTextBoxColumn85.HeaderText = "Score1";
            this.dataGridViewTextBoxColumn85.Name = "dataGridViewTextBoxColumn85";
            this.dataGridViewTextBoxColumn85.ReadOnly = true;
            this.dataGridViewTextBoxColumn85.Width = 50;
            // 
            // dataGridViewTextBoxColumn86
            // 
            this.dataGridViewTextBoxColumn86.HeaderText = "Score2";
            this.dataGridViewTextBoxColumn86.Name = "dataGridViewTextBoxColumn86";
            this.dataGridViewTextBoxColumn86.ReadOnly = true;
            this.dataGridViewTextBoxColumn86.Width = 50;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.dgvError2);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Size = new System.Drawing.Size(342, 124);
            this.tabPage14.TabIndex = 2;
            this.tabPage14.Text = "Error";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // dgvError2
            // 
            this.dgvError2.AllowUserToAddRows = false;
            this.dgvError2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle64.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle64.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle64.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle64.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle64.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle64.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle64.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvError2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle64;
            this.dgvError2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvError2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn72,
            this.dataGridViewTextBoxColumn73});
            dataGridViewCellStyle65.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle65.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle65.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle65.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle65.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle65.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle65.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvError2.DefaultCellStyle = dataGridViewCellStyle65;
            this.dgvError2.Location = new System.Drawing.Point(3, 3);
            this.dgvError2.Name = "dgvError2";
            this.dgvError2.ReadOnly = true;
            dataGridViewCellStyle66.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle66.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle66.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle66.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle66.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle66.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle66.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvError2.RowHeadersDefaultCellStyle = dataGridViewCellStyle66;
            this.dgvError2.RowHeadersVisible = false;
            dataGridViewCellStyle67.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle67.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle67.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle67.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle67.SelectionForeColor = System.Drawing.Color.White;
            this.dgvError2.RowsDefaultCellStyle = dataGridViewCellStyle67;
            this.dgvError2.RowTemplate.Height = 23;
            this.dgvError2.Size = new System.Drawing.Size(664, 87);
            this.dgvError2.TabIndex = 134;
            // 
            // dataGridViewTextBoxColumn72
            // 
            this.dataGridViewTextBoxColumn72.HeaderText = "CellID";
            this.dataGridViewTextBoxColumn72.Name = "dataGridViewTextBoxColumn72";
            this.dataGridViewTextBoxColumn72.ReadOnly = true;
            this.dataGridViewTextBoxColumn72.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn72.Width = 170;
            // 
            // dataGridViewTextBoxColumn73
            // 
            this.dataGridViewTextBoxColumn73.HeaderText = "Error";
            this.dataGridViewTextBoxColumn73.Name = "dataGridViewTextBoxColumn73";
            this.dataGridViewTextBoxColumn73.ReadOnly = true;
            this.dataGridViewTextBoxColumn73.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn73.Width = 150;
            // 
            // lblCycleTime2
            // 
            this.lblCycleTime2.BackColor = System.Drawing.Color.Black;
            this.lblCycleTime2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCycleTime2.ForeColor = System.Drawing.Color.Yellow;
            this.lblCycleTime2.Location = new System.Drawing.Point(1054, 306);
            this.lblCycleTime2.Name = "lblCycleTime2";
            this.lblCycleTime2.Size = new System.Drawing.Size(113, 20);
            this.lblCycleTime2.TabIndex = 290;
            this.lblCycleTime2.Text = "C/T";
            this.lblCycleTime2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRetryCount2
            // 
            this.lblRetryCount2.BackColor = System.Drawing.Color.Black;
            this.lblRetryCount2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRetryCount2.ForeColor = System.Drawing.Color.Yellow;
            this.lblRetryCount2.Location = new System.Drawing.Point(1168, 306);
            this.lblRetryCount2.Name = "lblRetryCount2";
            this.lblRetryCount2.Size = new System.Drawing.Size(48, 20);
            this.lblRetryCount2.TabIndex = 290;
            this.lblRetryCount2.Text = "Retry";
            this.lblRetryCount2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPPID2
            // 
            this.lblPPID2.BackColor = System.Drawing.Color.Black;
            this.lblPPID2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPPID2.ForeColor = System.Drawing.Color.Yellow;
            this.lblPPID2.Location = new System.Drawing.Point(881, 306);
            this.lblPPID2.Name = "lblPPID2";
            this.lblPPID2.Size = new System.Drawing.Size(172, 20);
            this.lblPPID2.TabIndex = 290;
            this.lblPPID2.Text = "Cell ID";
            this.lblPPID2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnInfo3
            // 
            this.pnInfo3.Controls.Add(this.tabControl3);
            this.pnInfo3.Location = new System.Drawing.Point(541, 787);
            this.pnInfo3.Name = "pnInfo3";
            this.pnInfo3.Size = new System.Drawing.Size(677, 106);
            this.pnInfo3.TabIndex = 310;
            // 
            // lblPPID4
            // 
            this.lblPPID4.BackColor = System.Drawing.Color.Black;
            this.lblPPID4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPPID4.ForeColor = System.Drawing.Color.Yellow;
            this.lblPPID4.Location = new System.Drawing.Point(1224, 764);
            this.lblPPID4.Name = "lblPPID4";
            this.lblPPID4.Size = new System.Drawing.Size(371, 20);
            this.lblPPID4.TabIndex = 290;
            this.lblPPID4.Text = "Cell ID";
            this.lblPPID4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCycleTime4
            // 
            this.lblCycleTime4.BackColor = System.Drawing.Color.Black;
            this.lblCycleTime4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCycleTime4.ForeColor = System.Drawing.Color.Yellow;
            this.lblCycleTime4.Location = new System.Drawing.Point(1601, 764);
            this.lblCycleTime4.Name = "lblCycleTime4";
            this.lblCycleTime4.Size = new System.Drawing.Size(150, 20);
            this.lblCycleTime4.TabIndex = 290;
            this.lblCycleTime4.Text = "C/T";
            this.lblCycleTime4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRetryCount4
            // 
            this.lblRetryCount4.BackColor = System.Drawing.Color.Black;
            this.lblRetryCount4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRetryCount4.ForeColor = System.Drawing.Color.Yellow;
            this.lblRetryCount4.Location = new System.Drawing.Point(1754, 764);
            this.lblRetryCount4.Name = "lblRetryCount4";
            this.lblRetryCount4.Size = new System.Drawing.Size(150, 20);
            this.lblRetryCount4.TabIndex = 290;
            this.lblRetryCount4.Text = "Retry";
            this.lblRetryCount4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnInfo4
            // 
            this.pnInfo4.Controls.Add(this.tabControl4);
            this.pnInfo4.Location = new System.Drawing.Point(1223, 788);
            this.pnInfo4.Name = "pnInfo4";
            this.pnInfo4.Size = new System.Drawing.Size(679, 105);
            this.pnInfo4.TabIndex = 311;
            // 
            // lblPPID3
            // 
            this.lblPPID3.BackColor = System.Drawing.Color.Black;
            this.lblPPID3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPPID3.ForeColor = System.Drawing.Color.Yellow;
            this.lblPPID3.Location = new System.Drawing.Point(541, 764);
            this.lblPPID3.Name = "lblPPID3";
            this.lblPPID3.Size = new System.Drawing.Size(365, 20);
            this.lblPPID3.TabIndex = 290;
            this.lblPPID3.Text = "Cell ID";
            this.lblPPID3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCycleTime3
            // 
            this.lblCycleTime3.BackColor = System.Drawing.Color.Black;
            this.lblCycleTime3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCycleTime3.ForeColor = System.Drawing.Color.Yellow;
            this.lblCycleTime3.Location = new System.Drawing.Point(912, 764);
            this.lblCycleTime3.Name = "lblCycleTime3";
            this.lblCycleTime3.Size = new System.Drawing.Size(150, 20);
            this.lblCycleTime3.TabIndex = 290;
            this.lblCycleTime3.Text = "C/T";
            this.lblCycleTime3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblRetryCount3
            // 
            this.lblRetryCount3.BackColor = System.Drawing.Color.Black;
            this.lblRetryCount3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblRetryCount3.ForeColor = System.Drawing.Color.Yellow;
            this.lblRetryCount3.Location = new System.Drawing.Point(1068, 764);
            this.lblRetryCount3.Name = "lblRetryCount3";
            this.lblRetryCount3.Size = new System.Drawing.Size(150, 20);
            this.lblRetryCount3.TabIndex = 290;
            this.lblRetryCount3.Text = "Retry";
            this.lblRetryCount3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dataGridViewTextBoxColumn101
            // 
            this.dataGridViewTextBoxColumn101.HeaderText = "Score2";
            this.dataGridViewTextBoxColumn101.Name = "dataGridViewTextBoxColumn101";
            this.dataGridViewTextBoxColumn101.ReadOnly = true;
            this.dataGridViewTextBoxColumn101.Width = 50;
            // 
            // dataGridViewTextBoxColumn100
            // 
            this.dataGridViewTextBoxColumn100.HeaderText = "Score1";
            this.dataGridViewTextBoxColumn100.Name = "dataGridViewTextBoxColumn100";
            this.dataGridViewTextBoxColumn100.ReadOnly = true;
            this.dataGridViewTextBoxColumn100.Width = 50;
            // 
            // dataGridViewTextBoxColumn99
            // 
            this.dataGridViewTextBoxColumn99.HeaderText = "Retry";
            this.dataGridViewTextBoxColumn99.Name = "dataGridViewTextBoxColumn99";
            this.dataGridViewTextBoxColumn99.ReadOnly = true;
            this.dataGridViewTextBoxColumn99.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn99.Width = 40;
            // 
            // dataGridViewTextBoxColumn98
            // 
            this.dataGridViewTextBoxColumn98.HeaderText = "T";
            this.dataGridViewTextBoxColumn98.Name = "dataGridViewTextBoxColumn98";
            this.dataGridViewTextBoxColumn98.ReadOnly = true;
            this.dataGridViewTextBoxColumn98.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn98.Width = 50;
            // 
            // dataGridViewTextBoxColumn97
            // 
            this.dataGridViewTextBoxColumn97.HeaderText = "Y";
            this.dataGridViewTextBoxColumn97.Name = "dataGridViewTextBoxColumn97";
            this.dataGridViewTextBoxColumn97.ReadOnly = true;
            this.dataGridViewTextBoxColumn97.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn97.Width = 50;
            // 
            // dataGridViewTextBoxColumn96
            // 
            this.dataGridViewTextBoxColumn96.HeaderText = "X";
            this.dataGridViewTextBoxColumn96.Name = "dataGridViewTextBoxColumn96";
            this.dataGridViewTextBoxColumn96.ReadOnly = true;
            this.dataGridViewTextBoxColumn96.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn96.Width = 50;
            // 
            // dataGridViewTextBoxColumn95
            // 
            this.dataGridViewTextBoxColumn95.HeaderText = "RY";
            this.dataGridViewTextBoxColumn95.Name = "dataGridViewTextBoxColumn95";
            this.dataGridViewTextBoxColumn95.ReadOnly = true;
            this.dataGridViewTextBoxColumn95.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn95.Width = 50;
            // 
            // dataGridViewTextBoxColumn94
            // 
            this.dataGridViewTextBoxColumn94.HeaderText = "RX";
            this.dataGridViewTextBoxColumn94.Name = "dataGridViewTextBoxColumn94";
            this.dataGridViewTextBoxColumn94.ReadOnly = true;
            this.dataGridViewTextBoxColumn94.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn94.Width = 50;
            // 
            // dataGridViewTextBoxColumn93
            // 
            this.dataGridViewTextBoxColumn93.HeaderText = "LY";
            this.dataGridViewTextBoxColumn93.Name = "dataGridViewTextBoxColumn93";
            this.dataGridViewTextBoxColumn93.ReadOnly = true;
            this.dataGridViewTextBoxColumn93.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn93.Width = 50;
            // 
            // dataGridViewTextBoxColumn92
            // 
            this.dataGridViewTextBoxColumn92.HeaderText = "LX";
            this.dataGridViewTextBoxColumn92.Name = "dataGridViewTextBoxColumn92";
            this.dataGridViewTextBoxColumn92.ReadOnly = true;
            this.dataGridViewTextBoxColumn92.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn92.Width = 50;
            // 
            // dataGridViewTextBoxColumn91
            // 
            this.dataGridViewTextBoxColumn91.HeaderText = "CellID";
            this.dataGridViewTextBoxColumn91.Name = "dataGridViewTextBoxColumn91";
            this.dataGridViewTextBoxColumn91.ReadOnly = true;
            this.dataGridViewTextBoxColumn91.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn91.Width = 120;
            // 
            // tmr1Sec
            // 
            this.tmr1Sec.Enabled = true;
            this.tmr1Sec.Interval = 500;
            this.tmr1Sec.Tick += new System.EventHandler(this.tmr1Sec_Tick);
            // 
            // tmrDispChart
            // 
            this.tmrDispChart.Enabled = true;
            this.tmrDispChart.Interval = 500;
            this.tmrDispChart.Tick += new System.EventHandler(this.tmrDispChart_Tick);
            // 
            // dgvResult2
            // 
            this.dgvResult2.AllowUserToAddRows = false;
            this.dgvResult2.AllowUserToDeleteRows = false;
            this.dgvResult2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvResult2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this.dgvResult2.Location = new System.Drawing.Point(4, 26);
            this.dgvResult2.Name = "dgvResult2";
            this.dgvResult2.ReadOnly = true;
            this.dgvResult2.RowHeadersVisible = false;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.Gray;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.White;
            this.dgvResult2.RowsDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvResult2.RowTemplate.Height = 23;
            this.dgvResult2.Size = new System.Drawing.Size(250, 266);
            this.dgvResult2.TabIndex = 136;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle7.NullValue = "0";
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn1.HeaderText = "LX";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 48;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle8.NullValue = "0";
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle8;
            this.dataGridViewTextBoxColumn2.HeaderText = "LY";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn2.Width = 48;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle9.NullValue = "0";
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridViewTextBoxColumn3.HeaderText = "RX";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn3.Width = 48;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle10.NullValue = "0";
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn4.HeaderText = "RY";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 48;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "PanelID";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn5.Width = 200;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "APNCode";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "No";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 40;
            // 
            // lblOFFSET0
            // 
            this.lblOFFSET0.BackColor = System.Drawing.Color.Black;
            this.lblOFFSET0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOFFSET0.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblOFFSET0.ForeColor = System.Drawing.Color.Yellow;
            this.lblOFFSET0.Location = new System.Drawing.Point(202, 375);
            this.lblOFFSET0.Name = "lblOFFSET0";
            this.lblOFFSET0.Size = new System.Drawing.Size(51, 20);
            this.lblOFFSET0.TabIndex = 139;
            this.lblOFFSET0.Text = "OFFSET";
            this.lblOFFSET0.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.ForeColor = System.Drawing.Color.Yellow;
            this.label1.Location = new System.Drawing.Point(202, 350);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 20);
            this.label1.TabIndex = 138;
            this.label1.Text = "MAX";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.ForeColor = System.Drawing.Color.Yellow;
            this.label2.Location = new System.Drawing.Point(202, 325);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 137;
            this.label2.Text = "SPEC.";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.ForeColor = System.Drawing.Color.Yellow;
            this.label3.Location = new System.Drawing.Point(202, 300);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 20);
            this.label3.TabIndex = 136;
            this.label3.Text = "MIN";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ucAutoMain
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.Black;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.lblCycleTime2);
            this.Controls.Add(this.pn3);
            this.Controls.Add(this.lblPPID4);
            this.Controls.Add(this.lblPPID1);
            this.Controls.Add(this.lblRetryCount2);
            this.Controls.Add(this.lblCycleTime1);
            this.Controls.Add(this.lblPPID2);
            this.Controls.Add(this.lblPPID3);
            this.Controls.Add(this.lblRetryCount1);
            this.Controls.Add(this.lblCycleTime3);
            this.Controls.Add(this.pn4);
            this.Controls.Add(this.lblRetryCount3);
            this.Controls.Add(this.pnInfo4);
            this.Controls.Add(this.pnInfo3);
            this.Controls.Add(this.lblCycleTime4);
            this.Controls.Add(this.pnAPC);
            this.Controls.Add(this.lblRetryCount4);
            this.Controls.Add(this.pnInfo2);
            this.Controls.Add(this.pnInfo1);
            this.Controls.Add(this.pn2);
            this.Controls.Add(this.pn1);
            this.Controls.Add(this.pnOKNG);
            this.Name = "ucAutoMain";
            this.Size = new System.Drawing.Size(1913, 900);
            this.pn4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogDS4)).EndInit();
            this.pn3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogDS3)).EndInit();
            this.pn2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogDS2)).EndInit();
            this.pn1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogDS1)).EndInit();
            this.pnResult1.ResumeLayout(false);
            this.gbBendResult1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpec1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpec2)).EndInit();
            this.gbBendResult2.ResumeLayout(false);
            this.pn8.ResumeLayout(false);
            this.pnHeightDisp.ResumeLayout(false);
            this.pnInfo5.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage18.ResumeLayout(false);
            this.tabPage19.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlign5)).EndInit();
            this.tabPage20.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvError5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cogDS8)).EndInit();
            this.pn6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogDS6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOKNG)).EndInit();
            this.pn5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogDS5)).EndInit();
            this.pngraph.ResumeLayout(false);
            this.pnGrahpData.ResumeLayout(false);
            this.pnGrahpData.PerformLayout();
            this.tcGraph.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.pnSquareLength.ResumeLayout(false);
            this.pnSquareLength.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp1_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp1_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp1_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp1_1)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp2_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp2_1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp3_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp3_1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp4_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ctDisp4_1)).EndInit();
            this.pnAPC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAPC2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAPC1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.pn7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.cogDS7)).EndInit();
            this.tabControl3.ResumeLayout(false);
            this.tabPage9.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlign3)).EndInit();
            this.tabPage15.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvError3)).EndInit();
            this.tabControl4.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.tabPage12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlign4)).EndInit();
            this.tabPage16.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvError4)).EndInit();
            this.pnResult2.ResumeLayout(false);
            this.gbBendResult3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpec3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult3)).EndInit();
            this.gbBendResult4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvSpec4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult4)).EndInit();
            this.pnOKNG.ResumeLayout(false);
            this.pnOKNG.PerformLayout();
            this.pnTimeData.ResumeLayout(false);
            this.pnTimeData.PerformLayout();
            this.pnInfo1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlign1)).EndInit();
            this.tabPage13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvError1)).EndInit();
            this.pnInfo2.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAlign2)).EndInit();
            this.tabPage14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvError2)).EndInit();
            this.pnInfo3.ResumeLayout(false);
            this.pnInfo4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvResult2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer tmrIF;
        private System.IO.Ports.SerialPort spLight1;
        private System.IO.Ports.SerialPort spLight2;
        private System.IO.Ports.SerialPort spLight3;
        private System.Windows.Forms.Panel pn4;
        private Cognex.VisionPro.Display.CogDisplay cogDS4;
        private System.Windows.Forms.Label lb4;
        private System.Windows.Forms.Panel pn3;
        private Cognex.VisionPro.Display.CogDisplay cogDS3;
        private System.Windows.Forms.Label lb3;
        private System.Windows.Forms.Panel pn2;
        private Cognex.VisionPro.Display.CogDisplay cogDS2;
        private System.Windows.Forms.Label lb2;
        private System.Windows.Forms.Panel pn1;
        private Cognex.VisionPro.Display.CogDisplay cogDS1;
        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.Panel pn8;
        private Cognex.VisionPro.Display.CogDisplay cogDS8;
        private System.Windows.Forms.Label lb8;
        private System.Windows.Forms.Panel pn6;
        private Cognex.VisionPro.Display.CogDisplay cogDS6;
        private System.Windows.Forms.Label lb6;
        private System.Windows.Forms.Panel pn5;
        private Cognex.VisionPro.Display.CogDisplay cogDS5;
        private System.Windows.Forms.Label lb5;
        private System.Windows.Forms.Panel pn7;
        private Cognex.VisionPro.Display.CogDisplay cogDS7;
        private System.Windows.Forms.Label lb7;
        private System.Windows.Forms.Label lbAlign2;
        private System.Windows.Forms.Label lbAlign1;
        private System.Windows.Forms.Label lbAlign3;
        private System.Windows.Forms.Label lbAlign4;
        private System.Windows.Forms.Label lbAlign6;
        private System.Windows.Forms.Label lbAlign7;
        private System.Windows.Forms.Label lbAlign8;
        private System.Windows.Forms.Label lblScore4;
        private System.Windows.Forms.Label lblSearchResult4;
        private System.Windows.Forms.Label lblScore3;
        private System.Windows.Forms.Label lblSearchResult3;
        private System.Windows.Forms.Label lblScore2;
        private System.Windows.Forms.Label lblSearchResult2;
        private System.Windows.Forms.Label lblScore1;
        private System.Windows.Forms.Label lblSearchResult1;
        private System.Windows.Forms.Label lblScore8;
        private System.Windows.Forms.Label lblSearchResult8;
        private System.Windows.Forms.Label lblScore6;
        private System.Windows.Forms.Label lblSearchResult6;
        private System.Windows.Forms.Label lblScore5;
        private System.Windows.Forms.Label lblSearchResult5;
        private System.Windows.Forms.Label lblScore7;
        private System.Windows.Forms.Label lblSearchResult7;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Panel pngraph;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DateTimePicker dtpStart;
        private System.Windows.Forms.Button btnDisp1;
        private System.Windows.Forms.Button button_PLC14;
        private System.Windows.Forms.CheckBox checkBox_Overlay4;
        private System.Windows.Forms.Button button_PLC4;
        private System.Windows.Forms.Button button_PC4;
        private System.Windows.Forms.Button button_PLC13;
        private System.Windows.Forms.CheckBox checkBox_Overlay3;
        private System.Windows.Forms.Button button_PLC3;
        private System.Windows.Forms.Button button_PC3;
        private System.Windows.Forms.Button button_PLC12;
        private System.Windows.Forms.CheckBox checkBox_Overlay2;
        private System.Windows.Forms.Button button_PLC2;
        private System.Windows.Forms.Button button_PC2;
        private System.Windows.Forms.Button button_PLC11;
        private System.Windows.Forms.Button button_PLC1;
        private System.Windows.Forms.Button button_PC1;
        private System.Windows.Forms.CheckBox checkBox_Overlay1;
        private System.Windows.Forms.Button button_PLC18;
        private System.Windows.Forms.CheckBox checkBox_Overlay8;
        private System.Windows.Forms.Button button_PLC8;
        private System.Windows.Forms.Button button_PC8;
        private System.Windows.Forms.Button button_PLC16;
        private System.Windows.Forms.Button button_PLC6;
        private System.Windows.Forms.Button button_PC6;
        private System.Windows.Forms.CheckBox checkBox_Overlay6;
        private System.Windows.Forms.Button button_PLC15;
        private System.Windows.Forms.Button button_PLC5;
        private System.Windows.Forms.Button button_PC5;
        private System.Windows.Forms.CheckBox checkBox_Overlay5;
        private System.Windows.Forms.Button button_PLC17;
        private System.Windows.Forms.Button button_PLC7;
        private System.Windows.Forms.Button button_PC7;
        private System.Windows.Forms.CheckBox checkBox_Overlay7;
        private System.Windows.Forms.Label lblRetryCount1;
        private System.Windows.Forms.Label lblCycleTime1;
        private System.Windows.Forms.Label lblPPID1;
        private System.Windows.Forms.GroupBox gbBendResult2;
        private System.Windows.Forms.DataGridView dgvSpec2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.Label lbResult2Title;
        private System.Windows.Forms.GroupBox gbBendResult1;
        private System.Windows.Forms.DataGridView dgvSpec1;
        private System.Windows.Forms.DataGridView dgvResult1;
        public System.Windows.Forms.Label lbResult1Title;
        private System.Windows.Forms.Timer tmrSave;
        private System.Windows.Forms.TabControl tcGraph;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataVisualization.Charting.Chart ctDisp1_2;
        private System.Windows.Forms.DataVisualization.Charting.Chart ctDisp1_1;
        private System.Windows.Forms.Label ct1_Xspec1_1;
        private System.Windows.Forms.Label ct1_Yspec1_1;
        private System.Windows.Forms.Label ct1_Yspec1_2;
        private System.Windows.Forms.Label ct1_Xspec1_2;
        private System.Windows.Forms.DataGridView dgvOKNG;
        private System.Windows.Forms.Panel pnGrahpData;
        private System.Windows.Forms.GroupBox pnResult1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label ct2_XSpec2_2;
        private System.Windows.Forms.Label ct2_YSpec2_1;
        private System.Windows.Forms.Label ct2_XSpec2_1;
        private System.Windows.Forms.DataVisualization.Charting.Chart ctDisp2_2;
        private System.Windows.Forms.DataVisualization.Charting.Chart ctDisp2_1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label ct3_XSpec3_2;
        private System.Windows.Forms.Label ct3_YSpec3_1;
        private System.Windows.Forms.Label ct3_XSpec3_1;
        private System.Windows.Forms.DataVisualization.Charting.Chart ctDisp3_2;
        private System.Windows.Forms.DataVisualization.Charting.Chart ctDisp3_1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Label ct4_Yspec4_2;
        private System.Windows.Forms.Label ct4_Xspec4_2;
        private System.Windows.Forms.Label ct4_Yspec4_1;
        private System.Windows.Forms.Label ct4_Xspec4_1;
        private System.Windows.Forms.DataVisualization.Charting.Chart ctDisp4_2;
        private System.Windows.Forms.DataVisualization.Charting.Chart ctDisp4_1;
        private System.Windows.Forms.Label ct2_YSpec2_2;
        private System.Windows.Forms.Label ct3_YSpec3_2;
        private System.Windows.Forms.GroupBox gbBendResult3;
        private System.Windows.Forms.DataGridView dgvSpec3;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridView dgvResult3;
        public System.Windows.Forms.Label lbResult3Title;
        private System.Windows.Forms.GroupBox gbBendResult4;
        private System.Windows.Forms.DataGridView dgvSpec4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DataGridView dgvResult4;
        public System.Windows.Forms.Label lbResult4Title;
        private System.Windows.Forms.Panel pnOKNG;
        private System.Windows.Forms.CheckBox cbResult;
        public System.Windows.Forms.Label label15;
        private System.Windows.Forms.DateTimePicker dtpEnd;
        private System.Windows.Forms.Panel pnTimeData;
        private System.Windows.Forms.DateTimePicker dtpokngStart;
        private System.Windows.Forms.DateTimePicker dtpokngEnd;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnTodayDisp;
        private System.Windows.Forms.Button btnDisp;
        private System.Windows.Forms.RadioButton rbGraphBD3;
        private System.Windows.Forms.RadioButton rbGraphBD2;
        private System.Windows.Forms.RadioButton rbGraphBD1;
        private System.Windows.Forms.RadioButton rbGraphTotal;
        private System.Windows.Forms.Label lblOFFSET1;
        private System.Windows.Forms.Label lblOFFSET2;
        private System.Windows.Forms.Panel pnInfo1;
        private System.Windows.Forms.Panel pnInfo2;
        private System.Windows.Forms.Label lblPPID2;
        private System.Windows.Forms.Label lblCycleTime2;
        private System.Windows.Forms.Label lblRetryCount2;
        private System.Windows.Forms.Panel pnInfo3;
        private System.Windows.Forms.Label lblPPID4;
        private System.Windows.Forms.Label lblCycleTime4;
        private System.Windows.Forms.Label lblRetryCount4;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.Panel pnInfo4;
        private System.Windows.Forms.Label lblPPID3;
        private System.Windows.Forms.Label lblCycleTime3;
        private System.Windows.Forms.Label lblRetryCount3;
        private System.Windows.Forms.ListBox listBox4;
        private System.Windows.Forms.Label lblOFFSET3;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.DataGridView dgvAlign1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.DataGridView dgvError1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn70;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn71;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.DataGridView dgvError3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn74;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn75;
        private System.Windows.Forms.DataGridView dgvError4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn76;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn77;
        private System.Windows.Forms.DataGridView dgvError2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn72;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn73;
        private System.Windows.Forms.Button btnDispReset;
        private System.Windows.Forms.Label lblRightScore2;
        private System.Windows.Forms.Label lblSpecOut1_2;
        private System.Windows.Forms.Label lblSpecOut1_1;
        private System.Windows.Forms.Label lblSpecOut2_2;
        private System.Windows.Forms.Label lblSpecOut2_1;
        private System.Windows.Forms.Label lblSpecOut3_2;
        private System.Windows.Forms.Label lblSpecOut3_1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtSuareY;
        private System.Windows.Forms.TextBox txtSuareX;
        private System.Windows.Forms.Label lblSpecOut4_2;
        private System.Windows.Forms.Label lblSpecOut4_1;
        private System.Windows.Forms.ComboBox cbSideImageSize4;
        private System.Windows.Forms.CheckBox cbLive4;
        private System.Windows.Forms.ComboBox cbSideImageSize3;
        private System.Windows.Forms.CheckBox cbLive3;
        private System.Windows.Forms.ComboBox cbSideImageSize2;
        private System.Windows.Forms.CheckBox cbLive2;
        private System.Windows.Forms.ComboBox cbSideImageSize1;
        private System.Windows.Forms.CheckBox cbLive1;
        private System.Windows.Forms.ComboBox cbSideImageSize8;
        private System.Windows.Forms.CheckBox cbLive8;
        private System.Windows.Forms.ComboBox cbSideImageSize6;
        private System.Windows.Forms.CheckBox cbLive6;
        private System.Windows.Forms.ComboBox cbSideImageSize5;
        private System.Windows.Forms.CheckBox cbLive5;
        private System.Windows.Forms.ComboBox cbSideImageSize7;
        private System.Windows.Forms.CheckBox cbLive7;
        private System.Windows.Forms.DataGridView dgvAlign3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn52;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn53;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn54;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn55;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn56;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn57;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn58;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn59;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn87;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn88;
        private System.Windows.Forms.DataGridView dgvAlign4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn60;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn61;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn62;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn63;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn64;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn65;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn66;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn68;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn69;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn89;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn90;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column26;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column27;
        private System.Windows.Forms.DataGridView dgvAlign2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn67;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn85;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn86;
        private System.Windows.Forms.Panel pnHeightDisp;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn101;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn100;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn99;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn98;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn97;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn96;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn95;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn94;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn93;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn92;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn91;
        private System.Windows.Forms.GroupBox pnResult2;
        private System.Windows.Forms.Button btnCPKReset;
        private System.Windows.Forms.Panel pnAPC;
        private System.Windows.Forms.Button btnManualMark;
        private System.Windows.Forms.Timer tmr1Sec;
        private System.Windows.Forms.CheckBox cbSCFInspResult;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataVisualization.Charting.Chart ctDisp1_4;
        private System.Windows.Forms.DataVisualization.Charting.Chart ctDisp1_3;
        private System.Windows.Forms.Label ct1_Yspec1_4;
        private System.Windows.Forms.Label ct1_Yspec1_3;
        private System.Windows.Forms.Label ct1_Xspec1_4;
        private System.Windows.Forms.Label ct1_Xspec1_3;
        private System.Windows.Forms.Label lblSpecOut1_4;
        private System.Windows.Forms.Label lblSpecOut1_3;
        private System.Windows.Forms.Panel pnInfo5;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.ListBox listBox5;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.DataGridView dgvAlign5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.DataGridView dgvError5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn78;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn79;
        private System.Windows.Forms.Label lblPPID5;
        private System.Windows.Forms.Label lblCycleTime5;
        private System.Windows.Forms.Label lblRetryCount5;
        private System.Windows.Forms.DataGridView dgvAPC1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column18;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn81;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn82;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn80;
        private System.Windows.Forms.DataGridView dgvAPC2;
        private System.Windows.Forms.Label lblRightScore1;
        private System.Windows.Forms.Button btnClearDisp;
        private System.Windows.Forms.Timer tmrDispChart;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSuareY1;
        private System.Windows.Forms.TextBox txtSuareX1;
        private System.Windows.Forms.Panel pnSquareLength;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button PCYTEST;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column28;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Button btnOff;
        private System.Windows.Forms.Button btnOn;
        private System.Windows.Forms.Button btn4;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.DataGridView dgvResult2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Label lblOFFSET0;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}
