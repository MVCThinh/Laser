﻿namespace MX_IF
{
    partial class MXIF
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tmrIF = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.showToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpLog = new System.Windows.Forms.TabPage();
            this.lbUPSLoad = new System.Windows.Forms.Label();
            this.lbGMSInspection = new System.Windows.Forms.Label();
            this.lbGMSLoad = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbPLC = new System.Windows.Forms.ListBox();
            this.lbplcMX = new System.Windows.Forms.ListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbMX = new System.Windows.Forms.ListBox();
            this.lbMain = new System.Windows.Forms.ListBox();
            this.lbVersion = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tpFFU = new System.Windows.Forms.TabPage();
            this.lblTimer = new System.Windows.Forms.Label();
            this.dgvFFU = new System.Windows.Forms.DataGridView();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label2 = new System.Windows.Forms.Label();
            this.tpGMS = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dgvGMS = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpPRE = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.dgvPRE = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpHeight = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tbUPS = new System.Windows.Forms.TabPage();
            this.gbGPS = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.lblGPSCurrentR = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lblGPSCurrentT = new System.Windows.Forms.Label();
            this.lblGPSVoltageT = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.lblGPSVoltageR = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.lblGPSKWhsum = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.lblGPSKWtotal = new System.Windows.Forms.Label();
            this.gbUPS = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.lblUPSCurrentR = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lblUPSCurrentT = new System.Windows.Forms.Label();
            this.lblUPSVoltageT = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblUPSVoltageR = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lblUPSKWhsum = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.lblUPSKWtotal = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.tmrUPS = new System.Windows.Forms.Timer(this.components);
            this.contextMenuStrip1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpLog.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tpFFU.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFFU)).BeginInit();
            this.tpGMS.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGMS)).BeginInit();
            this.tpPRE.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPRE)).BeginInit();
            this.tpHeight.SuspendLayout();
            this.tbUPS.SuspendLayout();
            this.gbGPS.SuspendLayout();
            this.gbUPS.SuspendLayout();
            this.SuspendLayout();
            // 
            // tmrIF
            // 
            this.tmrIF.Interval = 50;
            this.tmrIF.Tick += new System.EventHandler(this.tmrIF_Tick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(104, 26);
            // 
            // showToolStripMenuItem
            // 
            this.showToolStripMenuItem.Name = "showToolStripMenuItem";
            this.showToolStripMenuItem.Size = new System.Drawing.Size(103, 22);
            this.showToolStripMenuItem.Text = "Show";
            this.showToolStripMenuItem.Click += new System.EventHandler(this.showToolStripMenuItem_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpLog);
            this.tabControl1.Controls.Add(this.tpFFU);
            this.tabControl1.Controls.Add(this.tpGMS);
            this.tabControl1.Controls.Add(this.tpPRE);
            this.tabControl1.Controls.Add(this.tpHeight);
            this.tabControl1.Controls.Add(this.tbUPS);
            this.tabControl1.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(1, 1);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.Padding = new System.Drawing.Point(48, 20);
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(811, 620);
            this.tabControl1.TabIndex = 11;
            // 
            // tpLog
            // 
            this.tpLog.BackColor = System.Drawing.Color.LavenderBlush;
            this.tpLog.Controls.Add(this.lbUPSLoad);
            this.tpLog.Controls.Add(this.lbGMSInspection);
            this.tpLog.Controls.Add(this.lbGMSLoad);
            this.tpLog.Controls.Add(this.label1);
            this.tpLog.Controls.Add(this.panel2);
            this.tpLog.Controls.Add(this.label10);
            this.tpLog.Controls.Add(this.panel1);
            this.tpLog.Controls.Add(this.lbVersion);
            this.tpLog.Controls.Add(this.label8);
            this.tpLog.Controls.Add(this.label7);
            this.tpLog.Controls.Add(this.label6);
            this.tpLog.Controls.Add(this.label5);
            this.tpLog.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tpLog.Location = new System.Drawing.Point(4, 58);
            this.tpLog.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tpLog.Name = "tpLog";
            this.tpLog.Padding = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.tpLog.Size = new System.Drawing.Size(803, 558);
            this.tpLog.TabIndex = 0;
            this.tpLog.Text = "MX Log";
            // 
            // lbUPSLoad
            // 
            this.lbUPSLoad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbUPSLoad.Location = new System.Drawing.Point(251, 49);
            this.lbUPSLoad.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbUPSLoad.Name = "lbUPSLoad";
            this.lbUPSLoad.Size = new System.Drawing.Size(113, 23);
            this.lbUPSLoad.TabIndex = 280;
            this.lbUPSLoad.Text = "UPS";
            this.lbUPSLoad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbUPSLoad.Click += new System.EventHandler(this.lbUPSLoad_Click);
            // 
            // lbGMSInspection
            // 
            this.lbGMSInspection.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbGMSInspection.Location = new System.Drawing.Point(129, 49);
            this.lbGMSInspection.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbGMSInspection.Name = "lbGMSInspection";
            this.lbGMSInspection.Size = new System.Drawing.Size(113, 23);
            this.lbGMSInspection.TabIndex = 278;
            this.lbGMSInspection.Text = "GMS";
            this.lbGMSInspection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbGMSInspection.Visible = false;
            this.lbGMSInspection.Click += new System.EventHandler(this.lbGMSInspection_Click);
            // 
            // lbGMSLoad
            // 
            this.lbGMSLoad.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbGMSLoad.Location = new System.Drawing.Point(12, 49);
            this.lbGMSLoad.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbGMSLoad.Name = "lbGMSLoad";
            this.lbGMSLoad.Size = new System.Drawing.Size(113, 23);
            this.lbGMSLoad.TabIndex = 277;
            this.lbGMSLoad.Text = "GMS";
            this.lbGMSLoad.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbGMSLoad.Click += new System.EventHandler(this.lbGMSLoad_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DimGray;
            this.label1.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 319);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(186, 25);
            this.label1.TabIndex = 276;
            this.label1.Text = "MX <==> PLC";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbPLC);
            this.panel2.Controls.Add(this.lbplcMX);
            this.panel2.Location = new System.Drawing.Point(9, 346);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(655, 209);
            this.panel2.TabIndex = 275;
            // 
            // lbPLC
            // 
            this.lbPLC.FormattingEnabled = true;
            this.lbPLC.ItemHeight = 15;
            this.lbPLC.Location = new System.Drawing.Point(332, 3);
            this.lbPLC.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.lbPLC.Name = "lbPLC";
            this.lbPLC.Size = new System.Drawing.Size(318, 199);
            this.lbPLC.TabIndex = 17;
            // 
            // lbplcMX
            // 
            this.lbplcMX.FormattingEnabled = true;
            this.lbplcMX.ItemHeight = 15;
            this.lbplcMX.Location = new System.Drawing.Point(2, 3);
            this.lbplcMX.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.lbplcMX.Name = "lbplcMX";
            this.lbplcMX.Size = new System.Drawing.Size(323, 199);
            this.lbplcMX.TabIndex = 16;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.DimGray;
            this.label10.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(9, 83);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(186, 25);
            this.label10.TabIndex = 274;
            this.label10.Text = "Main <==> MX";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lbMX);
            this.panel1.Controls.Add(this.lbMain);
            this.panel1.Location = new System.Drawing.Point(9, 108);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(655, 207);
            this.panel1.TabIndex = 273;
            // 
            // lbMX
            // 
            this.lbMX.FormattingEnabled = true;
            this.lbMX.ItemHeight = 15;
            this.lbMX.Location = new System.Drawing.Point(332, 3);
            this.lbMX.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.lbMX.Name = "lbMX";
            this.lbMX.Size = new System.Drawing.Size(318, 199);
            this.lbMX.TabIndex = 13;
            // 
            // lbMain
            // 
            this.lbMain.FormattingEnabled = true;
            this.lbMain.ItemHeight = 15;
            this.lbMain.Location = new System.Drawing.Point(0, 0);
            this.lbMain.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.lbMain.Name = "lbMain";
            this.lbMain.Size = new System.Drawing.Size(323, 199);
            this.lbMain.TabIndex = 12;
            // 
            // lbVersion
            // 
            this.lbVersion.AutoSize = true;
            this.lbVersion.Location = new System.Drawing.Point(467, 24);
            this.lbVersion.Name = "lbVersion";
            this.lbVersion.Size = new System.Drawing.Size(62, 15);
            this.lbVersion.TabIndex = 23;
            this.lbVersion.Text = "lbVersion";
            // 
            // label8
            // 
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Location = new System.Drawing.Point(327, 23);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 23);
            this.label8.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label7.Location = new System.Drawing.Point(251, 23);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 23);
            this.label7.TabIndex = 21;
            this.label7.Text = "MX Error : ";
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Location = new System.Drawing.Point(129, 23);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(113, 23);
            this.label6.TabIndex = 20;
            this.label6.Text = "PLC Connection";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Location = new System.Drawing.Point(12, 23);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(113, 23);
            this.label5.TabIndex = 19;
            this.label5.Text = "Vision Connection";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tpFFU
            // 
            this.tpFFU.Controls.Add(this.lblTimer);
            this.tpFFU.Controls.Add(this.dgvFFU);
            this.tpFFU.Controls.Add(this.label2);
            this.tpFFU.Location = new System.Drawing.Point(4, 58);
            this.tpFFU.Name = "tpFFU";
            this.tpFFU.Size = new System.Drawing.Size(803, 558);
            this.tpFFU.TabIndex = 5;
            this.tpFFU.Text = "FFU";
            // 
            // lblTimer
            // 
            this.lblTimer.BackColor = System.Drawing.Color.White;
            this.lblTimer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTimer.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTimer.Location = new System.Drawing.Point(143, 33);
            this.lblTimer.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(86, 27);
            this.lblTimer.TabIndex = 292;
            this.lblTimer.Text = "ALIVE";
            this.lblTimer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvFFU
            // 
            this.dgvFFU.AllowUserToAddRows = false;
            this.dgvFFU.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllHeaders;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.DarkBlue;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvFFU.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvFFU.ColumnHeadersHeight = 60;
            this.dgvFFU.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column7,
            this.Column13,
            this.Column6});
            this.dgvFFU.Location = new System.Drawing.Point(18, 100);
            this.dgvFFU.Name = "dgvFFU";
            this.dgvFFU.ReadOnly = true;
            this.dgvFFU.RowHeadersWidth = 134;
            this.dgvFFU.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgvFFU.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.dgvFFU.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.ColumnHeaderSelect;
            this.dgvFFU.Size = new System.Drawing.Size(632, 444);
            this.dgvFFU.TabIndex = 291;
            // 
            // Column7
            // 
            this.Column7.HeaderText = "RPM";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            this.Column7.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column7.Width = 150;
            // 
            // Column13
            // 
            this.Column13.HeaderText = "Power (0 : oFF, 1 : ON)";
            this.Column13.Name = "Column13";
            this.Column13.ReadOnly = true;
            this.Column13.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column13.Width = 150;
            // 
            // Column6
            // 
            this.Column6.HeaderText = "Alarm (0 : OK, 1 : NG)";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Column6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column6.Width = 150;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(29, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 27);
            this.label2.TabIndex = 290;
            this.label2.Text = "FFU";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tpGMS
            // 
            this.tpGMS.Controls.Add(this.label11);
            this.tpGMS.Controls.Add(this.label3);
            this.tpGMS.Controls.Add(this.dgvGMS);
            this.tpGMS.Location = new System.Drawing.Point(4, 58);
            this.tpGMS.Name = "tpGMS";
            this.tpGMS.Size = new System.Drawing.Size(803, 558);
            this.tpGMS.TabIndex = 6;
            this.tpGMS.Text = "GMS";
            this.tpGMS.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.SystemColors.Control;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label11.Location = new System.Drawing.Point(116, 34);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(86, 27);
            this.label11.TabIndex = 292;
            this.label11.Text = "GMS2";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Visible = false;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.SystemColors.Control;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(25, 34);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 27);
            this.label3.TabIndex = 291;
            this.label3.Text = "GMS1";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvGMS
            // 
            this.dgvGMS.AllowUserToAddRows = false;
            this.dgvGMS.AllowUserToDeleteRows = false;
            this.dgvGMS.AllowUserToResizeRows = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgvGMS.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvGMS.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvGMS.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGMS.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn5,
            this.Column2,
            this.dataGridViewTextBoxColumn6});
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvGMS.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvGMS.Location = new System.Drawing.Point(15, 91);
            this.dgvGMS.Name = "dgvGMS";
            this.dgvGMS.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvGMS.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgvGMS.RowHeadersVisible = false;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgvGMS.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dgvGMS.RowTemplate.Height = 23;
            this.dgvGMS.Size = new System.Drawing.Size(639, 453);
            this.dgvGMS.TabIndex = 66;
            // 
            // dataGridViewTextBoxColumn1
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Blue;
            this.dataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn1.HeaderText = "PORT";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Width = 120;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn5.HeaderText = "GMS1";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column2
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.Blue;
            this.Column2.DefaultCellStyle = dataGridViewCellStyle6;
            this.Column2.HeaderText = "PORT";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Column2.Width = 120;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridViewTextBoxColumn6.HeaderText = "GMS2";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tpPRE
            // 
            this.tpPRE.Controls.Add(this.label9);
            this.tpPRE.Controls.Add(this.dgvPRE);
            this.tpPRE.Location = new System.Drawing.Point(4, 58);
            this.tpPRE.Name = "tpPRE";
            this.tpPRE.Size = new System.Drawing.Size(803, 558);
            this.tpPRE.TabIndex = 7;
            this.tpPRE.Text = "PRE";
            this.tpPRE.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.SystemColors.Control;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label9.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label9.Location = new System.Drawing.Point(30, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(86, 27);
            this.label9.TabIndex = 291;
            this.label9.Text = "FFU";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dgvPRE
            // 
            this.dgvPRE.AllowUserToAddRows = false;
            this.dgvPRE.AllowUserToDeleteRows = false;
            this.dgvPRE.AllowUserToResizeRows = false;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Georgia", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPRE.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle11;
            this.dgvPRE.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPRE.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.Column1});
            this.dgvPRE.Location = new System.Drawing.Point(19, 76);
            this.dgvPRE.Name = "dgvPRE";
            this.dgvPRE.ReadOnly = true;
            this.dgvPRE.RowHeadersVisible = false;
            this.dgvPRE.RowTemplate.Height = 23;
            this.dgvPRE.Size = new System.Drawing.Size(612, 449);
            this.dgvPRE.TabIndex = 69;
            // 
            // dataGridViewTextBoxColumn2
            // 
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.Color.Blue;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.Color.Blue;
            this.dataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewTextBoxColumn2.HeaderText = "DATA";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn3
            // 
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridViewTextBoxColumn3.HeaderText = "LEFT";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn4
            // 
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridViewTextBoxColumn4.HeaderText = "RIGHT";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Column1
            // 
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Column1.DefaultCellStyle = dataGridViewCellStyle15;
            this.Column1.HeaderText = "SPARE";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // tpHeight
            // 
            this.tpHeight.Controls.Add(this.label4);
            this.tpHeight.Controls.Add(this.button1);
            this.tpHeight.Controls.Add(this.listBox1);
            this.tpHeight.Location = new System.Drawing.Point(4, 58);
            this.tpHeight.Name = "tpHeight";
            this.tpHeight.Size = new System.Drawing.Size(803, 558);
            this.tpHeight.TabIndex = 8;
            this.tpHeight.Text = "Height";
            this.tpHeight.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.SystemColors.Control;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label4.Location = new System.Drawing.Point(29, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(156, 27);
            this.label4.TabIndex = 291;
            this.label4.Text = "HEIGHT CONNECTION";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(453, 26);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(141, 34);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 15;
            this.listBox1.Location = new System.Drawing.Point(21, 90);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(625, 439);
            this.listBox1.TabIndex = 0;
            // 
            // tbUPS
            // 
            this.tbUPS.Controls.Add(this.gbGPS);
            this.tbUPS.Controls.Add(this.gbUPS);
            this.tbUPS.Location = new System.Drawing.Point(4, 58);
            this.tbUPS.Name = "tbUPS";
            this.tbUPS.Padding = new System.Windows.Forms.Padding(3);
            this.tbUPS.Size = new System.Drawing.Size(803, 558);
            this.tbUPS.TabIndex = 10;
            this.tbUPS.Text = "UPS/GPS";
            this.tbUPS.UseVisualStyleBackColor = true;
            // 
            // gbGPS
            // 
            this.gbGPS.Controls.Add(this.label14);
            this.gbGPS.Controls.Add(this.label17);
            this.gbGPS.Controls.Add(this.label19);
            this.gbGPS.Controls.Add(this.lblGPSCurrentR);
            this.gbGPS.Controls.Add(this.label22);
            this.gbGPS.Controls.Add(this.lblGPSCurrentT);
            this.gbGPS.Controls.Add(this.lblGPSVoltageT);
            this.gbGPS.Controls.Add(this.label30);
            this.gbGPS.Controls.Add(this.lblGPSVoltageR);
            this.gbGPS.Controls.Add(this.label32);
            this.gbGPS.Controls.Add(this.label33);
            this.gbGPS.Controls.Add(this.label34);
            this.gbGPS.Controls.Add(this.label35);
            this.gbGPS.Controls.Add(this.label36);
            this.gbGPS.Controls.Add(this.lblGPSKWhsum);
            this.gbGPS.Controls.Add(this.label38);
            this.gbGPS.Controls.Add(this.lblGPSKWtotal);
            this.gbGPS.Location = new System.Drawing.Point(417, 44);
            this.gbGPS.Name = "gbGPS";
            this.gbGPS.Size = new System.Drawing.Size(408, 435);
            this.gbGPS.TabIndex = 354;
            this.gbGPS.TabStop = false;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.SystemColors.Control;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label14.Location = new System.Drawing.Point(0, 72);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(86, 27);
            this.label14.TabIndex = 323;
            this.label14.Text = "GPS";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.SystemColors.Control;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label17.Location = new System.Drawing.Point(1, 304);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(403, 25);
            this.label17.TabIndex = 352;
            this.label17.Text = "CURRENT MONITORING";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label19.Location = new System.Drawing.Point(202, 245);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(201, 20);
            this.label19.TabIndex = 329;
            this.label19.Text = "T상 전압";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGPSCurrentR
            // 
            this.lblGPSCurrentR.BackColor = System.Drawing.Color.Black;
            this.lblGPSCurrentR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGPSCurrentR.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGPSCurrentR.ForeColor = System.Drawing.Color.Yellow;
            this.lblGPSCurrentR.Location = new System.Drawing.Point(1, 354);
            this.lblGPSCurrentR.Name = "lblGPSCurrentR";
            this.lblGPSCurrentR.Size = new System.Drawing.Size(196, 30);
            this.lblGPSCurrentR.TabIndex = 344;
            this.lblGPSCurrentR.Text = "-";
            this.lblGPSCurrentR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label22.Location = new System.Drawing.Point(0, 245);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(197, 20);
            this.label22.TabIndex = 327;
            this.label22.Text = "R상 전압";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGPSCurrentT
            // 
            this.lblGPSCurrentT.BackColor = System.Drawing.Color.Black;
            this.lblGPSCurrentT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGPSCurrentT.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGPSCurrentT.ForeColor = System.Drawing.Color.Yellow;
            this.lblGPSCurrentT.Location = new System.Drawing.Point(204, 354);
            this.lblGPSCurrentT.Name = "lblGPSCurrentT";
            this.lblGPSCurrentT.Size = new System.Drawing.Size(201, 30);
            this.lblGPSCurrentT.TabIndex = 346;
            this.lblGPSCurrentT.Text = "-";
            this.lblGPSCurrentT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGPSVoltageT
            // 
            this.lblGPSVoltageT.BackColor = System.Drawing.Color.Black;
            this.lblGPSVoltageT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGPSVoltageT.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGPSVoltageT.ForeColor = System.Drawing.Color.Yellow;
            this.lblGPSVoltageT.Location = new System.Drawing.Point(202, 265);
            this.lblGPSVoltageT.Name = "lblGPSVoltageT";
            this.lblGPSVoltageT.Size = new System.Drawing.Size(201, 30);
            this.lblGPSVoltageT.TabIndex = 325;
            this.lblGPSVoltageT.Text = "-";
            this.lblGPSVoltageT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label30.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label30.Location = new System.Drawing.Point(204, 334);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(199, 20);
            this.label30.TabIndex = 347;
            this.label30.Text = "T상 전류";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGPSVoltageR
            // 
            this.lblGPSVoltageR.BackColor = System.Drawing.Color.Black;
            this.lblGPSVoltageR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGPSVoltageR.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGPSVoltageR.ForeColor = System.Drawing.Color.Yellow;
            this.lblGPSVoltageR.Location = new System.Drawing.Point(0, 265);
            this.lblGPSVoltageR.Name = "lblGPSVoltageR";
            this.lblGPSVoltageR.Size = new System.Drawing.Size(196, 30);
            this.lblGPSVoltageR.TabIndex = 324;
            this.lblGPSVoltageR.Text = "-";
            this.lblGPSVoltageR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label32.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label32.Location = new System.Drawing.Point(1, 334);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(196, 20);
            this.label32.TabIndex = 348;
            this.label32.Text = "R상 전류";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.SystemColors.Control;
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label33.Location = new System.Drawing.Point(0, 216);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(403, 25);
            this.label33.TabIndex = 331;
            this.label33.Text = "VOLTAGE MONITORING";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.White;
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label34.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(303, 72);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(100, 25);
            this.label34.TabIndex = 343;
            this.label34.Text = "ALIVE";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.SystemColors.Control;
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label35.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label35.Location = new System.Drawing.Point(0, 125);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(403, 25);
            this.label35.TabIndex = 333;
            this.label35.Text = "POWER MONITORING";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label36.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label36.Location = new System.Drawing.Point(202, 155);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(200, 20);
            this.label36.TabIndex = 339;
            this.label36.Text = "전력량(순시)[KW]";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGPSKWhsum
            // 
            this.lblGPSKWhsum.BackColor = System.Drawing.Color.Black;
            this.lblGPSKWhsum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGPSKWhsum.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGPSKWhsum.ForeColor = System.Drawing.Color.Yellow;
            this.lblGPSKWhsum.Location = new System.Drawing.Point(0, 175);
            this.lblGPSKWhsum.Name = "lblGPSKWhsum";
            this.lblGPSKWhsum.Size = new System.Drawing.Size(196, 30);
            this.lblGPSKWhsum.TabIndex = 334;
            this.lblGPSKWhsum.Text = "-";
            this.lblGPSKWhsum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label38.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label38.Location = new System.Drawing.Point(0, 155);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(196, 20);
            this.label38.TabIndex = 337;
            this.label38.Text = "모든 상의 유효전력의 합(KWH)";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblGPSKWtotal
            // 
            this.lblGPSKWtotal.BackColor = System.Drawing.Color.Black;
            this.lblGPSKWtotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblGPSKWtotal.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGPSKWtotal.ForeColor = System.Drawing.Color.Yellow;
            this.lblGPSKWtotal.Location = new System.Drawing.Point(202, 175);
            this.lblGPSKWtotal.Name = "lblGPSKWtotal";
            this.lblGPSKWtotal.Size = new System.Drawing.Size(201, 30);
            this.lblGPSKWtotal.TabIndex = 336;
            this.lblGPSKWtotal.Text = "-";
            this.lblGPSKWtotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbUPS
            // 
            this.gbUPS.Controls.Add(this.label12);
            this.gbUPS.Controls.Add(this.label13);
            this.gbUPS.Controls.Add(this.label29);
            this.gbUPS.Controls.Add(this.lblUPSCurrentR);
            this.gbUPS.Controls.Add(this.label27);
            this.gbUPS.Controls.Add(this.lblUPSCurrentT);
            this.gbUPS.Controls.Add(this.lblUPSVoltageT);
            this.gbUPS.Controls.Add(this.label15);
            this.gbUPS.Controls.Add(this.lblUPSVoltageR);
            this.gbUPS.Controls.Add(this.label16);
            this.gbUPS.Controls.Add(this.label25);
            this.gbUPS.Controls.Add(this.label18);
            this.gbUPS.Controls.Add(this.label24);
            this.gbUPS.Controls.Add(this.label21);
            this.gbUPS.Controls.Add(this.lblUPSKWhsum);
            this.gbUPS.Controls.Add(this.label23);
            this.gbUPS.Controls.Add(this.lblUPSKWtotal);
            this.gbUPS.Location = new System.Drawing.Point(3, 44);
            this.gbUPS.Name = "gbUPS";
            this.gbUPS.Size = new System.Drawing.Size(408, 435);
            this.gbUPS.TabIndex = 353;
            this.gbUPS.TabStop = false;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.SystemColors.Control;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label12.Location = new System.Drawing.Point(0, 72);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(86, 27);
            this.label12.TabIndex = 323;
            this.label12.Text = "UPS";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.SystemColors.Control;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label13.Location = new System.Drawing.Point(1, 304);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(403, 25);
            this.label13.TabIndex = 352;
            this.label13.Text = "CURRENT MONITORING";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label29.Location = new System.Drawing.Point(202, 245);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(201, 20);
            this.label29.TabIndex = 329;
            this.label29.Text = "T상 전압";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUPSCurrentR
            // 
            this.lblUPSCurrentR.BackColor = System.Drawing.Color.Black;
            this.lblUPSCurrentR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUPSCurrentR.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUPSCurrentR.ForeColor = System.Drawing.Color.Yellow;
            this.lblUPSCurrentR.Location = new System.Drawing.Point(1, 354);
            this.lblUPSCurrentR.Name = "lblUPSCurrentR";
            this.lblUPSCurrentR.Size = new System.Drawing.Size(196, 30);
            this.lblUPSCurrentR.TabIndex = 344;
            this.lblUPSCurrentR.Text = "-";
            this.lblUPSCurrentR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label27.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label27.Location = new System.Drawing.Point(0, 245);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(197, 20);
            this.label27.TabIndex = 327;
            this.label27.Text = "R상 전압";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUPSCurrentT
            // 
            this.lblUPSCurrentT.BackColor = System.Drawing.Color.Black;
            this.lblUPSCurrentT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUPSCurrentT.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUPSCurrentT.ForeColor = System.Drawing.Color.Yellow;
            this.lblUPSCurrentT.Location = new System.Drawing.Point(204, 354);
            this.lblUPSCurrentT.Name = "lblUPSCurrentT";
            this.lblUPSCurrentT.Size = new System.Drawing.Size(201, 30);
            this.lblUPSCurrentT.TabIndex = 346;
            this.lblUPSCurrentT.Text = "-";
            this.lblUPSCurrentT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUPSVoltageT
            // 
            this.lblUPSVoltageT.BackColor = System.Drawing.Color.Black;
            this.lblUPSVoltageT.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUPSVoltageT.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUPSVoltageT.ForeColor = System.Drawing.Color.Yellow;
            this.lblUPSVoltageT.Location = new System.Drawing.Point(202, 265);
            this.lblUPSVoltageT.Name = "lblUPSVoltageT";
            this.lblUPSVoltageT.Size = new System.Drawing.Size(201, 30);
            this.lblUPSVoltageT.TabIndex = 325;
            this.lblUPSVoltageT.Text = "-";
            this.lblUPSVoltageT.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label15.Location = new System.Drawing.Point(204, 334);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(199, 20);
            this.label15.TabIndex = 347;
            this.label15.Text = "T상 전류";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUPSVoltageR
            // 
            this.lblUPSVoltageR.BackColor = System.Drawing.Color.Black;
            this.lblUPSVoltageR.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUPSVoltageR.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUPSVoltageR.ForeColor = System.Drawing.Color.Yellow;
            this.lblUPSVoltageR.Location = new System.Drawing.Point(0, 265);
            this.lblUPSVoltageR.Name = "lblUPSVoltageR";
            this.lblUPSVoltageR.Size = new System.Drawing.Size(196, 30);
            this.lblUPSVoltageR.TabIndex = 324;
            this.lblUPSVoltageR.Text = "-";
            this.lblUPSVoltageR.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label16.Location = new System.Drawing.Point(1, 334);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(196, 20);
            this.label16.TabIndex = 348;
            this.label16.Text = "R상 전류";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.SystemColors.Control;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label25.Location = new System.Drawing.Point(0, 216);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(403, 25);
            this.label25.TabIndex = 331;
            this.label25.Text = "VOLTAGE MONITORING";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(303, 72);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(100, 25);
            this.label18.TabIndex = 343;
            this.label18.Text = "ALIVE";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.SystemColors.Control;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label24.Location = new System.Drawing.Point(0, 125);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(403, 25);
            this.label24.TabIndex = 333;
            this.label24.Text = "POWER MONITORING";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label21.Location = new System.Drawing.Point(202, 155);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(200, 20);
            this.label21.TabIndex = 339;
            this.label21.Text = "전력량(순시)[KW]";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUPSKWhsum
            // 
            this.lblUPSKWhsum.BackColor = System.Drawing.Color.Black;
            this.lblUPSKWhsum.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUPSKWhsum.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUPSKWhsum.ForeColor = System.Drawing.Color.Yellow;
            this.lblUPSKWhsum.Location = new System.Drawing.Point(0, 175);
            this.lblUPSKWhsum.Name = "lblUPSKWhsum";
            this.lblUPSKWhsum.Size = new System.Drawing.Size(196, 30);
            this.lblUPSKWhsum.TabIndex = 334;
            this.lblUPSKWhsum.Text = "-";
            this.lblUPSKWhsum.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label23.Location = new System.Drawing.Point(0, 155);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(196, 20);
            this.label23.TabIndex = 337;
            this.label23.Text = "모든 상의 유효전력의 합(KWH)";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblUPSKWtotal
            // 
            this.lblUPSKWtotal.BackColor = System.Drawing.Color.Black;
            this.lblUPSKWtotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUPSKWtotal.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUPSKWtotal.ForeColor = System.Drawing.Color.Yellow;
            this.lblUPSKWtotal.Location = new System.Drawing.Point(202, 175);
            this.lblUPSKWtotal.Name = "lblUPSKWtotal";
            this.lblUPSKWtotal.Size = new System.Drawing.Size(201, 30);
            this.lblUPSKWtotal.TabIndex = 336;
            this.lblUPSKWtotal.Text = "-";
            this.lblUPSKWtotal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer1
            // 
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 500;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // tmrUPS
            // 
            this.tmrUPS.Interval = 10000;
            this.tmrUPS.Tick += new System.EventHandler(this.tmrUPS_Tick);
            // 
            // MXIF
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.LavenderBlush;
            this.ClientSize = new System.Drawing.Size(813, 621);
            this.ControlBox = false;
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MXIF";
            this.Text = "MX_IF";
            this.WindowState = System.Windows.Forms.FormWindowState.Minimized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MXIF_FormClosing);
            this.contextMenuStrip1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tpLog.ResumeLayout(false);
            this.tpLog.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tpFFU.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvFFU)).EndInit();
            this.tpGMS.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvGMS)).EndInit();
            this.tpPRE.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvPRE)).EndInit();
            this.tpHeight.ResumeLayout(false);
            this.tbUPS.ResumeLayout(false);
            this.gbGPS.ResumeLayout(false);
            this.gbUPS.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer tmrIF;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem showToolStripMenuItem;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpFFU;
        private System.Windows.Forms.TabPage tpLog;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lbVersion;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ListBox lbPLC;
        private System.Windows.Forms.ListBox lbplcMX;
        public System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ListBox lbMX;
        private System.Windows.Forms.ListBox lbMain;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.DataGridView dgvFFU;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column13;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lbGMSInspection;
        private System.Windows.Forms.Label lbGMSLoad;
        private System.Windows.Forms.TabPage tpGMS;
        private System.Windows.Forms.TabPage tpPRE;
        private System.Windows.Forms.DataGridView dgvGMS;
        private System.Windows.Forms.DataGridView dgvPRE;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.TabPage tpHeight;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.Label lbUPSLoad;
        private System.Windows.Forms.Timer tmrUPS;
        private System.Windows.Forms.TabPage tbUPS;
        private System.Windows.Forms.GroupBox gbGPS;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label lblGPSCurrentR;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblGPSCurrentT;
        private System.Windows.Forms.Label lblGPSVoltageT;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label lblGPSVoltageR;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label lblGPSKWhsum;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label lblGPSKWtotal;
        private System.Windows.Forms.GroupBox gbUPS;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label lblUPSCurrentR;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lblUPSCurrentT;
        private System.Windows.Forms.Label lblUPSVoltageT;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblUPSVoltageR;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblUPSKWhsum;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label lblUPSKWtotal;
    }
}

